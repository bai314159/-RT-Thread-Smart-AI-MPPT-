
#ifndef RTCONFIG_PREINC_H__
#define RTCONFIG_PREINC_H__

/* Automatically generated file; DO NOT EDIT. */
/* RT-Thread pre-include file */

#define HAVE_CCONFIG_H
#define __RTTHREAD__

#endif /*RTCONFIG_PREINC_H__*/
