/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-07-08     RT-Thread    Power Control System with MPPT
 */

#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#ifdef RT_USING_PWM
#include <drv_pwm.h>
#endif

/* Math utility functions */
#ifndef fminf
#define fminf(a, b) ((a) < (b) ? (a) : (b))
#endif

#ifndef fmaxf
#define fmaxf(a, b) ((a) > (b) ? (a) : (b))
#endif

#ifndef fabsf
#define fabsf(x) ((x) < 0 ? -(x) : (x))
#endif

/* RT-Thread device handles */
static rt_device_t uart_dev = RT_NULL;
static rt_device_t adc_dev = RT_NULL;
#ifdef RT_USING_PWM
static struct rt_device_pwm *pwm_dev = RT_NULL;
#endif

/* System configuration */
#define MAIN_THREAD_STACK_SIZE 4096
#define MAIN_THREAD_PRIORITY   5
#define TASK_05MS_THREAD_STACK_SIZE 2048
#define TASK_05MS_THREAD_PRIORITY   8

/* Hardware configuration */
#define ADC_DEV_NAME    "adc1"
#define UART_DEV_NAME   "uart2"
#define PWM_DEV_NAME    "pwm1"

/* Power system constants */
#define DP_VOLTAGE_RATED     48.0f
#define DP_CURRENT_RATED     5.0f
#define DP_VOLTAGE_OUT_MAX   50.0f
#define DP_CURRENT_OUT_MAX   6.0f
#define DP_VOLTAGE_IN_MAX    60.0f
#define DP_CURRENT_IN_MAX    8.0f
#define DP_VOLTAGE_IN_MIN    8.0f
#define DP_PWM_FREQUENCY     25000
#define DP_PWM_PER          4000
#define DP_ADC_II_OFFSET    2048.0f
#define DP_ADC_IO_OFFSET    2048.0f

/* Voltage and current ratio calibration */
#define DP_VOLTAGE_OUT_RATIO 0.015f
#define DP_CURRENT_OUT_RATIO 0.002f
#define DP_VOLTAGE_IN_RATIO  0.018f
#define DP_CURRENT_IN_RATIO  0.0025f

/* Filter constants */
#define PI2 6.283185307f

/* MPPT constants */
#define SCAN_RESOLUTION 100
#define VOLTAGE_START   5.0f
#define VOLTAGE_END     45.0f
#define NUM_RULES       9
#define NUM_INPUTS      2
#define LEARNING_RATE   0.01f
#define INITIAL_ALPHA   0.25f

/* Data structures */
typedef struct {
    float x1, y1, x2, y2;
    float Value;
    float Coeff;
    float Offset;
} ELEC_INFO_STRUCT;

typedef struct {
    float Input;
    float Output;
    float Fc;
    float Fs;
    float Ka;
    float Kb;
} LOW_FILTER_STRUCT;

typedef struct {
    float T;
    float Kp, Ti, Td;
    float Ref, Fdb;
    float Ek_0, Ek_1, Ek_2;
    float Ek_Dead;
    float Output;
    float OutMax, OutMin;
    float Increm;
    float a0, a1, a2;
} PID_STRUCT;

typedef struct {
    float VoRefSet;
    float IoRefSet;
    float ViRefSet;
} BASE_CMD_STRUCT;

typedef union {
    struct {
        rt_uint32_t RUN    : 1;
        rt_uint32_t FAUT   : 1;
        rt_uint32_t RDY    : 1;
        rt_uint32_t EN     : 1;
        rt_uint32_t PWRUP  : 1;
        rt_uint32_t CC     : 1;
        rt_uint32_t CV     : 1;
        rt_uint32_t CW     : 1;
        rt_uint32_t MPPT   : 1;
        rt_uint32_t CHARGE : 1;
        rt_uint32_t DISCHA : 1;
        rt_uint32_t reserved : 21;
    } bit;
    rt_uint32_t all;
} SYSTEM_STA_STRUCT;

typedef union {
    struct {
        rt_uint32_t excu : 1;
        rt_uint32_t iovp : 1;
        rt_uint32_t oovp : 1;
        rt_uint32_t iocp : 1;
        rt_uint32_t oocp : 1;
        rt_uint32_t iuvp : 1;
        rt_uint32_t motp : 1;
        rt_uint32_t reserved : 25;
    } bit;
    rt_uint32_t all;
} SYSTEM_FAULT_STRUCT;

typedef struct {
    float VoltIn[SCAN_RESOLUTION];
    float VoltOut[SCAN_RESOLUTION];
    float CurrIn[SCAN_RESOLUTION];
    float CurrOut[SCAN_RESOLUTION];
} CurveI_V;

/* Global variables */
static volatile SYSTEM_FAULT_STRUCT gPSM_FAULT;
static volatile SYSTEM_STA_STRUCT gPSM_STA;
static BASE_CMD_STRUCT gMainCmd;
static ELEC_INFO_STRUCT gVoltOutStr, gCurrOutStr, gVoltInStr, gCurrInStr;
static LOW_FILTER_STRUCT gLowFilter_ViFdb, gLowFilter_IiFdb, gLowFilter_VoFdb, gLowFilter_IoFdb;
static PID_STRUCT gPID_VoltInLoop, gPID_VoltOutLoop, gPID_CurrOutLoop;
static CurveI_V g_sCurve;

static float gDefVoltageOutSet = 13.00f;
static float gDefCurrentOutSet = 5.00f;
static float gDegTempMos = 25.0f;
static float gExcursionZeroIin = DP_ADC_II_OFFSET;
static float gExcursionZeroIout = DP_ADC_IO_OFFSET;

static volatile rt_uint32_t gAdcSampleBuf[3];
static volatile rt_uint64_t gSysTim01msTicks = 0;
static volatile rt_uint64_t gBaseTim05msTick = 0;
static volatile rt_uint64_t gBaseTim1sTick = 0;

static volatile int iv_received_flag = 0;
static rt_uint8_t direct[4] = {9, 9, 9, 9};
static int sampleIndex = 0;
static float GetIVbuckboost = 100;
static int GetIVbuckboost_flag = 0;
static int current_send_index = 0;

/* Thread handles */
static rt_thread_t main_task_thread = RT_NULL;
static rt_thread_t task_05ms_thread = RT_NULL;

/* RT-Thread timer for system tick */
static rt_timer_t systick_timer = RT_NULL;

/* Function prototypes */
static void low_filter_init(LOW_FILTER_STRUCT *p);
static void low_filter_calc(LOW_FILTER_STRUCT *p);
static void pid_init(PID_STRUCT *p);
static void pid_calc(PID_STRUCT *p);
static void pid_reset(PID_STRUCT *p);
static void pid_clc(PID_STRUCT *p);
static void dp_ElecLineCorr(ELEC_INFO_STRUCT *p);
static void dp_ExcursionCheck(void);
static void dp_PowerCmcCtrl(void);
static void dp_PowerCtrlInit(void);
static float f_MosTempDeal(void);
static float f_GetMosTemp(void);
static float tsFuzzyNNGsaMppt(float pv_v, float pv_i, rt_uint8_t mppt_enable);
static float dpMpptPoCtr(float vin, float iin, rt_uint8_t enable);
static void GetIV_Line1(void);
static void IVsend_data(void);
static void Task_05ms_A(void);
static void Task_05ms_B(void);
static void Task_05ms_C(void);
static void Task_05ms_D(void);
static void Task_1s(void);

/* Utility function to get minimum of two floats */
static float min_float(float a, float b)
{
    return (a < b) ? a : b;
}

/* Utility function to get maximum of two floats */
static float max_float(float a, float b)
{
    return (a > b) ? a : b;
}

/* Utility function to get absolute value of float */
static float abs_float(float x)
{
    return (x < 0) ? -x : x;
}

/* Low-pass filter implementation */
static void low_filter_init(LOW_FILTER_STRUCT *p)
{
    float Tc;

    if (p->Fc <= 0.0f || p->Fs <= 0.0f) {
        p->Ka = 1.0f;
        p->Kb = 0.0f;
        return;
    }

    Tc = 1.0f / (PI2 * p->Fc);
    p->Ka = 1.0f / (1.0f + Tc * p->Fs);
    p->Kb = 1.0f - p->Ka;
    p->Input = 0.0f;
    p->Output = 0.0f;
}

static void low_filter_calc(LOW_FILTER_STRUCT *p)
{
    if (p->Output == p->Input) return;
    p->Output = p->Ka * p->Input + p->Kb * p->Output;
}

/* PID controller implementation */
static void pid_init(PID_STRUCT *p)
{
    if (p->T <= 0) p->T = 1.0f;
    if (p->Ti == 0) p->Ti = 3.4E+38f;
    if (p->Ek_Dead < 0) p->Ek_Dead = 0;

    p->a0 = p->Kp * (1.0f + p->T/p->Ti + p->Td/p->T);
    p->a1 = p->Kp * (1.0f + p->Td/p->T * 2.0f);
    p->a2 = p->Kp * p->Td/p->T;
}

static void pid_reset(PID_STRUCT *p)
{
    rt_memset(p, 0, sizeof(PID_STRUCT));
}

static void pid_clc(PID_STRUCT *p)
{
    p->Ek_0 = 0;
    p->Ek_1 = 0;
    p->Ek_2 = 0;
    p->Increm = 0;
    p->Output = 0;
}

static void pid_calc(PID_STRUCT *p)
{
    p->Ek_0 = p->Ref - p->Fdb;

    if (abs_float(p->Ek_0) < p->Ek_Dead) {
        p->Increm = 0;
    } else {
        p->Increm = (p->a0 * p->Ek_0 - p->a1 * p->Ek_1 + p->a2 * p->Ek_2);
    }

    p->Output += p->Increm;

    p->Ek_2 = p->Ek_1;
    p->Ek_1 = p->Ek_0;

    if (p->Output > p->OutMax) {
        p->Output = p->OutMax;
        return;
    }
    if (p->Output < p->OutMin) {
        p->Output = p->OutMin;
        return;
    }
}

/* Linear correction for voltage/current sensing */
static void dp_ElecLineCorr(ELEC_INFO_STRUCT *p)
{
    float a, b;

    if ((p->y2 - p->y1 == 0) || (p->x2 - p->x1 == 0)) {
        return;
    }

    a = (p->y2 - p->y1) / (p->x2 - p->x1);
    b = (p->y1 - p->x1 * a);

    p->Value = 0;
    p->Coeff = a * p->Coeff;
    p->Offset = b;
}

/* Zero drift check */
static void dp_ExcursionCheck(void)
{
    static rt_uint8_t sys_stop_count = 0;
    static rt_uint8_t excursion_count = 0;
    static rt_uint8_t excursion_ErrCnt = 0;
    static float excursion_total1 = 0;
    static float excursion_total2 = 0;

    if (gPSM_STA.bit.RUN != 0) {
        sys_stop_count = 0;
        return;
    }

    sys_stop_count = (sys_stop_count >= 200) ? 200 : sys_stop_count + 1;
    if (sys_stop_count < 200) {
        excursion_total1 = 0;
        excursion_total2 = 0;
        excursion_count = 0;
        return;
    }

    excursion_total1 += (rt_uint16_t)(gAdcSampleBuf[0] & 0xFFFF);
    excursion_total2 += (rt_uint16_t)(gAdcSampleBuf[1] & 0xFFFF);
    excursion_count += 1;

    if (excursion_count >= 32) {
        float n_Err = excursion_total1 / 32.0f;
        float m_Err = excursion_total2 / 32.0f;
        excursion_total1 = 0;
        excursion_total2 = 0;
        excursion_count = 0;

        if (abs_float(n_Err - DP_ADC_II_OFFSET) < 80 && abs_float(m_Err - DP_ADC_IO_OFFSET) < 80) {
            gExcursionZeroIin = n_Err;
            gExcursionZeroIout = m_Err;
            gPSM_FAULT.bit.excu = 0;
            gPSM_STA.bit.RDY = 1;
        } else if ((excursion_ErrCnt++) > 5) {
            excursion_ErrCnt = 0;
            excursion_count = 0;
            gPSM_FAULT.bit.excu = 1;
            gPSM_STA.bit.RDY = 0;
        }
    }
}

/* Temperature calculation using NTC lookup table */
static float f_MosTempDeal(void)
{
    static const float NTC_Table[][2] = {
        {25, 10.0}, {30, 8.047}, {35, 6.523}, {40, 5.318},
        {45, 4.357}, {50, 3.588}, {55, 2.968}, {60, 2.466},
        {65, 2.058}, {70, 1.725}, {75, 1.452}, {80, 1.228}
    };

    float f_adc_ntc = gAdcSampleBuf[2] & 0xFFFF;
    float f_v_ntc = f_adc_ntc / 4095.0f * 3.30f;
    float f_r_ntc = 33.0f / f_v_ntc - 10.0f;

    static float m_filter_sum = 0;
    static float m_filter_temp = 25.0f;

    // Simple linear interpolation for temperature
    for (int i = 1; i < 12; i++) {
        if (f_r_ntc > NTC_Table[i][1]) {
            float x1 = NTC_Table[i-1][1];
            float y1 = NTC_Table[i-1][0];
            float x2 = NTC_Table[i][1];
            float y2 = NTC_Table[i][0];

            m_filter_temp = ((y2 - y1) * (f_r_ntc - x1)) / (x2 - x1) + y1;
            break;
        }
    }

    m_filter_sum += m_filter_temp - m_filter_sum / 2.0f;
    return gDegTempMos = m_filter_sum / 2.0f;
}

static float f_GetMosTemp(void)
{
    return gDegTempMos;
}

/* MPPT Algorithm - Simplified Perturb and Observe */
static float tsFuzzyNNGsaMppt(float pv_v, float pv_i, rt_uint8_t mppt_enable)
{
    static float pv_ref = 0;
    static float prev_power = 0;
    static float prev_voltage = 0;
    static rt_uint8_t mppt_direction = 1;

    float current_power = pv_v * pv_i;

    if (mppt_enable == 0) {
        pv_ref = 0.8f * pv_v;
        prev_power = current_power;
        prev_voltage = pv_v;
        return pv_ref;
    }

    // Simple P&O MPPT algorithm
    if (current_power > prev_power) {
        if (pv_v > prev_voltage) {
            mppt_direction = 1; // Increase voltage
        } else {
            mppt_direction = 0; // Decrease voltage
        }
    } else {
        if (pv_v > prev_voltage) {
            mppt_direction = 0; // Decrease voltage
        } else {
            mppt_direction = 1; // Increase voltage
        }
    }

    float step = INITIAL_ALPHA;
    if (mppt_direction) {
        pv_ref = pv_v + step;
    } else {
        pv_ref = pv_v - step;
    }

    // Limit reference voltage
    if (pv_ref < 10.0f) pv_ref = 15.0f;
    if (pv_ref > 50.0f) pv_ref = 50.0f;

    prev_power = current_power;
    prev_voltage = pv_v;

    return pv_ref;
}

static float dpMpptPoCtr(float vin, float iin, rt_uint8_t enable)
{
    return tsFuzzyNNGsaMppt(vin, iin, enable);
}

/* PWM update function */
static void update_pwm_duty(float duty_cycle)
{
#ifdef RT_USING_PWM
    if (pwm_dev != RT_NULL) {
        rt_uint32_t period = 1000000000 / DP_PWM_FREQUENCY; // Period in ns
        rt_uint32_t pulse = (rt_uint32_t)(period * duty_cycle / DP_PWM_PER);
        rt_pwm_set(pwm_dev, 1, period, pulse);
    }
#endif
}

/* Power control main function */
static void dp_PowerCmcCtrl(void)
{
    static rt_uint16_t oocp_timecount = 0;
    static rt_uint16_t oovp_timecount = 0;
    static rt_uint16_t iocp_timecount = 0;
    static rt_uint16_t iovp_timecount = 0;
    static rt_uint16_t uvp_timecount = 0;
    static rt_uint32_t m_loop_count = 0;
    static float m_pwm_cmp;

    float k;
    float m_iout_ref;

    // Simulate ADC reading (in real implementation, read from actual ADC)
    gAdcSampleBuf[0] = 2048 + (rt_uint32_t)(gVoltInStr.Value * 100);
    gAdcSampleBuf[1] = 2048 + (rt_uint32_t)(gCurrInStr.Value * 100);
    gAdcSampleBuf[2] = 2048;

    float gAdcIiSampleValue = (rt_uint16_t)(gAdcSampleBuf[0] & 0xFFFF) - gExcursionZeroIin;
    float gAdcIoSampleValue = (rt_uint16_t)(gAdcSampleBuf[1] & 0xFFFF) - gExcursionZeroIout;
    float gAdcVoSampleValue = (rt_uint16_t)(gAdcSampleBuf[0] / 0xFFFF);
    float gAdcViSampleValue = (rt_uint16_t)(gAdcSampleBuf[1] / 0xFFFF);

    // Convert ADC values to actual voltage/current
    gLowFilter_ViFdb.Input = (gAdcViSampleValue * gVoltInStr.Coeff) + gVoltInStr.Offset;
    gLowFilter_VoFdb.Input = (gAdcVoSampleValue * gVoltOutStr.Coeff) + gVoltOutStr.Offset;
    gLowFilter_IiFdb.Input = (gAdcIiSampleValue * gCurrInStr.Coeff) + gCurrInStr.Offset;
    gLowFilter_IoFdb.Input = (gAdcIoSampleValue * gCurrOutStr.Coeff) + gCurrOutStr.Offset;

    // Apply filters
    low_filter_calc(&gLowFilter_ViFdb);
    low_filter_calc(&gLowFilter_IiFdb);
    low_filter_calc(&gLowFilter_VoFdb);
    low_filter_calc(&gLowFilter_IoFdb);

    gVoltOutStr.Value = gLowFilter_VoFdb.Output;
    gCurrOutStr.Value = gLowFilter_IoFdb.Output;
    gVoltInStr.Value = gLowFilter_ViFdb.Output;
    gCurrInStr.Value = gLowFilter_IiFdb.Output;

    // Fault detection - fixed sequence point warnings
    if (gVoltInStr.Value > DP_VOLTAGE_IN_MAX) {
        iovp_timecount++;
    } else {
        iovp_timecount = 0;
    }

    if (gVoltOutStr.Value > DP_VOLTAGE_OUT_MAX) {
        oovp_timecount++;
    } else {
        oovp_timecount = 0;
    }

    if (abs_float(gCurrInStr.Value) > DP_CURRENT_IN_MAX) {
        iocp_timecount++;
    } else {
        iocp_timecount = 0;
    }

    if (abs_float(gCurrOutStr.Value) > DP_CURRENT_OUT_MAX) {
        oocp_timecount++;
    } else {
        oocp_timecount = 0;
    }

    if (gVoltInStr.Value < DP_VOLTAGE_IN_MIN) {
        uvp_timecount++;
    } else {
        uvp_timecount = 0;
    }

    // System run status
    gPSM_STA.bit.RUN = !gPSM_STA.bit.FAUT && gPSM_STA.bit.RDY && gPSM_STA.bit.EN && gPSM_STA.bit.PWRUP;

    if (gPSM_STA.bit.RUN == 0) {
        // System stopped
        pid_clc(&gPID_VoltInLoop);
        pid_clc(&gPID_VoltOutLoop);
        pid_clc(&gPID_CurrOutLoop);

        k = gVoltOutStr.Value / gVoltInStr.Value;
        if (k > 1.70f) k = 1.70f;
        if (k < 0.01f) k = 0.01f;

        m_pwm_cmp = k * DP_PWM_PER;
        gPID_VoltOutLoop.Output = m_pwm_cmp;
        gPID_CurrOutLoop.Output = m_pwm_cmp;

        if (iv_received_flag == 0) {
            update_pwm_duty(m_pwm_cmp);
        } else {
            update_pwm_duty(GetIVbuckboost);
        }

        m_loop_count = 0;
        return;
    }

    // Voltage loop control (every 10th cycle)
    if ((m_loop_count++) % 10 == 0) {
        // Input voltage loop
        gPID_VoltInLoop.Ref = gVoltInStr.Value;
        gPID_VoltInLoop.Fdb = gMainCmd.ViRefSet;
        pid_calc(&gPID_VoltInLoop);

        // Output voltage loop
        gPID_VoltOutLoop.Ref = gMainCmd.VoRefSet;
        gPID_VoltOutLoop.Fdb = gVoltOutStr.Value;
        pid_calc(&gPID_VoltOutLoop);
    }

    m_iout_ref = min_float(gPID_VoltInLoop.Output, gPID_VoltOutLoop.Output);
    m_iout_ref = min_float(m_iout_ref, gMainCmd.IoRefSet);

    // Current loop control
    gPID_CurrOutLoop.Ref = m_iout_ref;
    gPID_CurrOutLoop.Fdb = gCurrOutStr.Value;
    pid_calc(&gPID_CurrOutLoop);

    m_pwm_cmp = gPID_CurrOutLoop.Output;

    if (iv_received_flag == 0) {
        update_pwm_duty(m_pwm_cmp);
    } else {
        update_pwm_duty(GetIVbuckboost);
    }
}

/* IV curve measurement */
static void GetIV_Line1(void)
{
    GetIVbuckboost_flag = 1;

    // Process current measurements
    dp_PowerCmcCtrl();

    g_sCurve.VoltOut[sampleIndex] = gVoltOutStr.Value;
    g_sCurve.CurrOut[sampleIndex] = gCurrOutStr.Value;
    g_sCurve.VoltIn[sampleIndex] = gVoltInStr.Value;
    g_sCurve.CurrIn[sampleIndex] = gCurrInStr.Value;
    sampleIndex += 1;

    GetIVbuckboost += 95;

    if (GetIVbuckboost >= 8600) {
        GetIVbuckboost = 100;
        GetIVbuckboost_flag = 0;
        sampleIndex = 0;

        for (int i = 0; i < 4; i++)
            direct[i] = 0;
    }
}

static void IVsend_data(void)
{
    rt_kprintf("ASTART,0,");
    for (rt_uint16_t i = 0; i < SCAN_RESOLUTION; i++) {
        rt_kprintf("%.2f,%.2f,", g_sCurve.VoltIn[i], g_sCurve.CurrIn[i]);
    }
    rt_kprintf("OVER\n");

    rt_thread_mdelay(200);
    iv_received_flag = 0;
}

/* System initialization */
static void dp_PowerCtrlInit(void)
{
    gPSM_FAULT.all = 0x00;
    gPSM_STA.all = 0x00;

    // Initialize voltage/current sensing calibration
    gVoltInStr.x1 = 14.87f; gVoltInStr.y1 = 15.00f;
    gVoltInStr.x2 = 47.76f; gVoltInStr.y2 = 48.00f;
    gVoltInStr.Coeff = DP_VOLTAGE_IN_RATIO;

    gCurrInStr.x1 = 0.27f; gCurrInStr.y1 = 0.25f;
    gCurrInStr.x2 = 5.22f; gCurrInStr.y2 = 5.03f;
    gCurrInStr.Coeff = DP_CURRENT_IN_RATIO;

    gVoltOutStr.x1 = 5.00f; gVoltOutStr.y1 = 5.04f;
    gVoltOutStr.x2 = 48.00f; gVoltOutStr.y2 = 48.36f;
    gVoltOutStr.Coeff = DP_VOLTAGE_OUT_RATIO;

    gCurrOutStr.x1 = 0.54f; gCurrOutStr.y1 = 0.50f;
    gCurrOutStr.x2 = 4.98f; gCurrOutStr.y2 = 4.83f;
    gCurrOutStr.Coeff = DP_CURRENT_OUT_RATIO;

    // Apply calibration
    dp_ElecLineCorr(&gVoltInStr);
    dp_ElecLineCorr(&gCurrInStr);
    dp_ElecLineCorr(&gVoltOutStr);
    dp_ElecLineCorr(&gCurrOutStr);

    // Initialize filters
    gLowFilter_IoFdb.Fc = 5e3; gLowFilter_IoFdb.Fs = 25e3;
    low_filter_init(&gLowFilter_IoFdb);

    gLowFilter_IiFdb.Fc = 5e3; gLowFilter_IiFdb.Fs = 25e3;
    low_filter_init(&gLowFilter_IiFdb);

    gLowFilter_ViFdb.Fc = 5e3; gLowFilter_ViFdb.Fs = 25e3;
    low_filter_init(&gLowFilter_ViFdb);

    gLowFilter_VoFdb.Fc = 5e3; gLowFilter_VoFdb.Fs = 25e3;
    low_filter_init(&gLowFilter_VoFdb);

    // Initialize PID controllers
    pid_reset(&gPID_VoltInLoop);
    gPID_VoltInLoop.T = 0.50f;
    gPID_VoltInLoop.Kp = 1.00f;
    gPID_VoltInLoop.Ti = 10.5f;
    gPID_VoltInLoop.Td = 0.01f;
    gPID_VoltInLoop.Ek_Dead = 0.01f;
    gPID_VoltInLoop.OutMin = -0.1f * DP_CURRENT_RATED;
    gPID_VoltInLoop.OutMax = +1.0f * DP_CURRENT_RATED;
    pid_init(&gPID_VoltInLoop);

    pid_reset(&gPID_VoltOutLoop);
    gPID_VoltOutLoop.T = 0.50f;
    gPID_VoltOutLoop.Kp = 1.0f;
    gPID_VoltOutLoop.Ti = 5.50f;
    gPID_VoltOutLoop.Td = 0.01f;
    gPID_VoltOutLoop.Ek_Dead = 0.01f;
    gPID_VoltOutLoop.OutMin = -0.1f * DP_CURRENT_RATED;
    gPID_VoltOutLoop.OutMax = +1.0f * DP_CURRENT_RATED;
    pid_init(&gPID_VoltOutLoop);

    pid_reset(&gPID_CurrOutLoop);
    gPID_CurrOutLoop.T = 0.40f;
    gPID_CurrOutLoop.Kp = 20.5f;
    gPID_CurrOutLoop.Ti = 0.50f;
    gPID_CurrOutLoop.Td = 0.01f;
    gPID_CurrOutLoop.Ek_Dead = 0.01f;
    gPID_CurrOutLoop.OutMin = 0.03f * DP_PWM_PER;
    gPID_CurrOutLoop.OutMax = 1.70f * DP_PWM_PER;
    pid_init(&gPID_CurrOutLoop);

    // Set default values
    gMainCmd.VoRefSet = gDefVoltageOutSet;
    gMainCmd.IoRefSet = gDefCurrentOutSet;
}

/* Task functions */
static void Task_05ms_A(void)
{
    static rt_uint32_t uTaskTimeCount = 0;
    static rt_uint32_t uShutdownDelay = 0;
    static rt_uint8_t l_new_run_cmd = 0;
    static rt_uint8_t l_old_run_cmd = 0;

    dp_ExcursionCheck();

    // MPPT calculation
    if (iv_received_flag == 0) {
        gMainCmd.ViRefSet = dpMpptPoCtr(gVoltInStr.Value, gCurrInStr.Value, gPSM_STA.bit.RUN);
    } else {
        gMainCmd.ViRefSet = dpMpptPoCtr(gVoltInStr.Value, gCurrInStr.Value, gPSM_STA.bit.RUN);
    }

    gMainCmd.VoRefSet = min_float(DP_VOLTAGE_RATED, gDefVoltageOutSet);
    gMainCmd.IoRefSet = min_float(DP_CURRENT_RATED, gDefCurrentOutSet);

    l_new_run_cmd = 1; // Simulate enable command

    if (l_new_run_cmd == 1) {
        uShutdownDelay = 0;
        if (gPSM_STA.bit.RDY == 0x01) {
            gPSM_STA.bit.EN = 0x01;
        }
    } else {
        gMainCmd.VoRefSet = 0;
        gMainCmd.IoRefSet = 0;
        if (uShutdownDelay > 100 || abs_float(gCurrOutStr.Value) < 0.10f) {
            gPSM_STA.bit.EN = 0x00;
        }
        uShutdownDelay++;
    }

    if (l_old_run_cmd == 1 && l_new_run_cmd == 0) {
        gPSM_FAULT.bit.excu = 0;
    }

    l_old_run_cmd = l_new_run_cmd;
    uTaskTimeCount++;
}

static void Task_05ms_B(void)
{
    static rt_uint32_t uTaskTimeCount = 0;

    if (iv_received_flag == 1) {
        GetIV_Line1();

        if (GetIVbuckboost_flag == 0) {
            IVsend_data();
        }
    }

    uTaskTimeCount++;
}

static void Task_05ms_C(void)
{
    static rt_uint32_t uTaskTimeCount = 0;
    uTaskTimeCount++;
}

static void Task_05ms_D(void)
{
    static rt_uint32_t uTaskTimeCount = 0;
    static rt_uint16_t uLedTimeCount = 0;

    if (uTaskTimeCount > 1000) gPSM_STA.bit.PWRUP = 0x01;

    f_MosTempDeal();

    if (f_GetMosTemp() > 65.0f) gPSM_FAULT.bit.motp = 0x01;
    if (f_GetMosTemp() < 55.0f) gPSM_FAULT.bit.motp = 0x00;

    // CC/CV mode detection
    if (abs_float(gMainCmd.IoRefSet - gCurrOutStr.Value) < 0.10f) {
        gPSM_STA.bit.CV = abs_float(gMainCmd.VoRefSet - gVoltOutStr.Value) < 0.10f ? 1 : 0;
        gPSM_STA.bit.CC = abs_float(gMainCmd.VoRefSet - gVoltOutStr.Value) > 0.10f ? 1 : 0;
    } else {
        gPSM_STA.bit.CV = 1;
        gPSM_STA.bit.CC = 0;
    }

    uLedTimeCount = uLedTimeCount > 1000 ? 0 : uLedTimeCount + 1;
    uTaskTimeCount++;
}

static void Task_1s(void)
{
    if (iv_received_flag == 0) {
        int vin, iin, vout, iout, temp, duty = 0;

        vin = gVoltInStr.Value * 100;
        iin = gCurrInStr.Value * 100;
        vout = gVoltOutStr.Value * 100;
        iout = gCurrOutStr.Value * 100;
        temp = f_GetMosTemp() * 100;
        if (vin > 0) duty = vout / vin * 10;

        switch (current_send_index) {
            case 0:
                rt_kprintf("S,3,1,%d,%d,%d,%d,T\n", (vin/1000)%10, (vin/100)%10, (vin/10)%10, vin%10);
                break;
            case 1:
                rt_kprintf("S,3,2,%d,%d,%d,%d,T\n", (iin/1000)%10, (iin/100)%10, (iin/10)%10, iin%10);
                break;
            case 2:
                rt_kprintf("S,3,3,%d,%d,%d,%d,T\n", (vout/1000)%10, (vout/100)%10, (vout/10)%10, vout%10);
                break;
            case 3:
                rt_kprintf("S,3,4,%d,%d,%d,%d,T\n", (iout/1000)%10, (iout/100)%10, (iout/10)%10, iout%10);
                break;
            case 4:
                rt_kprintf("S,3,5,%d,%d,%d,%d,T\n", (temp/1000)%10, (temp/100)%10, (temp/10)%10, temp%10);
                break;
            case 5:
                rt_kprintf("S,3,6,%d,%d,%d,%d,T\n", (duty/1000)%10, (duty/100)%10, (duty/10)%10, duty%10);
                break;
        }

        current_send_index = (current_send_index + 1) % 6;
    }
}

/* System tick timer callback */
static void systick_timer_callback(void *parameter)
{
    gSysTim01msTicks++;
}

/* Thread functions */
static void task_05ms_thread_entry(void *parameter)
{
    static rt_uint16_t task_id = 0;

    while (1) {
        if (gSysTim01msTicks >= gBaseTim05msTick) {
            gBaseTim05msTick += 5; // 5ms period

            switch (task_id) {
                case 0x00:
                    Task_05ms_A();
                    break;
                case 0x01:
                    Task_05ms_B();
                    break;
                case 0x02:
                    Task_05ms_C();
                    break;
                case 0x03:
                    Task_05ms_D();
                    break;
            }

            task_id = task_id >= 0x03 ? 0 : task_id + 1;
            gBaseTim1sTick++;

            if (gBaseTim1sTick >= 400 && iv_received_flag == 0) {
                Task_1s();
                gBaseTim1sTick = 0;
            }
        }

        rt_thread_mdelay(1);
    }
}

static void main_task_thread_entry(void *parameter)
{
    while (1) {
        // Main power control loop
        if (direct[1] == 3 && direct[2] == 2 && direct[3] != 0) {
            iv_received_flag = 1;
        } else {
            iv_received_flag = 0;
        }

        // Execute power control every 40us (25kHz)
        dp_PowerCmcCtrl();

        rt_thread_mdelay(1); // 1ms delay for main loop
    }
}

/* Device initialization */
static int device_init(void)
{
    // Initialize UART
    uart_dev = rt_device_find(UART_DEV_NAME);
    if (uart_dev != RT_NULL) {
        rt_device_open(uart_dev, RT_DEVICE_OFLAG_RDWR | RT_DEVICE_FLAG_INT_RX);
        rt_kprintf("UART device initialized\n");
    } else {
        rt_kprintf("Failed to find UART device\n");
    }

    // Initialize ADC
    adc_dev = rt_device_find(ADC_DEV_NAME);
    if (adc_dev != RT_NULL) {
        rt_device_open(adc_dev, RT_DEVICE_OFLAG_RDONLY);
        rt_kprintf("ADC device initialized\n");
    } else {
        rt_kprintf("Failed to find ADC device\n");
    }

#ifdef RT_USING_PWM
    // Initialize PWM
    pwm_dev = (struct rt_device_pwm *)rt_device_find(PWM_DEV_NAME);
    if (pwm_dev != RT_NULL) {
        rt_uint32_t period = 1000000000 / DP_PWM_FREQUENCY; // Period in ns
        rt_pwm_set(pwm_dev, 1, period, 0);
        rt_pwm_enable(pwm_dev, 1);
        rt_kprintf("PWM device initialized, period: %d ns\n", period);
    } else {
        rt_kprintf("Failed to find PWM device\n");
    }
#endif

    return RT_EOK;
}

int main(void)
{
    rt_kprintf("Power Control System Starting...\n");

    // Initialize devices
    device_init();

    // Initialize power control system
    dp_PowerCtrlInit();

    // Create system tick timer (1ms)
    systick_timer = rt_timer_create("systick",
                                   systick_timer_callback,
                                   RT_NULL,
                                   1, // 1ms
                                   RT_TIMER_FLAG_PERIODIC);
    if (systick_timer != RT_NULL) {
        rt_timer_start(systick_timer);
        rt_kprintf("System tick timer started\n");
    }

    // Create threads
    task_05ms_thread = rt_thread_create("task_05ms",
                                       task_05ms_thread_entry,
                                       RT_NULL,
                                       TASK_05MS_THREAD_STACK_SIZE,
                                       TASK_05MS_THREAD_PRIORITY,
                                       10);
    if (task_05ms_thread != RT_NULL) {
        rt_thread_startup(task_05ms_thread);
        rt_kprintf("05ms task thread created\n");
    }

    main_task_thread = rt_thread_create("main_task",
                                       main_task_thread_entry,
                                       RT_NULL,
                                       MAIN_THREAD_STACK_SIZE,
                                       MAIN_THREAD_PRIORITY,
                                       20);
    if (main_task_thread != RT_NULL) {
        rt_thread_startup(main_task_thread);
        rt_kprintf("Main task thread created\n");
    }

    // Initialize system status
    gPSM_STA.bit.PWRUP = 1;
    gPSM_STA.bit.RDY = 1;
    gPSM_STA.bit.EN = 1;

    rt_kprintf("Power Control System Initialized Successfully\n");

    return RT_EOK;
}
