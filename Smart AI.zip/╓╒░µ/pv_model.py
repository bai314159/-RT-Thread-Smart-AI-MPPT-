# Enhanced PV Diagnostic Model
# 增强版光伏诊断模型 - 完整封装版本

import json
import math
import time
import sys
import gc


class Array:
    """数组操作工具类，提供类似NumPy的基础功能"""

    @staticmethod
    def zeros(shape):
        """创建指定形状的零数组"""
        if isinstance(shape, tuple) and len(shape) > 1:
            rows, cols = shape
            return [[0.0 for _ in range(cols)] for _ in range(rows)]
        else:
            return [0.0 for _ in range(shape)]

    @staticmethod
    def array(data):
        """将数据转换为数组"""
        return data

    @staticmethod
    def argmax(arr, axis=None):
        """返回数组中最大值的索引"""
        if axis == 1:
            result = []
            for row in arr:
                max_idx = 0
                max_val = row[0]
                for i, val in enumerate(row):
                    if val > max_val:
                        max_val = val
                        max_idx = i
                result.append(max_idx)
            return result
        else:
            max_idx = 0
            max_val = arr[0]
            for i, val in enumerate(arr):
                if val > max_val:
                    max_val = val
                    max_idx = i
            return max_idx

    @staticmethod
    def max(arr, axis=None):
        """返回数组中的最大值"""
        if axis == 1:
            return [max(row) for row in arr]
        else:
            return max([max(row) if isinstance(row, list) else row for row in arr])

    @staticmethod
    def mean(arr, axis=None):
        """计算数组的平均值"""
        if axis == 1:
            return [sum(row) / len(row) for row in arr]
        else:
            if isinstance(arr[0], list):
                flat_arr = [item for sublist in arr for item in sublist]
                return sum(flat_arr) / len(flat_arr)
            else:
                return sum(arr) / len(arr)

    @staticmethod
    def std(arr, axis=None):
        """计算数组的标准差"""
        if axis == 1:
            means = Array.mean(arr, axis=1)
            return [math.sqrt(sum((x - means[i]) ** 2 for x in row) / len(row))
                    for i, row in enumerate(arr)]
        else:
            if isinstance(arr[0], list):
                flat_arr = [item for sublist in arr for item in sublist]
                mean = sum(flat_arr) / len(flat_arr)
                return math.sqrt(sum((x - mean) ** 2 for x in flat_arr) / len(flat_arr))
            else:
                mean = sum(arr) / len(arr)
                return math.sqrt(sum((x - mean) ** 2 for x in arr) / len(arr))

    @staticmethod
    def column_stack(arrays):
        """将多个数组按列堆叠"""
        result = []
        for i in range(len(arrays[0])):
            row = []
            for arr in arrays:
                if isinstance(arr[i], list):
                    row.extend(arr[i])
                else:
                    row.append(arr[i])
            result.append(row)
        return result

    @staticmethod
    def diff(arr, axis=1):
        """计算数组沿指定轴的差分"""
        result = []
        for row in arr:
            diff_row = []
            for i in range(1, len(row)):
                diff_row.append(row[i] - row[i - 1])
            result.append(diff_row)
        return result

    @staticmethod
    def nan_to_num(arr):
        """将数组中的NaN和Inf替换为0"""
        if isinstance(arr[0], list):
            return [[0.0 if not isinstance(x, (int, float)) or math.isnan(x) or math.isinf(x) else x
                     for x in row] for row in arr]
        else:
            return [0.0 if not isinstance(x, (int, float)) or math.isnan(x) or math.isinf(x) else x
                    for x in arr]


class SignalProcessor:
    """信号处理工具类 - 优化版"""

    @staticmethod
    def simple_fft(x):
        """简化版的FFT实现 - 优化性能"""
        n = len(x)
        if n <= 1:
            return x
        
        # 限制FFT计算规模以提高性能
        if n > 64:
            x = x[:64]
            n = 64

        try:
            # 递归计算
            even = SignalProcessor.simple_fft(x[0::2])
            odd = SignalProcessor.simple_fft(x[1::2])

            # 合并结果
            result = [0] * n
            for k in range(n // 2):
                t = odd[k] * math.cos(-2 * math.pi * k / n)
                result[k] = even[k] + t
                result[k + n // 2] = even[k] - t

            return result
        except Exception as e:
            print(f"FFT计算错误: {e}")
            return [0] * n

    @staticmethod
    def fft_magnitude(x):
        """计算FFT的幅度"""
        try:
            fft_result = SignalProcessor.simple_fft(x)
            return [abs(val) if isinstance(val, (int, float)) else 0 for val in fft_result]
        except Exception as e:
            print(f"FFT幅度计算错误: {e}")
            return [0] * len(x)


class FeatureExtractor:
    """特征提取类，从IV曲线数据中提取特征 - 增强版"""

    @staticmethod
    def label_mapping(label):
        """将文本标签映射为数字"""
        label_dict = {'normal': 0, 'short': 1, 'open': 2, 'shelter': 3, 'old': 4}
        return label_dict.get(label, -1)

    @staticmethod
    def reverse_label_mapping(label_id):
        """将数字标签映射回文本"""
        label_list = ['normal', 'short', 'open', 'shelter', 'old']
        if 0 <= label_id < len(label_list):
            return label_list[label_id]
        return 'unknown'

    @staticmethod
    def validate_data(data):
        """验证和预处理输入数据"""
        if not data:
            print("警告: 输入数据为空")
            return [[0.0] * 160]
        
        # 确保数据是列表格式
        if isinstance(data, str):
            try:
                parsed_data = []
                for part in data.split(','):
                    try:
                        parsed_data.append(float(part.strip()))
                    except ValueError:
                        parsed_data.append(0.0)
                data = [parsed_data]
            except Exception as e:
                print(f"数据解析错误: {e}")
                return [[0.0] * 160]
        elif not isinstance(data[0], list):
            data = [data]
        
        # 验证数据长度
        expected_length = 160
        validated_data = []
        
        for i, sample in enumerate(data):
            if len(sample) != expected_length:
                print(f"警告: 样本 {i} 长度 {len(sample)} 不符合预期长度 {expected_length}")
                if len(sample) < expected_length:
                    # 补零
                    sample = sample + [0.0] * (expected_length - len(sample))
                else:
                    # 截断
                    sample = sample[:expected_length]
            
            # 确保所有值都是数字
            validated_sample = []
            for val in sample:
                if isinstance(val, (int, float)) and not (math.isnan(val) or math.isinf(val)):
                    validated_sample.append(float(val))
                else:
                    validated_sample.append(0.0)
            
            validated_data.append(validated_sample)
        
        return validated_data

    @staticmethod
    def advanced_feature_extraction(data):
        """从IV曲线数据中提取高级特征 - 增强版"""
        try:
            # 数据验证和预处理
            data = FeatureExtractor.validate_data(data)
            n_samples = len(data)
            
            if n_samples == 0:
                print("错误: 验证后数据仍为空")
                return [[0.0] * 34]

            print(f"开始特征提取，样本数: {n_samples}")

            # 分离电压和电流数据
            voltages = Array.zeros((n_samples, 80))
            currents = Array.zeros((n_samples, 80))

            for i in range(80):
                for j in range(n_samples):
                    try:
                        voltages[j][i] = data[j][2 * i] if 2 * i < len(data[j]) else 0.0
                        currents[j][i] = data[j][2 * i + 1] if 2 * i + 1 < len(data[j]) else 0.0
                    except (IndexError, TypeError):
                        voltages[j][i] = 0.0
                        currents[j][i] = 0.0

            # 计算功率曲线
            power = []
            for i in range(n_samples):
                power_row = []
                for j in range(80):
                    try:
                        p = voltages[i][j] * currents[i][j]
                        power_row.append(p if isinstance(p, (int, float)) and not math.isnan(p) else 0.0)
                    except:
                        power_row.append(0.0)
                power.append(power_row)

            # 提取基础特征
            print("提取基础IV特征...")
            
            # 1. 最大功率点特征
            max_power_idx = Array.argmax(power, axis=1)
            max_power = Array.max(power, axis=1)

            v_mpp = []
            i_mpp = []
            for i in range(n_samples):
                try:
                    idx = max_power_idx[i] if isinstance(max_power_idx[i], int) else 0
                    idx = max(0, min(idx, len(voltages[i]) - 1))
                    v_mpp.append(voltages[i][idx])
                    i_mpp.append(currents[i][idx])
                except:
                    v_mpp.append(0.0)
                    i_mpp.append(0.0)

            # 2. 开路电压和短路电流
            v_oc = Array.max(voltages, axis=1)
            i_sc = Array.max(currents, axis=1)

            # 3. 填充因子
            ff = []
            for i in range(n_samples):
                try:
                    v_oc_val = v_oc[i] if v_oc[i] > 1e-10 else 1e-10
                    i_sc_val = i_sc[i] if i_sc[i] > 1e-10 else 1e-10
                    ff_val = max_power[i] / (v_oc_val * i_sc_val)
                    ff.append(ff_val if isinstance(ff_val, (int, float)) and not math.isnan(ff_val) else 0.0)
                except:
                    ff.append(0.0)

            # 4. IV曲线形状特征
            print("计算曲线形状特征...")
            try:
                v_diff = Array.diff(voltages)
                i_diff = Array.diff(currents)

                slopes = []
                for i in range(n_samples):
                    slope_row = []
                    for j in range(len(v_diff[i])):
                        try:
                            v_diff_val = v_diff[i][j] if abs(v_diff[i][j]) > 1e-10 else 1e-10
                            slope = i_diff[i][j] / v_diff_val
                            slope_row.append(slope if isinstance(slope, (int, float)) and not math.isnan(slope) else 0.0)
                        except:
                            slope_row.append(0.0)
                    slopes.append(slope_row if slope_row else [0.0])

                # 计算斜率统计特征
                slope_mean = Array.mean(slopes, axis=1)
                slope_std = Array.std(slopes, axis=1)

                slope_max = []
                slope_min = []
                for row in slopes:
                    if row and len(row) > 0:
                        valid_values = [x for x in row if isinstance(x, (int, float)) and not math.isnan(x)]
                        if valid_values:
                            slope_max.append(max(valid_values))
                            slope_min.append(min(valid_values))
                        else:
                            slope_max.append(0.0)
                            slope_min.append(0.0)
                    else:
                        slope_max.append(0.0)
                        slope_min.append(0.0)
            except Exception as e:
                print(f"斜率特征计算错误: {e}")
                slope_mean = [0.0] * n_samples
                slope_std = [0.0] * n_samples
                slope_max = [0.0] * n_samples
                slope_min = [0.0] * n_samples

            # 5. 功率曲线特征
            print("计算功率特征...")
            p_std = Array.std(power, axis=1)
            p_mean = Array.mean(power, axis=1)

            p_range = []
            for row in power:
                if row and len(row) > 0:
                    valid_values = [x for x in row if isinstance(x, (int, float)) and not math.isnan(x)]
                    if valid_values:
                        p_range.append(max(valid_values) - min(valid_values))
                    else:
                        p_range.append(0.0)
                else:
                    p_range.append(0.0)

            # 6. 功率与电压的比值特征
            p_v_ratio = []
            for i in range(n_samples):
                try:
                    v_mpp_val = v_mpp[i] if v_mpp[i] > 1e-10 else 1e-10
                    ratio = max_power[i] / v_mpp_val
                    p_v_ratio.append(ratio if isinstance(ratio, (int, float)) and not math.isnan(ratio) else 0.0)
                except:
                    p_v_ratio.append(0.0)

            # 组合基础特征
            print("组合特征...")
            try:
                feature_list = [
                    max_power, v_mpp, i_mpp,
                    v_oc, i_sc, ff,
                    slope_mean, slope_std, slope_max, slope_min,
                    p_std, p_mean, p_range, p_v_ratio
                ]

                combined_features = Array.column_stack(feature_list)
            except Exception as e:
                print(f"特征组合错误: {e}")
                # 创建默认特征
                combined_features = [[0.0] * 14 for _ in range(n_samples)]

            # 7. 简化版FFT特征（可选）
            print("计算频域特征...")
            try:
                fft_features = []
                for i in range(n_samples):
                    # 只对前32个点计算FFT以提高性能
                    v_sample = voltages[i][:32]
                    i_sample = currents[i][:32]
                    
                    v_fft = SignalProcessor.fft_magnitude(v_sample)
                    i_fft = SignalProcessor.fft_magnitude(i_sample)
                    
                    # 取前10个频率分量
                    v_fft_selected = v_fft[1:11] if len(v_fft) >= 11 else (v_fft[1:] + [0.0] * (10 - len(v_fft) + 1))
                    i_fft_selected = i_fft[1:11] if len(i_fft) >= 11 else (i_fft[1:] + [0.0] * (10 - len(i_fft) + 1))
                    
                    fft_row = v_fft_selected + i_fft_selected
                    fft_features.append(fft_row)

                # 合并所有特征
                final_features = []
                for i in range(n_samples):
                    feature_row = combined_features[i] + fft_features[i]
                    final_features.append(feature_row)
                    
            except Exception as e:
                print(f"FFT特征计算错误: {e}")
                # 使用基本特征
                final_features = combined_features

            # 最终清理和验证
            final_features = Array.nan_to_num(final_features)
            
            print(f"特征提取完成，特征维度: {len(final_features[0]) if final_features else 0}")
            return final_features

        except Exception as e:
            print(f"特征提取总体错误: {e}")
            import sys
            sys.print_exception(e)
            # 返回默认特征
            return [[0.0] * 34]


class ModelManager:
    """模型管理类，负责模型的加载和预测 - 增强版"""

    def __init__(self):
        """初始化模型管理器"""
        self._models_initialized = False
        self._scaler_params = None
        self._imputer_params = None
        self._svm_params = None
        self._rf_params = None
        self._mlp_params = None
        self._error_counter = 0
        self._max_errors = 5  # 增加最大错误次数
        self._last_prediction_time = 0
        
        # 性能监控
        self.performance_stats = {
            'total_predictions': 0,
            'successful_predictions': 0,
            'failed_predictions': 0,
            'avg_prediction_time': 0,
            'model_reload_count': 0
        }

    def load_model_params(self, model_dir='/sdcard'):
        """从JSON文件加载模型参数 - 增强版"""
        files_to_load = [
            (f'{model_dir}/model/scaler_params.json', '_scaler_params'),
            (f'{model_dir}/model/imputer_params.json', '_imputer_params'),
            (f'{model_dir}/model/svm_params.json', '_svm_params'),
            (f'{model_dir}/model/rf_params.json', '_rf_params'),
            (f'{model_dir}/model/mlp_params.json', '_mlp_params')
        ]

        # 检查文件是否存在
        import os
        missing_files = []
        for file_path, _ in files_to_load:
            try:
                os.stat(file_path)
            except OSError:
                missing_files.append(file_path)

        if missing_files:
            print("缺少以下模型参数文件:")
            for file in missing_files:
                print(f"  - {file}")
            return False

        # 加载文件
        try:
            for file_path, param_name in files_to_load:
                print(f"加载: {file_path}")
                try:
                    with open(file_path, 'r') as f:
                        data = json.load(f)
                        setattr(self, param_name, data)
                        print(f"  ✓ 成功加载 {param_name}")
                except Exception as e:
                    print(f"  ✗ 加载失败 {param_name}: {e}")
                    return False

            self._models_initialized = True
            self.performance_stats['model_reload_count'] += 1
            print("所有模型参数加载成功!")
            return True
            
        except Exception as e:
            print(f"模型参数加载总体错误: {e}")
            return False

    def apply_imputer(self, X):
        """应用均值填充 - 增强版"""
        if not self._models_initialized or not self._imputer_params:
            return X

        try:
            X_imputed = []
            means = self._imputer_params.get('mean', [])

            for row in X:
                imputed_row = []
                for i, val in enumerate(row):
                    if i >= len(means):
                        imputed_row.append(0.0)
                    elif not isinstance(val, (int, float)) or math.isnan(val) or math.isinf(val):
                        imputed_row.append(means[i] if i < len(means) else 0.0)
                    else:
                        imputed_row.append(float(val))
                X_imputed.append(imputed_row)

            return X_imputed
        except Exception as e:
            print(f"均值填充错误: {e}")
            return X

    def apply_scaler(self, X):
        """应用标准化 - 增强版"""
        if not self._models_initialized or not self._scaler_params:
            return X

        try:
            X_scaled = []
            means = self._scaler_params.get('mean', [])
            scales = self._scaler_params.get('scale', [])

            for row in X:
                scaled_row = []
                for i, val in enumerate(row):
                    if i >= len(means) or i >= len(scales):
                        scaled_row.append(0.0)
                    else:
                        scale = scales[i] if scales[i] != 0 else 1.0
                        mean = means[i]
                        scaled_val = (val - mean) / scale
                        if isinstance(scaled_val, (int, float)) and not (math.isnan(scaled_val) or math.isinf(scaled_val)):
                            scaled_row.append(scaled_val)
                        else:
                            scaled_row.append(0.0)
                X_scaled.append(scaled_row)

            return X_scaled
        except Exception as e:
            print(f"标准化错误: {e}")
            return X

    def rbf_kernel(self, X, Y, gamma):
        """计算RBF核函数 - 优化版"""
        try:
            result = []
            for x in X:
                row = []
                for y in Y:
                    sqr_dist = 0
                    min_len = min(len(x), len(y))
                    for i in range(min_len):
                        diff = x[i] - y[i]
                        sqr_dist += diff * diff
                    
                    kernel_val = math.exp(-gamma * sqr_dist)
                    row.append(kernel_val if isinstance(kernel_val, (int, float)) and not math.isnan(kernel_val) else 0.0)
                result.append(row)
            return result
        except Exception as e:
            print(f"RBF核函数计算错误: {e}")
            return [[1.0] * len(Y) for _ in range(len(X))]

    def predict_svm(self, X):
        """使用SVM模型进行预测 - 增强版"""
        if not self._models_initialized or not self._svm_params:
            print("SVM模型未初始化")
            return [0] * len(X)

        try:
            support_vectors = self._svm_params.get('support_vectors', [])
            dual_coef = self._svm_params.get('dual_coef', [])
            intercept = self._svm_params.get('intercept', [])
            gamma = self._svm_params.get('gamma', 1.0)
            classes = self._svm_params.get('classes', [0, 1, 2, 3, 4])

            if not support_vectors or not dual_coef or not intercept:
                print("SVM参数不完整")
                return [0] * len(X)

            kernel_matrix = self.rbf_kernel(X, support_vectors, gamma)

            decisions = []
            for i in range(len(X)):
                try:
                    # 简化的决策逻辑
                    decision_values = []
                    n_classes = len(classes)

                    # 计算决策值
                    for j in range(min(len(intercept), n_classes - 1)):
                        decision_value = intercept[j] if j < len(intercept) else 0.0
                        
                        # 添加支持向量贡献
                        if j < len(dual_coef) and isinstance(dual_coef[j], list):
                            for sv_idx in range(min(len(support_vectors), len(dual_coef[j]))):
                                if sv_idx < len(kernel_matrix[i]):
                                    decision_value += dual_coef[j][sv_idx] * kernel_matrix[i][sv_idx]
                        
                        decision_values.append(decision_value)

                    # 投票决定类别
                    if decision_values:
                        max_decision = max(decision_values)
                        predicted_class = decision_values.index(max_decision)
                        predicted_class = min(predicted_class, len(classes) - 1)
                        decisions.append(classes[predicted_class])
                    else:
                        decisions.append(classes[0])

                except Exception as inner_e:
                    print(f"SVM单样本预测错误: {inner_e}")
                    decisions.append(classes[0])

            return decisions

        except Exception as e:
            print(f"SVM预测总体错误: {e}")
            return [0] * len(X)

    def predict_tree(self, X, tree):
        """使用决策树进行预测 - 增强版"""
        try:
            predictions = []

            for sample in X:
                try:
                    node_id = 0
                    max_depth = 50  # 防止无限循环

                    for depth in range(max_depth):
                        if (tree.get('children_left', {}).get(node_id, -1) == -1 or 
                            tree.get('children_right', {}).get(node_id, -1) == -1):
                            # 叶子节点
                            leaf_value = tree.get('value', {}).get(node_id, [1.0, 0.0, 0.0, 0.0, 0.0])
                            predictions.append(leaf_value)
                            break

                        feature_idx = tree.get('feature', {}).get(node_id, -1)
                        threshold = tree.get('threshold', {}).get(node_id, 0.0)

                        if feature_idx < 0 or feature_idx >= len(sample):
                            node_id = tree.get('children_left', {}).get(node_id, 0)
                        else:
                            if sample[feature_idx] <= threshold:
                                node_id = tree.get('children_left', {}).get(node_id, 0)
                            else:
                                node_id = tree.get('children_right', {}).get(node_id, 0)
                    else:
                        # 达到最大深度
                        predictions.append([1.0, 0.0, 0.0, 0.0, 0.0])

                except Exception as inner_e:
                    print(f"决策树单样本预测错误: {inner_e}")
                    predictions.append([1.0, 0.0, 0.0, 0.0, 0.0])

            return predictions
        except Exception as e:
            print(f"决策树预测错误: {e}")
            return [[1.0, 0.0, 0.0, 0.0, 0.0]] * len(X)

    def predict_rf(self, X):
        """使用随机森林模型进行预测 - 增强版"""
        if not self._models_initialized or not self._rf_params:
            print("随机森林模型未初始化")
            return [0] * len(X)

        try:
            trees = self._rf_params.get('trees', [])
            classes = self._rf_params.get('classes', [0, 1, 2, 3, 4])
            n_classes = self._rf_params.get('n_classes', 5)

            if not trees:
                print("随机森林无树结构")
                return [0] * len(X)

            all_predictions = []

            # 预测每棵树
            for tree_idx, tree in enumerate(trees):
                try:
                    tree_preds = self.predict_tree(X, tree)
                    all_predictions.append(tree_preds)
                except Exception as tree_e:
                    print(f"随机森林第{tree_idx}棵树预测错误: {tree_e}")
                    # 添加默认预测
                    all_predictions.append([[1.0, 0.0, 0.0, 0.0, 0.0]] * len(X))

            # 投票决定最终结果
            final_preds = []
            for i in range(len(X)):
                votes = [0] * n_classes

                for tree_idx in range(len(all_predictions)):
                    if tree_idx < len(all_predictions) and i < len(all_predictions[tree_idx]):
                        tree_pred = all_predictions[tree_idx][i]
                        if tree_pred and len(tree_pred) > 0:
                            # 找到最大概率的类别
                            max_class = 0
                            max_prob = tree_pred[0]

                            for class_idx in range(min(n_classes, len(tree_pred))):
                                if tree_pred[class_idx] > max_prob:
                                    max_prob = tree_pred[class_idx]
                                    max_class = class_idx

                            votes[max_class] += 1

                # 确定最终预测
                max_votes = max(votes) if votes else 0
                predicted_class = votes.index(max_votes) if max_votes > 0 else 0
                predicted_class = min(predicted_class, len(classes) - 1)

                final_preds.append(classes[predicted_class])

            return final_preds

        except Exception as e:
            print(f"随机森林预测错误: {e}")
            return [0] * len(X)

    def relu(self, x):
        """ReLU激活函数"""
        try:
            return max(0, x) if isinstance(x, (int, float)) and not math.isnan(x) else 0
        except:
            return 0

    def predict_mlp(self, X):
        """使用MLP模型进行预测 - 增强版"""
        if not self._models_initialized or not self._mlp_params:
            print("MLP模型未初始化")
            return [0] * len(X)

        try:
            coefs = self._mlp_params.get('coefs', [])
            intercepts = self._mlp_params.get('intercepts', [])
            classes = self._mlp_params.get('classes', [0, 1, 2, 3, 4])
            activation = self._mlp_params.get('activation', 'relu')

            if not coefs or not intercepts:
                print("MLP参数不完整")
                return [0] * len(X)

            predictions = []
            for sample in X:
                try:
                    activations = [sample]

                    # 前向传播
                    for layer_idx in range(len(coefs)):
                        if layer_idx >= len(intercepts):
                            break
                            
                        layer_coef = coefs[layer_idx]
                        layer_intercept = intercepts[layer_idx]

                        if not layer_coef or not layer_intercept:
                            continue

                        output = []
                        for j in range(len(layer_intercept)):
                            value = layer_intercept[j]
                            
                            # 计算加权和
                            for k in range(min(len(activations[-1]), len(layer_coef))):
                                if k < len(layer_coef) and j < len(layer_coef[k]):
                                    value += activations[-1][k] * layer_coef[k][j]

                            # 应用激活函数
                            if layer_idx < len(coefs) - 1 and activation == 'relu':
                                value = self.relu(value)

                            output.append(value)

                        activations.append(output)

                    # 应用softmax到最后一层
                    if activations[-1]:
                        try:
                            # 数值稳定的softmax
                            max_val = max(activations[-1])
                            exp_values = []
                            for val in activations[-1]:
                                exp_val = math.exp(min(val - max_val, 50))  # 防止溢出
                                exp_values.append(exp_val)

                            sum_exp = sum(exp_values) if exp_values else 1e-10
                            if sum_exp == 0:
                                sum_exp = 1e-10

                            softmax = [val / sum_exp for val in exp_values]
                        except Exception as softmax_e:
                            print(f"Softmax计算错误: {softmax_e}")
                            softmax = [1.0] + [0.0] * (len(classes) - 1)

                        # 找到最大概率的类别
                        max_prob = max(softmax) if softmax else 0
                        predicted_class = softmax.index(max_prob) if max_prob > 0 else 0
                        predicted_class = min(predicted_class, len(classes) - 1)

                        predictions.append(classes[predicted_class])
                    else:
                        predictions.append(classes[0])

                except Exception as sample_e:
                    print(f"MLP单样本预测错误: {sample_e}")
                    predictions.append(classes[0])

            return predictions

        except Exception as e:
            print(f"MLP预测错误: {e}")
            return [0] * len(X)

    def predict(self, data, mode='voting', model_dir='.'):
        """预测PV面板状态 - 增强版"""
        start_time = time.ticks_ms()
        labels = ['normal', 'short', 'open', 'shelter', 'old']

        try:
            self.performance_stats['total_predictions'] += 1
            
            # 检查模型初始化状态
            if not self._models_initialized:
                print("模型未初始化，尝试加载...")
                init_success = self.load_model_params(model_dir)
                if not init_success:
                    print("模型加载失败，返回默认结果")
                    self.performance_stats['failed_predictions'] += 1
                    return 'normal', {'normal': 1.0, 'short': 0.0, 'open': 0.0, 'shelter': 0.0, 'old': 0.0}

            # 数据预处理
            print("开始数据预处理...")
            
            if isinstance(data, str):
                try:
                    parsed_data = []
                    for part in data.split(','):
                        try:
                            parsed_data.append(float(part.strip()))
                        except ValueError:
                            parsed_data.append(0.0)
                    data = parsed_data
                except Exception as parse_error:
                    print(f"数据解析错误: {parse_error}")
                    data = [0.0] * 160

            # 确保数据长度正确
            if len(data) < 160:
                data = data + [0.0] * (160 - len(data))
            elif len(data) > 160:
                data = data[:160]

            sample_data = [data]

            # 提取特征
            print("开始特征提取...")
            X = FeatureExtractor.advanced_feature_extraction(sample_data)
            if not X or len(X) == 0:
                raise ValueError("特征提取失败")

            # 应用预处理
            print("应用数据预处理...")
            X_imputed = self.apply_imputer(X)
            X_scaled = self.apply_scaler(X_imputed)

            # 执行预测
            print(f"开始预测，模式: {mode}")
            predictions = None
            
            try:
                if mode == 'svm':
                    predictions = self.predict_svm(X_scaled)
                elif mode == 'rf':
                    predictions = self.predict_rf(X_scaled)
                elif mode == 'mlp':
                    predictions = self.predict_mlp(X_scaled)
                else:  # 投票模式
                    print("执行投票预测...")
                    svm_pred = self.predict_svm(X_scaled)
                    rf_pred = self.predict_rf(X_scaled)
                    mlp_pred = self.predict_mlp(X_scaled)

                    print(f"SVM预测: {svm_pred[0] if svm_pred else 'None'}")
                    print(f"RF预测: {rf_pred[0] if rf_pred else 'None'}")
                    print(f"MLP预测: {mlp_pred[0] if mlp_pred else 'None'}")

                    if not svm_pred or not rf_pred or not mlp_pred:
                        raise ValueError("某个模型预测失败")

                    # 投票决定最终结果
                    votes = {}
                    for pred in [svm_pred[0], rf_pred[0], mlp_pred[0]]:
                        votes[pred] = votes.get(pred, 0) + 1

                    max_votes = max(votes.values()) if votes else 0
                    predictions = [0]  # 默认值

                    for class_id, vote_count in votes.items():
                        if vote_count == max_votes:
                            predictions = [class_id]
                            break

            except Exception as model_error:
                print(f"模型预测错误: {model_error}")
                predictions = [0]
                self._error_counter += 1

            # 处理预测结果
            if predictions and predictions[0] is not None:
                self._error_counter = 0
                self.performance_stats['successful_predictions'] += 1
            else:
                self.performance_stats['failed_predictions'] += 1

            # 检查错误次数
            if self._error_counter >= self._max_errors:
                print(f"连续 {self._max_errors} 次预测错误，重新加载模型")
                self._models_initialized = False
                self.load_model_params(model_dir)
                self._error_counter = 0
                predictions = [0]

            # 生成最终结果
            pred_class = int(predictions[0]) if predictions and isinstance(predictions[0], (int, float)) else 0
            pred_class = max(0, min(pred_class, len(labels) - 1))

            pred_class_name = labels[pred_class]

            # 生成概率分布
            pred_probs = {label: 0.1 for label in labels}  # 基础概率
            pred_probs[pred_class_name] = 0.9  # 主要概率

            # 更新性能统计
            prediction_time = time.ticks_diff(time.ticks_ms(), start_time)
            self.performance_stats['avg_prediction_time'] = int(
                (self.performance_stats['avg_prediction_time'] * 0.9) + (prediction_time * 0.1)
            )

            print(f"预测完成: {pred_class_name}, 耗时: {prediction_time}ms")
            return pred_class_name, pred_probs

        except Exception as e:
            print(f"预测过程总体错误: {str(e)}")
            self.performance_stats['failed_predictions'] += 1
            return 'normal', {'normal': 1.0, 'short': 0.0, 'open': 0.0, 'shelter': 0.0, 'old': 0.0}

    def get_performance_stats(self):
        """获取性能统计"""
        return self.performance_stats.copy()


class PVDiagnosticModel:
    """光伏诊断模型主类 - 增强版"""

    def __init__(self, model_dir='/sdcard'):
        """初始化诊断模型"""
        self.model_manager = ModelManager()
        self.model_dir = model_dir
        self.initialized = False
        
        # 诊断结果历史
        self.diagnosis_history = []
        self.max_history = 100
        
        # 性能统计
        self.stats = {
            'total_predictions': 0,
            'success_predictions': 0,
            'error_predictions': 0,
            'avg_prediction_time': 0,
            'model_accuracy': 0.0,
            'uptime': time.time()
        }

    def initialize(self):
        """初始化模型"""
        print("正在初始化光伏诊断模型...")
        start_time = time.time()
        
        try:
            success = self.model_manager.load_model_params(self.model_dir)
            self.initialized = success
            
            if success:
                init_time = time.time() - start_time
                print(f"光伏诊断模型初始化成功，耗时: {init_time:.2f}秒")
            else:
                print("光伏诊断模型初始化失败")
            
            return success
        except Exception as e:
            print(f"模型初始化异常: {e}")
            self.initialized = False
            return False

    def diagnose(self, iv_data, panel_id=1, mode='voting'):
        """
        诊断光伏面板状态 - 增强版
        
        Args:
            iv_data: IV曲线数据 (160个值的列表或字符串)
            panel_id: 面板ID
            mode: 预测模式 ('voting', 'svm', 'rf', 'mlp')
            
        Returns:
            dict: 诊断结果
        """
        start_time = time.ticks_ms()
        
        try:
            print(f"开始诊断面板 {panel_id}，模式: {mode}")
            
            if not self.initialized:
                print("模型未初始化，尝试重新初始化...")
                if not self.initialize():
                    return self._get_error_result("模型初始化失败")
            
            # 执行预测
            pred_class, pred_probs = self.model_manager.predict(iv_data, mode, self.model_dir)
            
            # 计算置信度
            confidence = max(pred_probs.values()) * 100
            
            # 生成建议
            recommendations = self._generate_recommendations(pred_class, confidence)
            
            # 计算预测时间
            prediction_time = time.ticks_diff(time.ticks_ms(), start_time)
            
            # 构建结果
            result = {
                'panel_id': panel_id,
                'status': pred_class,
                'confidence': confidence,
                'probabilities': pred_probs,
                'recommendations': recommendations,
                'prediction_time': prediction_time,
                'timestamp': time.time(),
                'mode': mode,
                'success': True
            }
            
            # 更新统计信息
            self._update_stats(True, prediction_time, confidence)
            
            # 保存到历史
            self._save_to_history(result)
            
            print(f"诊断完成: {pred_class}, 置信度: {confidence:.1f}%")
            return result
            
        except Exception as e:
            prediction_time = time.ticks_diff(time.ticks_ms(), start_time)
            self._update_stats(False, prediction_time, 0)
            print(f"诊断异常: {e}")
            return self._get_error_result(f"诊断出错: {str(e)}")

    def diagnose_multiple_panels(self, panels_data, mode='voting'):
        """
        诊断多个光伏面板 - 增强版
        
        Args:
            panels_data: 字典，键为panel_id，值为IV数据
            mode: 预测模式
            
        Returns:
            dict: 多面板诊断结果
        """
        print(f"开始批量诊断 {len(panels_data)} 个面板")
        start_time = time.time()
        
        results = {}
        
        for panel_id, iv_data in panels_data.items():
            print(f"诊断面板 {panel_id}...")
            results[panel_id] = self.diagnose(iv_data, panel_id, mode)
        
        # 生成系统级统计
        total_panels = len(results)
        normal_panels = sum(1 for r in results.values() if r.get('status') == 'normal')
        successful_diagnoses = sum(1 for r in results.values() if r.get('success', False))
        
        total_time = time.time() - start_time
        avg_confidence = sum(r.get('confidence', 0) for r in results.values()) / total_panels if total_panels > 0 else 0
        
        system_result = {
            'total_panels': total_panels,
            'normal_panels': normal_panels,
            'abnormal_panels': total_panels - normal_panels,
            'successful_diagnoses': successful_diagnoses,
            'failed_diagnoses': total_panels - successful_diagnoses,
            'system_health': (normal_panels / total_panels) * 100 if total_panels > 0 else 0,
            'avg_confidence': avg_confidence,
            'total_time': total_time,
            'panel_results': results,
            'timestamp': time.time(),
            'mode': mode
        }
        
        print(f"批量诊断完成，系统健康度: {system_result['system_health']:.1f}%")
        return system_result

    def get_diagnosis_history(self, panel_id=None, limit=10):
        """获取诊断历史"""
        if panel_id is None:
            return self.diagnosis_history[-limit:]
        else:
            panel_history = [h for h in self.diagnosis_history if h.get('panel_id') == panel_id]
            return panel_history[-limit:]

    def get_model_stats(self):
        """获取模型统计信息 - 增强版"""
        # 合并内部统计和性能统计
        combined_stats = self.stats.copy()
        performance_stats = self.model_manager.get_performance_stats()
        
        combined_stats.update({
            'manager_' + k: v for k, v in performance_stats.items()
        })
        
        # 计算运行时间
        combined_stats['runtime'] = time.time() - self.stats['uptime']
        
        return combined_stats

    def clear_history(self):
        """清空诊断历史"""
        self.diagnosis_history.clear()
        gc.collect()
        print("诊断历史已清空")

    def reset_stats(self):
        """重置统计信息"""
        self.stats = {
            'total_predictions': 0,
            'success_predictions': 0,
            'error_predictions': 0,
            'avg_prediction_time': 0,
            'model_accuracy': 0.0,
            'uptime': time.time()
        }
        print("统计信息已重置")

    def _generate_recommendations(self, status, confidence):
        """生成诊断建议 - 增强版"""
        recommendations = []
        
        # 基于置信度的建议
        if confidence < 60:
            recommendations.append("⚠ 置信度较低，建议重新采集数据或检查传感器")
        elif confidence < 80:
            recommendations.append("📊 建议结合其他检测方法验证结果")
        
        # 基于状态的建议
        if status == 'normal':
            recommendations.append("✅ 面板工作状态正常")
            if confidence > 90:
                recommendations.append("🔋 性能良好，建议保持定期维护")
            else:
                recommendations.append("📈 建议持续监测确保稳定运行")
        elif status == 'short':
            recommendations.append("🚨 检测到短路故障，立即停止使用！")
            recommendations.append("🔌 检查面板连接和电缆是否有损坏")
            recommendations.append("👨‍🔧 联系专业技术人员进行紧急维修")
            recommendations.append("⚡ 确认电气安全后再进行操作")
        elif status == 'open':
            recommendations.append("🔗 检测到开路故障")
            recommendations.append("🔧 检查面板连接是否松动")
            recommendations.append("🔌 检查电缆是否断开或损坏")
            recommendations.append("📋 建议检查接线盒和连接器")
        elif status == 'shelter':
            recommendations.append("☁️ 检测到遮挡影响")
            recommendations.append("🧹 清除面板表面的遮挡物（叶子、灰尘等）")
            recommendations.append("🌳 检查周围是否有新的遮挡源（建筑物、植被）")
            recommendations.append("📊 评估遮挡对整体发电量的影响")
        elif status == 'old':
            recommendations.append("⏰ 面板老化，性能下降")
            recommendations.append("🔄 考虑更换老化的面板以提升效率")
            recommendations.append("🔍 增加维护频率和监测密度")
            recommendations.append("💰 评估更换成本与收益")
        else:
            recommendations.append("❓ 诊断结果不确定，建议重新检测")
            recommendations.append("🔧 检查系统设置和传感器状态")
        
        # 通用建议
        if len(recommendations) < 3:
            recommendations.append("📞 如有疑问请联系技术支持")
        
        return recommendations

    def _get_error_result(self, error_msg):
        """生成错误结果 - 增强版"""
        return {
            'panel_id': 0,
            'status': 'unknown',
            'confidence': 0,
            'probabilities': {
                'normal': 0.2, 
                'short': 0.2, 
                'open': 0.2, 
                'shelter': 0.2, 
                'old': 0.2
            },
            'recommendations': [
                f"❌ {error_msg}",
                "🔧 请检查系统状态并重试",
                "📞 如问题持续，请联系技术支持"
            ],
            'prediction_time': 0,
            'timestamp': time.time(),
            'success': False,
            'error': error_msg
        }

    def _update_stats(self, success, prediction_time, confidence=0):
        """更新统计信息 - 增强版"""
        self.stats['total_predictions'] += 1
        
        if success:
            self.stats['success_predictions'] += 1
            
            # 更新平均预测时间
            total_time = self.stats['avg_prediction_time'] * (self.stats['total_predictions'] - 1)
            self.stats['avg_prediction_time'] = (total_time + prediction_time) / self.stats['total_predictions']
            
            # 更新模型准确度（基于置信度）
            if confidence > 0:
                total_accuracy = self.stats['model_accuracy'] * (self.stats['success_predictions'] - 1)
                self.stats['model_accuracy'] = (total_accuracy + confidence) / self.stats['success_predictions']
        else:
            self.stats['error_predictions'] += 1

    def _save_to_history(self, result):
        """保存结果到历史 - 增强版"""
        self.diagnosis_history.append(result)
        
        # 限制历史记录数量
        if len(self.diagnosis_history) > self.max_history:
            self.diagnosis_history = self.diagnosis_history[-self.max_history:]
        
        # 定期清理内存
        if len(self.diagnosis_history) % 20 == 0:
            gc.collect()


# 全局模型实例
_global_model = None

def get_pv_model(model_dir='/sdcard'):
    """获取全局光伏诊断模型实例"""
    global _global_model
    if _global_model is None:
        _global_model = PVDiagnosticModel(model_dir)
    return _global_model

def initialize_pv_model(model_dir='/sdcard'):
    """初始化全局光伏诊断模型"""
    model = get_pv_model(model_dir)
    return model.initialize()

def reset_pv_model():
    """重置全局模型实例"""
    global _global_model
    if _global_model:
        _global_model.clear_history()
        _global_model.reset_stats()
    _global_model = None
    gc.collect()
    print("全局模型已重置")