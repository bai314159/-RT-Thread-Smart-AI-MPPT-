# Enhanced SSD1306 Small Screen Driver (Fixed Status Page)
# 增强版SSD1306小屏幕驱动 - 固定状态页面版

import time
import math
from machine import FPIOA, I2C


class SSD1306Driver:
    """SSD1306 OLED显示屏驱动类 - 增强版"""

    # SSD1306 命令定义
    SET_CONTRAST = 0x81
    SET_ENTIRE_ON = 0xA4
    SET_NORM_INV = 0xA6
    SET_DISP = 0xAE
    SET_MEM_ADDR = 0x20
    SET_COL_ADDR = 0x21
    SET_PAGE_ADDR = 0x22
    SET_DISP_START_LINE = 0x40
    SET_SEG_REMAP = 0xA0
    SET_MUX_RATIO = 0xA8
    SET_COM_OUT_DIR = 0xC0
    SET_DISP_OFFSET = 0xD3
    SET_COM_PIN_CFG = 0xDA
    SET_DISP_CLK_DIV = 0xD5
    SET_PRECHARGE = 0xD9
    SET_VCOM_DESEL = 0xDB
    SET_CHARGE_PUMP = 0x8D

    def __init__(self, width=128, height=64, i2c_id=5, scl_pin=44, sda_pin=45,
                 addr=0x3C, freq=400000, timeout=1000):
        """初始化SSD1306显示屏"""
        self.width = width
        self.height = height
        self.addr = addr
        self.pages = height // 8
        self.initialized = False
        self.i2c = None
        self.display_ready = False

        try:
            print(f"SSD1306初始化: {width}x{height}, I2C地址: 0x{addr:02X}")
            
            # 初始化引脚复用
            self.fpioa = FPIOA()
            print(f"配置I2C引脚: SCL={scl_pin}, SDA={sda_pin}")

            # 初始化I2C
            self.i2c = I2C(i2c_id, scl=scl_pin, sda=sda_pin, freq=freq, timeout=timeout)
            
            # 扫描I2C设备
            devices = self.i2c.scan()
            print(f"扫描到的I2C设备: {[hex(d) for d in devices]}")
            
            if self.addr not in devices:
                print(f"警告: 未找到SSD1306设备 (0x{self.addr:02X})")
            
            # 创建显示缓冲区
            self.buffer = bytearray(self.pages * self.width)
            print(f"创建缓冲区: {len(self.buffer)} 字节")

            # 初始化显示屏
            if self._init_display():
                self.initialized = True
                self.display_ready = True
                print("SSD1306小屏幕初始化成功")
                
                # 显示初始化成功信息
                self._show_init_success()
            else:
                print("SSD1306显示屏初始化失败")

        except Exception as e:
            print(f"SSD1306初始化失败: {e}")
            import sys
            sys.print_exception(e)
            self.initialized = False
            self.display_ready = False

        # 优化字体数据 - 6x8像素字体
        self.font_6x8 = {
            ' ': [0x00, 0x00, 0x00, 0x00, 0x00, 0x00],
            '0': [0x3E, 0x51, 0x49, 0x45, 0x3E, 0x00],
            '1': [0x00, 0x42, 0x7F, 0x40, 0x00, 0x00],
            '2': [0x42, 0x61, 0x51, 0x49, 0x46, 0x00],
            '3': [0x21, 0x41, 0x45, 0x4B, 0x31, 0x00],
            '4': [0x18, 0x14, 0x12, 0x7F, 0x10, 0x00],
            '5': [0x27, 0x45, 0x45, 0x45, 0x39, 0x00],
            '6': [0x3C, 0x4A, 0x49, 0x49, 0x30, 0x00],
            '7': [0x01, 0x71, 0x09, 0x05, 0x03, 0x00],
            '8': [0x36, 0x49, 0x49, 0x49, 0x36, 0x00],
            '9': [0x06, 0x49, 0x49, 0x29, 0x1E, 0x00],
            'A': [0x7E, 0x11, 0x11, 0x11, 0x7E, 0x00],
            'B': [0x7F, 0x49, 0x49, 0x49, 0x36, 0x00],
            'C': [0x3E, 0x41, 0x41, 0x41, 0x22, 0x00],
            'D': [0x7F, 0x41, 0x41, 0x22, 0x1C, 0x00],
            'E': [0x7F, 0x49, 0x49, 0x49, 0x41, 0x00],
            'F': [0x7F, 0x09, 0x09, 0x09, 0x01, 0x00],
            'G': [0x3E, 0x41, 0x49, 0x49, 0x7A, 0x00],
            'H': [0x7F, 0x08, 0x08, 0x08, 0x7F, 0x00],
            'I': [0x00, 0x41, 0x7F, 0x41, 0x00, 0x00],
            'J': [0x20, 0x40, 0x41, 0x3F, 0x01, 0x00],
            'K': [0x7F, 0x08, 0x14, 0x22, 0x41, 0x00],
            'L': [0x7F, 0x40, 0x40, 0x40, 0x40, 0x00],
            'M': [0x7F, 0x02, 0x0C, 0x02, 0x7F, 0x00],
            'N': [0x7F, 0x04, 0x08, 0x10, 0x7F, 0x00],
            'O': [0x3E, 0x41, 0x41, 0x41, 0x3E, 0x00],
            'P': [0x7F, 0x09, 0x09, 0x09, 0x06, 0x00],
            'Q': [0x3E, 0x41, 0x51, 0x21, 0x5E, 0x00],
            'R': [0x7F, 0x09, 0x19, 0x29, 0x46, 0x00],
            'S': [0x46, 0x49, 0x49, 0x49, 0x31, 0x00],
            'T': [0x01, 0x01, 0x7F, 0x01, 0x01, 0x00],
            'U': [0x3F, 0x40, 0x40, 0x40, 0x3F, 0x00],
            'V': [0x1F, 0x20, 0x40, 0x20, 0x1F, 0x00],
            'W': [0x3F, 0x40, 0x38, 0x40, 0x3F, 0x00],
            'X': [0x63, 0x14, 0x08, 0x14, 0x63, 0x00],
            'Y': [0x07, 0x08, 0x70, 0x08, 0x07, 0x00],
            'Z': [0x61, 0x51, 0x49, 0x45, 0x43, 0x00],
            '.': [0x00, 0x60, 0x60, 0x00, 0x00, 0x00],
            ',': [0x00, 0x80, 0x60, 0x00, 0x00, 0x00],
            ':': [0x00, 0x36, 0x36, 0x00, 0x00, 0x00],
            '!': [0x00, 0x00, 0x5F, 0x00, 0x00, 0x00],
            '-': [0x08, 0x08, 0x08, 0x08, 0x08, 0x00],
            '/': [0x60, 0x10, 0x08, 0x04, 0x03, 0x00],
            '%': [0x46, 0x26, 0x10, 0x08, 0x64, 0x62],
            '|': [0x00, 0x00, 0x7F, 0x00, 0x00, 0x00],
            # 特殊图标
            '●': [0x1C, 0x3E, 0x7F, 0x7F, 0x3E, 0x1C],  # 实心圆
            '○': [0x1C, 0x22, 0x41, 0x41, 0x22, 0x1C],  # 空心圆
            '♥': [0x0E, 0x1F, 0x3F, 0x1F, 0x0E, 0x04],  # 心形
            '►': [0x08, 0x0C, 0x0E, 0x0C, 0x08, 0x00],  # 三角形
            '★': [0x08, 0x2A, 0x1C, 0x08, 0x1C, 0x2A],  # 星形
            '■': [0x7F, 0x7F, 0x7F, 0x7F, 0x7F, 0x00],  # 方块
            '?': [0x02, 0x01, 0x51, 0x09, 0x06, 0x00],  # 问号
            'X': [0x63, 0x14, 0x08, 0x14, 0x63, 0x00],  # X号
        }

    def _write_cmd(self, cmd):
        """发送命令到SSD1306"""
        if not self.i2c:
            return False
        try:
            self.i2c.writeto(self.addr, bytearray([0x80, cmd]), True)
            return True
        except Exception as e:
            print(f"写命令失败: {e}")
            return False

    def _write_data(self, data):
        """发送数据到SSD1306"""
        if not self.i2c:
            return False
        try:
            if isinstance(data, int):
                data = [data]
            buf = bytearray([0x40] + list(data))
            self.i2c.writeto(self.addr, buf, True)
            return True
        except Exception as e:
            print(f"写数据失败: {e}")
            return False

    def _init_display(self):
        """初始化显示屏设置"""
        print("开始初始化SSD1306显示设置...")
        
        init_cmds = [
            self.SET_DISP | 0x00,           # 关闭显示
            self.SET_MEM_ADDR, 0x00,        # 水平寻址模式
            self.SET_DISP_START_LINE | 0x00, # 设置显示开始行
            self.SET_SEG_REMAP | 0x01,      # 设置段重映射
            self.SET_MUX_RATIO, self.height - 1,  # 设置复用比
            self.SET_COM_OUT_DIR | 0x08,    # 设置COM输出扫描方向
            self.SET_DISP_OFFSET, 0x00,     # 设置显示偏移
            self.SET_COM_PIN_CFG, 0x12 if self.height == 64 else 0x02,  # COM引脚配置
            self.SET_DISP_CLK_DIV, 0x80,    # 设置显示时钟分频
            self.SET_PRECHARGE, 0xF1,       # 设置预充电周期
            self.SET_VCOM_DESEL, 0x30,      # 设置VCOM取消选择级别
            self.SET_CONTRAST, 0xFF,        # 设置对比度到最大
            self.SET_ENTIRE_ON,             # 输出跟随RAM内容
            self.SET_NORM_INV,              # 正常显示(非反显)
            self.SET_CHARGE_PUMP, 0x14,     # 使能电荷泵
            self.SET_DISP | 0x01,           # 开启显示
        ]

        success_count = 0
        for i, cmd in enumerate(init_cmds):
            if self._write_cmd(cmd):
                success_count += 1
            else:
                print(f"初始化命令 {i} (0x{cmd:02X}) 失败")
            time.sleep_ms(1)

        print(f"初始化命令完成: {success_count}/{len(init_cmds)}")
        time.sleep_ms(100)
        
        return success_count >= len(init_cmds) - 2  # 允许少量命令失败

    def _show_init_success(self):
        """显示初始化成功信息"""
        try:
            self.clear()
            self.text_centered("PV DISPLAY", 5)
            self.text_centered("OLED OK", 20)
            self.hline(0, 35, 128, 1)
            self.text_centered("Ready...", 45)
            self.show()
            time.sleep(1)
        except:
            pass

    def clear(self):
        """清空显示缓冲区"""
        if not self.initialized:
            return
        for i in range(len(self.buffer)):
            self.buffer[i] = 0

    def pixel(self, x, y, color=1):
        """设置单个像素"""
        if not self.initialized or x < 0 or x >= self.width or y < 0 or y >= self.height:
            return

        page = y // 8
        bit = y % 8
        index = page * self.width + x

        if color:
            self.buffer[index] |= (1 << bit)
        else:
            self.buffer[index] &= ~(1 << bit)

    def hline(self, x, y, w, color=1):
        """绘制水平线"""
        for i in range(w):
            self.pixel(x + i, y, color)

    def vline(self, x, y, h, color=1):
        """绘制垂直线"""
        for i in range(h):
            self.pixel(x, y + i, color)

    def rect(self, x, y, w, h, color=1, fill=False):
        """绘制矩形"""
        if fill:
            for i in range(w):
                self.vline(x + i, y, h, color)
        else:
            self.hline(x, y, w, color)
            self.hline(x, y + h - 1, w, color)
            self.vline(x, y, h, color)
            self.vline(x + w - 1, y, h, color)

    def circle(self, cx, cy, r, color=1, fill=False):
        """绘制圆形"""
        if fill:
            for y in range(-r, r + 1):
                for x in range(-r, r + 1):
                    if x*x + y*y <= r*r:
                        self.pixel(cx + x, cy + y, color)
        else:
            x = 0
            y = r
            d = 3 - 2 * r
            
            while y >= x:
                self.pixel(cx + x, cy + y, color)
                self.pixel(cx - x, cy + y, color)
                self.pixel(cx + x, cy - y, color)
                self.pixel(cx - x, cy - y, color)
                self.pixel(cx + y, cy + x, color)
                self.pixel(cx - y, cy + x, color)
                self.pixel(cx + y, cy - x, color)
                self.pixel(cx - y, cy - x, color)
                
                x += 1
                if d > 0:
                    y -= 1
                    d = d + 4 * (x - y) + 10
                else:
                    d = d + 4 * x + 6

    def text(self, text_str, x, y, color=1):
        """显示文字"""
        if not self.initialized:
            return
        
        current_x = x
        for char in text_str:
            if char.upper() in self.font_6x8:
                char_data = self.font_6x8[char.upper()]
                for col in range(6):
                    if current_x + col >= self.width:
                        break
                    for row in range(8):
                        if y + row >= self.height:
                            break
                        if char_data[col] & (1 << row):
                            self.pixel(current_x + col, y + row, color)
                current_x += 6
                if current_x >= self.width:
                    break

    def text_centered(self, text_str, y, color=1):
        """居中显示文字"""
        text_width = len(text_str) * 6
        x = (self.width - text_width) // 2
        self.text(text_str, x, y, color)

    def progress_bar(self, x, y, w, h, progress, color=1):
        """绘制进度条"""
        # 绘制边框
        self.rect(x, y, w, h, color, fill=False)
        
        # 绘制填充
        fill_width = int((w - 2) * progress)
        if fill_width > 0:
            self.rect(x + 1, y + 1, fill_width, h - 2, color, fill=True)

    def show(self):
        """更新显示屏内容"""
        if not self.initialized or not self.i2c or not self.display_ready:
            return False
        
        try:
            # 设置列地址范围
            if not self._write_cmd(self.SET_COL_ADDR):
                return False
            if not self._write_cmd(0):
                return False
            if not self._write_cmd(self.width - 1):
                return False

            # 设置页地址范围
            if not self._write_cmd(self.SET_PAGE_ADDR):
                return False
            if not self._write_cmd(0):
                return False
            if not self._write_cmd(self.pages - 1):
                return False

            # 发送显示数据
            chunk_size = 16
            for i in range(0, len(self.buffer), chunk_size):
                chunk = self.buffer[i:i + chunk_size]
                if not self._write_data(chunk):
                    print(f"数据块 {i//chunk_size} 发送失败")
                    return False
                
            return True
            
        except Exception as e:
            print(f"显示更新失败: {e}")
            return False


class SSD1306ScreenManager:
    """SSD1306小屏幕管理器 - 固定状态页面版"""
    
    def __init__(self):
        self.driver = SSD1306Driver()
        self.animation_frame = 0
        self.last_update_time = 0
        
    def initialize(self):
        """初始化小屏幕"""
        success = self.driver.initialized
        
        if success:
            # 显示系统启动动画
            self.show_startup_animation()
        
        return success
    
    def show_startup_animation(self):
        """显示启动动画"""
        try:
            # 第一步：Logo显示
            self.driver.clear()
            self.driver.text_centered("PV DISPLAY", 15)
            self.driver.text_centered("SYSTEM", 30)
            self.driver.hline(20, 45, 88, 1)
            self.driver.show()
            time.sleep(1)
            
            # 第二步：版本信息
            self.driver.clear()
            self.driver.text_centered("VERSION 3.0", 15)
            self.driver.text_centered("DATA RX", 30)
            self.driver.show()
            time.sleep(1)
            
            # 第三步：加载动画
            for i in range(4):
                self.driver.clear()
                self.driver.text_centered("LOADING", 20)
                dots = "." * (i + 1)
                self.driver.text_centered(dots, 35)
                self.driver.progress_bar(20, 50, 88, 8, (i + 1) / 4)
                self.driver.show()
                time.sleep(0.5)
            
            # 第四步：准备就绪
            self.driver.clear()
            self.driver.text_centered("SYSTEM", 15)
            self.driver.text_centered("READY!", 30)
            self.driver.circle(64, 45, 3, 1, True)
            self.driver.show()
            time.sleep(1)
            
        except Exception as e:
            print(f"启动动画错误: {e}")
    
    def draw_init_progress_page(self, module_name, progress, step, total_steps):
        """绘制初始化进度页面"""
        self.driver.clear()
        
        # 标题
        self.driver.text_centered("INITIALIZING", 0)
        self.driver.hline(0, 9, 128, 1)
        
        # 当前模块
        self.driver.text_centered(module_name, 15)
        
        # 步骤信息
        self.driver.text(f"Step {step}/{total_steps}", 0, 30)
        
        # 进度条
        self.driver.progress_bar(0, 40, 128, 10, progress)
        
        # 进度百分比
        percentage = int(progress * 100)
        self.driver.text_centered(f"{percentage}%", 55)

    def draw_status_display_page(self, system_data):
        """绘制固定状态显示页面 - 以数据为主的精简版"""
        self.driver.clear()
        
        # 获取数据
        system_status = system_data.get('system_status', {})
        latest_data = system_status.get('latest_data', {})
        bluetooth_status = system_status.get('bluetooth_status', {})
        
        # === 顶部标题栏 ===
        self.driver.text_centered("PV DATA MONITOR", 0)
        self.driver.hline(0, 8, 128, 1)
        
        # === 主要数据区域 ===
        
        # 第一行：总功率 (大字体效果)
        power = latest_data.get('total_power', 0)
        power_str = f"{power:.0f}W"
        self.driver.text("POWER:", 0, 12)
        
        # 功率值居中显示，带边框
        power_x = 45
        power_y = 11
        power_width = len(power_str) * 6 + 8
        self.driver.rect(power_x - 3, power_y - 1, power_width, 10, 1, False)
        self.driver.text(power_str, power_x, power_y)
        
        # 第二行：温度和AI状态
        temperature = latest_data.get('temperature', 25)
        ai_status = latest_data.get('ai_status', 0)
        
        self.driver.text("TEMP:", 0, 25)
        temp_str = f"{temperature}C"
        self.driver.text(temp_str, 35, 25)
        
        # AI状态指示
        ai_text = "AI:BUSY" if ai_status == 1 else "AI:IDLE"
        ai_icon = "►" if ai_status == 1 else "■"
        self.driver.text(ai_text, 70, 25)
        self.driver.text(ai_icon, 118, 25)
        
        # 第三行：通信状态
        uart_ok = system_status.get('uart_status') == 'ok'
        bt_ok = bluetooth_status.get('connected', False)
        packets = system_status.get('comm_stats', {}).get('packets_received', 0)
        
        # UART状态
        uart_icon = "●" if uart_ok else "○"
        self.driver.text(f"UART{uart_icon}", 0, 38)
        
        # 蓝牙状态  
        bt_icon = "●" if bt_ok else "○"
        self.driver.text(f"BT{bt_icon}", 45, 38)
        
        # 数据包计数
        self.driver.text(f"RX:{packets}", 80, 38)
        
        # === 分割线 ===
        self.driver.hline(0, 50, 128, 1)
        
    def draw_status_display_page(self, system_data):
        """绘制固定状态显示页面 - 以数据为主的精简版"""
        self.driver.clear()
        
        # 获取数据
        system_status = system_data.get('system_status', {})
        latest_data = system_status.get('latest_data', {})
        bluetooth_status = system_status.get('bluetooth_status', {})
        
        # === 顶部标题栏 ===
        self.driver.text_centered("PV DATA MONITOR", 0)
        self.driver.hline(0, 8, 128, 1)
        
        # === 主要数据区域 ===
        
        # 第一行：总功率 (大字体效果)
        power = latest_data.get('total_power', 0)
        power_str = f"{power:.0f}W"
        self.driver.text("POWER:", 0, 12)
        
        # 功率值居中显示，带边框
        power_x = 45
        power_y = 11
        power_width = len(power_str) * 6 + 8
        self.driver.rect(power_x - 3, power_y - 1, power_width, 10, 1, False)
        self.driver.text(power_str, power_x, power_y)
        
        # 第二行：温度和AI状态
        temperature = latest_data.get('temperature', 25)
        ai_status = latest_data.get('ai_status', 0)
        
        self.driver.text("TEMP:", 0, 25)
        temp_str = f"{temperature}C"
        self.driver.text(temp_str, 35, 25)
        
        # AI状态指示
        ai_text = "AI:BUSY" if ai_status == 1 else "AI:IDLE"
        ai_icon = "►" if ai_status == 1 else "■"
        self.driver.text(ai_text, 70, 25)
        self.driver.text(ai_icon, 118, 25)
        
        # 第三行：通信状态
        uart_ok = system_status.get('uart_status') == 'ok'
        bt_ok = bluetooth_status.get('connected', False)
        packets = system_status.get('comm_stats', {}).get('packets_received', 0)
        
        # UART状态
        uart_icon = "●" if uart_ok else "○"
        self.driver.text(f"UART{uart_icon}", 0, 38)
        
        # 蓝牙状态  
        bt_icon = "●" if bt_ok else "○"
        self.driver.text(f"BT{bt_icon}", 45, 38)
        
        # 数据包计数
        self.driver.text(f"RX:{packets}", 80, 38)
        
        # === 分割线 ===
        self.driver.hline(0, 50, 128, 1)
        
        # === 底部数据包显示 ===
        self._draw_data_packet_display(system_data)
        
        # === 动画效果 ===
        if ai_status == 1:
            # AI工作时的闪烁效果
            if (self.animation_frame // 15) % 2:
                # 在AI状态附近绘制工作指示
                self.driver.pixel(115, 25, 1)
                self.driver.pixel(116, 26, 1)
                self.driver.pixel(114, 26, 1)
    
    def _draw_data_packet_display(self, system_data):
        """绘制底部数据包格式显示"""
        try:
            system_status = system_data.get('system_status', {})
            latest_data = system_status.get('latest_data', {})
            
            # 构造数据包字符串
            pv_statuses = latest_data.get('pv_statuses', [0, 0, 0, 0])
            power = latest_data.get('total_power', 0)
            temperature = latest_data.get('temperature', 25)
            ai_status = latest_data.get('ai_status', 0)
            
            # 确保pv_statuses有4个元素
            while len(pv_statuses) < 4:
                pv_statuses.append(0)
            
            data_packet = f"S,4,{pv_statuses[0]},{pv_statuses[1]},{pv_statuses[2]},{pv_statuses[3]},{power:.0f},{temperature},{ai_status},T"
            
            # 数据包可能很长，需要滚动显示
            display_width = 21  # 128像素 / 6像素字符宽度 ≈ 21字符
            
            if len(data_packet) <= display_width:
                # 数据包短，直接显示
                self.driver.text(data_packet, 0, 53)
            else:
                # 数据包长，滚动显示
                scroll_offset = (self.animation_frame // 20) % (len(data_packet) + 5)
                
                if scroll_offset < len(data_packet):
                    # 正常滚动
                    visible_part = data_packet[scroll_offset:scroll_offset + display_width]
                    if len(visible_part) < display_width and scroll_offset > 0:
                        # 末尾不足，从头补充
                        visible_part += " | " + data_packet[:display_width - len(visible_part) - 3]
                else:
                    # 空白间隔
                    visible_part = " " * min(display_width, 5) + data_packet[:max(0, display_width - 5)]
                
                self.driver.text(visible_part[:display_width], 0, 53)
            
        except Exception as e:
            # 如果数据包构造失败，显示错误信息
            self.driver.text("DATA ERROR", 0, 53)
            print(f"数据包显示错误: {e}")
    
    def update_display(self, system_data, force_page=None):
        """更新显示内容 - 固定状态页面版本"""
        if not self.driver.initialized:
            return
        
        # 强制显示特定页面（主要用于初始化）
        if force_page == 'init_progress':
            module_name = system_data.get('init_module', 'UNKNOWN')
            progress = system_data.get('init_progress', 0)
            step = system_data.get('init_step', 1)
            total_steps = system_data.get('init_total_steps', 4)
            self.draw_init_progress_page(module_name, progress, step, total_steps)
        else:
            # 默认显示固定状态页面
            self.draw_status_display_page(system_data)
        
        # 显示内容
        if self.driver.show():
            pass  # 显示成功
        else:
            print("小屏幕显示更新失败")
        
        # 更新动画帧
        self.animation_frame += 1
        if self.animation_frame >= 1000:
            self.animation_frame = 0
    
    def force_page(self, page_name):
        """强制显示特定页面（保留接口兼容性）"""
        # 由于现在是固定状态页面，这个方法主要用于初始化页面
        pass
    
    def cleanup(self):
        """清理资源"""
        if self.driver.initialized:
            self.driver.clear()
            self.driver.text_centered("SHUTDOWN", 30)
            self.driver.show()
            time.sleep(1)
            self.driver.clear()
            self.driver.show()