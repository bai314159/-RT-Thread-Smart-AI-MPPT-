# Enhanced K230 Large Screen Driver (0-100W Power Range Optimized)
# 增强版K230大屏幕驱动 - 0-100W功率全范围优化版

import time
import os
from media.display import *
from media.media import *
import image
import math


def align_to_8(x):
    """将尺寸对齐到8的倍数"""
    return (x // 8) * 8


class K230Colors:
    """K230屏幕颜色定义 - 精美配色方案"""
    # 主色调 - 深蓝科技风
    PRIMARY_DARK = (18, 28, 45)
    PRIMARY_BLUE = (39, 125, 161) 
    PRIMARY_LIGHT = (116, 204, 244)
    
    # 背景色系
    WHITE = (255, 255, 255)
    LIGHT_BLUE = (240, 248, 255)
    VERY_LIGHT_GRAY = (250, 250, 250)
    LIGHT_GRAY = (245, 245, 245)
    
    # 文字色系
    DARK_BLUE = (25, 42, 86)
    BLACK = (32, 32, 32)
    MEDIUM_GRAY = (128, 128, 128)
    LIGHT_TEXT = (96, 96, 96)
    
    # 状态色系 - 更加柔和精致
    SUCCESS_GREEN = (76, 175, 80)       # 成功绿
    SUCCESS_LIGHT = (165, 214, 167)     # 浅绿
    WARNING_ORANGE = (255, 152, 0)      # 警告橙
    WARNING_LIGHT = (255, 204, 128)     # 浅橙
    ERROR_RED = (244, 67, 54)           # 错误红
    ERROR_LIGHT = (255, 138, 128)       # 浅红
    INFO_BLUE = (33, 150, 243)          # 信息蓝
    INFO_LIGHT = (144, 202, 249)        # 浅蓝
    
    # 边框和装饰色系
    BORDER_LIGHT = (220, 220, 220)
    BORDER_MEDIUM = (200, 200, 200)
    ACCENT_CYAN = (0, 188, 212)
    ACCENT_PURPLE = (156, 39, 176)
    
    # PV面板状态颜色映射
    PV_NORMAL = SUCCESS_LIGHT
    PV_SHORT = ERROR_LIGHT
    PV_OPEN = WARNING_LIGHT
    PV_SHELTER = INFO_LIGHT
    PV_OLD = (206, 147, 216)  # 紫色系
    PV_UNKNOWN = LIGHT_GRAY


class K230ScreenDriver:
    """K230大屏幕驱动类 - 0-100W功率全范围优化版"""
    
    def __init__(self, width=960, height=540):
        self.display_width = width
        self.display_height = height
        self.image_width = align_to_8(width)
        self.image_height = align_to_8(height)
        
        self.current_image = None
        self.is_initialized = False
        self.colors = K230Colors()
        
        # UI布局参数
        self.header_height = 90
        self.footer_height = 50
        self.panel_margin = 20
        self.card_radius = 12
        
        print(f"K230屏幕驱动初始化: {self.display_width}x{self.display_height}")
    
    def init(self):
        """初始化显示系统"""
        try:
            Display.init(Display.NT35516, 
                        width=self.display_width, 
                        height=self.display_height, 
                        to_ide=True)
            MediaManager.init()
            self.is_initialized = True
            print("K230大屏幕初始化成功")
            return True
        except Exception as e:
            print(f"K230大屏幕初始化失败: {e}")
            return False
    
    def deinit(self):
        """清理显示系统"""
        try:
            if self.is_initialized:
                Display.deinit()
                MediaManager.deinit()
                self.is_initialized = False
                print("K230大屏幕已清理")
        except Exception as e:
            print(f"K230大屏幕清理错误: {e}")
    
    def create_canvas(self, bg_color=None):
        """创建画布"""
        if not self.is_initialized:
            return False
        
        if bg_color is None:
            bg_color = self.colors.WHITE
        
        try:
            self.current_image = image.Image(self.image_width, self.image_height, image.RGB565)
            self.current_image.clear(color=bg_color)
            return True
        except Exception as e:
            print(f"创建画布失败: {e}")
            return False
    
    def display(self):
        """显示画布"""
        if not self.current_image:
            return False
        
        try:
            Display.show_image(self.current_image)
            return True
        except Exception as e:
            print(f"显示失败: {e}")
            return False
    
    # 基础绘图功能（修复thickness问题）
    def draw_line(self, x1, y1, x2, y2, color, thickness=2):
        """绘制直线"""
        try:
            if thickness <= 1:
                self.current_image.draw_line(x1, y1, x2, y2, color=color)
            else:
                # 绘制多条线来模拟thickness
                for i in range(thickness):
                    offset = i - thickness // 2
                    if abs(x2 - x1) > abs(y2 - y1):  # 水平线
                        self.current_image.draw_line(x1, y1 + offset, x2, y2 + offset, color=color)
                    else:  # 垂直线
                        self.current_image.draw_line(x1 + offset, y1, x2 + offset, y2, color=color)
        except:
            pass
    
    def draw_rect(self, x, y, width, height, color, fill=False):
        """绘制矩形"""
        try:
            self.current_image.draw_rectangle(x, y, width, height, color=color, fill=fill)
        except:
            pass
    
    def draw_circle(self, x, y, radius, color, fill=False):
        """绘制圆形"""
        try:
            self.current_image.draw_circle(x, y, radius, color=color, fill=fill)
        except:
            pass
    
    def draw_text(self, x, y, text, size=16, color=None):
        """绘制文字"""
        if color is None:
            color = self.colors.BLACK
        try:
            self.current_image.draw_string_advanced(x, y, size, str(text), color=color)
        except:
            try:
                self.current_image.draw_string(x, y, str(text), color=color)
            except:
                pass
    
    def draw_text_centered(self, x, y, text, size=16, color=None):
        """绘制居中文字"""
        text_width = len(str(text)) * size // 2
        text_x = x - text_width // 2
        self.draw_text(text_x, y, text, size, color)
    
    def pixel(self, x, y, color):
        """设置单个像素（辅助方法）"""
        try:
            if self.current_image and 0 <= x < self.display_width and 0 <= y < self.display_height:
                # 使用draw_rectangle来模拟像素设置
                self.current_image.draw_rectangle(x, y, 1, 1, color=color, fill=True)
        except:
            pass
    
    # 高级UI组件
    def draw_rounded_rect(self, x, y, width, height, radius, color, fill=False):
        """绘制圆角矩形"""
        try:
            if fill:
                # 填充主要区域
                self.draw_rect(x + radius, y, width - 2*radius, height, color, fill=True)
                self.draw_rect(x, y + radius, width, height - 2*radius, color, fill=True)
                # 填充四个角
                self.draw_circle(x + radius, y + radius, radius, color, fill=True)
                self.draw_circle(x + width - radius, y + radius, radius, color, fill=True)
                self.draw_circle(x + radius, y + height - radius, radius, color, fill=True)
                self.draw_circle(x + width - radius, y + height - radius, radius, color, fill=True)
            else:
                # 绘制边框
                self.draw_line(x + radius, y, x + width - radius, y, color, 2)
                self.draw_line(x + radius, y + height, x + width - radius, y + height, color, 2)
                self.draw_line(x, y + radius, x, y + height - radius, color, 2)
                self.draw_line(x + width, y + radius, x + width, y + height - radius, color, 2)
                # 绘制圆角
                self.draw_circle(x + radius, y + radius, radius, color)
                self.draw_circle(x + width - radius, y + radius, radius, color)
                self.draw_circle(x + radius, y + height - radius, radius, color)
                self.draw_circle(x + width - radius, y + height - radius, radius, color)
        except:
            # fallback to simple rectangle
            self.draw_rect(x, y, width, height, color, fill)
    
    def draw_gradient_rect(self, x, y, width, height, color1, color2, vertical=True):
        """绘制渐变矩形"""
        try:
            steps = height if vertical else width
            for i in range(steps):
                ratio = i / steps
                r = int(color1[0] + (color2[0] - color1[0]) * ratio)
                g = int(color1[1] + (color2[1] - color1[1]) * ratio)
                b = int(color1[2] + (color2[2] - color1[2]) * ratio)
                
                if vertical:
                    self.draw_line(x, y + i, x + width, y + i, (r, g, b), 1)
                else:
                    self.draw_line(x + i, y, x + i, y + height, (r, g, b), 1)
        except:
            # fallback
            self.draw_rect(x, y, width, height, color1, fill=True)
    
    def draw_progress_bar(self, x, y, width, height, progress, bg_color=None, fill_color=None, radius=5):
        """绘制精美进度条"""
        if bg_color is None:
            bg_color = self.colors.LIGHT_GRAY
        if fill_color is None:
            fill_color = self.colors.PRIMARY_BLUE
        
        progress = max(0, min(1, progress))
        
        # 背景
        self.draw_rounded_rect(x, y, width, height, radius, bg_color, fill=True)
        
        # 进度填充
        if progress > 0:
            fill_width = int(width * progress)
            if fill_width > radius * 2:
                self.draw_rounded_rect(x, y, fill_width, height, radius, fill_color, fill=True)
            else:
                self.draw_rect(x, y, fill_width, height, fill_color, fill=True)
        
        # 边框
        self.draw_rounded_rect(x, y, width, height, radius, self.colors.BORDER_MEDIUM, fill=False)
    
    def draw_card(self, x, y, width, height, title="", bg_color=None, border_color=None):
        """绘制卡片容器"""
        if bg_color is None:
            bg_color = self.colors.WHITE
        if border_color is None:
            border_color = self.colors.BORDER_LIGHT
        
        # 绘制阴影效果
        shadow_offset = 3
        self.draw_rounded_rect(x + shadow_offset, y + shadow_offset, width, height, 
                              self.card_radius, (0, 0, 0, 30), fill=True)
        
        # 绘制卡片背景
        self.draw_rounded_rect(x, y, width, height, self.card_radius, bg_color, fill=True)
        
        # 绘制边框
        self.draw_rounded_rect(x, y, width, height, self.card_radius, border_color, fill=False)
        
        # 绘制标题
        if title:
            title_bg_color = self.colors.LIGHT_BLUE
            self.draw_rounded_rect(x, y, width, 35, self.card_radius, title_bg_color, fill=True)
            self.draw_text(x + 15, y + 8, title, 16, self.colors.DARK_BLUE)
            self.draw_line(x + 10, y + 35, x + width - 10, y + 35, self.colors.BORDER_LIGHT, 1)
    
    def draw_status_indicator(self, x, y, status, size=12):
        """绘制状态指示器"""
        colors = {
            'normal': self.colors.SUCCESS_GREEN,
            'warning': self.colors.WARNING_ORANGE,
            'error': self.colors.ERROR_RED,
            'info': self.colors.INFO_BLUE,
            'offline': self.colors.MEDIUM_GRAY
        }
        
        color = colors.get(status, self.colors.MEDIUM_GRAY)
        
        # 绘制外圈
        self.draw_circle(x, y, size, self.colors.WHITE, fill=True)
        self.draw_circle(x, y, size, self.colors.BORDER_MEDIUM, fill=False)
        
        # 绘制内圈
        self.draw_circle(x, y, size - 3, color, fill=True)
        
        # 添加发光效果
        if status == 'normal':
            self.draw_circle(x, y, size + 2, (color[0], color[1], color[2], 50), fill=False)
    
    # 系统专用组件
    def draw_startup_animation(self):
        """绘制开机启动动画"""
        try:
            # 第一阶段：Logo显示
            self.create_canvas(self.colors.PRIMARY_DARK)
            
            # 主标题
            center_x = self.display_width // 2
            center_y = self.display_height // 2
            
            self.draw_text_centered(center_x-70, center_y - 60, "光伏数据显示系统", 42, self.colors.PRIMARY_LIGHT)
            self.draw_text_centered(center_x+10, center_y - 10, "PV Data Display System", 24, self.colors.LIGHT_GRAY)
            self.draw_text_centered(center_x, center_y + 20, "Version 3.2", 18, self.colors.MEDIUM_GRAY)
            
            # 绘制装饰线
            line_width = 300
            line_x = center_x - line_width // 2
            self.draw_gradient_rect(line_x, center_y + 50, line_width, 4, 
                                  self.colors.PRIMARY_BLUE, self.colors.PRIMARY_LIGHT, False)
            
            self.display()
            time.sleep(2)
            
            # 第二阶段：初始化进度
            self.show_init_progress("系统初始化中...", 0.0)
            time.sleep(0.5)
            
        except Exception as e:
            print(f"启动动画错误: {e}")
    
    def show_init_progress(self, message, progress):
        """显示初始化进度"""
        try:
            self.create_canvas(self.colors.PRIMARY_DARK)
            
            center_x = self.display_width // 2
            center_y = self.display_height // 2
            
            # 标题
            self.draw_text_centered(center_x-30, center_y - 80, "系统正在启动", 32, self.colors.PRIMARY_LIGHT)
            
            # 消息
            self.draw_text_centered(center_x-10, center_y - 30, message, 20, self.colors.LIGHT_GRAY)
            
            # 进度条
            bar_width = 400
            bar_height = 20
            bar_x = center_x - bar_width // 2
            bar_y = center_y + 20
            
            self.draw_progress_bar(bar_x, bar_y, bar_width, bar_height, progress,
                                 self.colors.MEDIUM_GRAY, self.colors.PRIMARY_LIGHT, 10)
            
            # 进度百分比
            self.draw_text_centered(center_x, center_y + 60, f"{int(progress * 100)}%", 24, self.colors.PRIMARY_LIGHT)
            
            self.display()
        except Exception as e:
            print(f"初始化进度显示错误: {e}")
    
    def draw_main_interface(self, pv_data, system_status):
        """绘制主界面"""
        try:
            # 创建渐变背景
            self.create_canvas(self.colors.VERY_LIGHT_GRAY)
            
            # 绘制头部
            self.draw_system_header(system_status)
            
            # 计算布局
            content_y = self.header_height + 10
            content_height = self.display_height - self.header_height - self.footer_height - 20
            
            # 左侧区域 (光伏面板监控)
            left_width = int(self.display_width * 0.48)
            left_height = content_height
            self.draw_pv_panels_section(20, content_y, left_width, left_height, pv_data)
            
            # 右上区域 (功率监控曲线图)
            right_x = left_width + 40
            right_width = self.display_width - right_x - 20
            right_top_height = int(content_height * 0.48)
            self.draw_power_monitor_section(right_x, content_y, right_width, right_top_height, system_status)
            
            # 右下区域 (AI诊断和系统状态)
            right_bottom_y = content_y + right_top_height + 20
            right_bottom_height = content_height - right_top_height - 20
            self.draw_ai_system_section(right_x, right_bottom_y, right_width, right_bottom_height, system_status)
            
            # 底部状态栏
            self.draw_status_footer(system_status)
            
            self.display()
            
        except Exception as e:
            print(f"主界面绘制错误: {e}")
    
    def draw_system_header(self, system_status):
        """绘制系统头部"""
        try:
            # 渐变背景
            self.draw_gradient_rect(0, 0, self.display_width, self.header_height,
                                  self.colors.WHITE, self.colors.LIGHT_BLUE, True)
            
            # 主标题
            self.draw_text(30, 15, "光伏数据显示系统", 28, self.colors.DARK_BLUE)
            self.draw_text(30, 45, "PV Data Display System", 16, self.colors.MEDIUM_GRAY)
            
            # 系统时间
            try:
                current_time = time.localtime()
                time_str = f"{current_time[0]}-{current_time[1]:02d}-{current_time[2]:02d} {current_time[3]:02d}:{current_time[4]:02d}:{current_time[5]:02d}"
                self.draw_text(self.display_width - 280, 15, time_str, 18, self.colors.DARK_BLUE)
            except:
                self.draw_text(self.display_width - 280, 15, "2025-06-07 12:34:56", 18, self.colors.DARK_BLUE)
            
            # 系统状态指示器
            status_y = 45
            
            # UART状态
            uart_status = 'normal' if system_status.get('uart_status') == 'ok' else 'error'
            self.draw_status_indicator(self.display_width - 350, status_y, uart_status, 8)
            self.draw_text(self.display_width - 335, status_y - 5, "UART", 12, self.colors.DARK_BLUE)
            
            # 蓝牙状态
            bt_status = system_status.get('bluetooth_status', {})
            bt_indicator = 'normal' if bt_status.get('connected', False) else 'error'
            self.draw_status_indicator(self.display_width - 280, status_y, bt_indicator, 8)
            self.draw_text(self.display_width - 265, status_y - 5, "BT", 12, self.colors.DARK_BLUE)
            
            # AI状态
            latest_data = system_status.get('latest_data', {})
            ai_status_code = latest_data.get('ai_status', 0)
            ai_indicator = 'warning' if ai_status_code == 1 else 'info'
            self.draw_status_indicator(self.display_width - 200, status_y, ai_indicator, 8)
            self.draw_text(self.display_width - 185, status_y - 5, "AI", 12, self.colors.DARK_BLUE)
            
            # 分割线
            self.draw_line(0, self.header_height - 1, self.display_width, self.header_height - 1, 
                          self.colors.BORDER_MEDIUM, 2)
            
        except Exception as e:
            print(f"头部绘制错误: {e}")
    
    def draw_pv_panels_section(self, x, y, width, height, pv_data):
        """绘制光伏面板区域"""
        try:
            # 绘制卡片
            self.draw_card(x, y, width, height, "光伏面板监控", self.colors.WHITE)
            
            # 计算面板布局
            panel_area_y = y + 50
            panel_area_height = height - 70
            
            panel_width = (width - 60) // 2
            panel_height = (panel_area_height - 15) // 2
            
            # 绘制4个面板
            for i in range(4):
                row = i // 2
                col = i % 2
                
                panel_x = x + 20 + col * (panel_width + 20)
                panel_y = panel_area_y + row * (panel_height + 15)
                
                panel_info = pv_data.get(f'panel_{i+1}', {})
                self.draw_pv_panel_card(panel_x, panel_y, panel_width, panel_height, i+1, panel_info)
            
            # 总功率显示
            total_power = sum(panel.get('power', 0) for panel in pv_data.values())
            power_text = f"总功率: {total_power:.1f}W"
            self.draw_text(x + width - 150, y + 15, power_text, 16, self.colors.SUCCESS_GREEN)
            
        except Exception as e:
            print(f"光伏面板区域绘制错误: {e}")
    
    def draw_pv_panel_card(self, x, y, width, height, panel_id, panel_info):
        """绘制单个光伏面板卡片（简化版 - 只显示状态）"""
        try:
            status = panel_info.get('status', 'unknown')
            
            # 状态颜色映射
            status_colors = {
                'normal': self.colors.PV_NORMAL,
                'short': self.colors.PV_SHORT,
                'open': self.colors.PV_OPEN,
                'shelter': self.colors.PV_SHELTER,
                'old': self.colors.PV_OLD,
                'unknown': self.colors.PV_UNKNOWN
            }
            bg_color = status_colors.get(status, self.colors.PV_UNKNOWN)
            
            # 状态中文显示映射
            status_text_map = {
                'normal': '正常',
                'short': '短路',
                'open': '开路',
                'shelter': '遮挡',
                'old': '老化',
                'unknown': '未知'
            }
            status_text = status_text_map.get(status, '未知')
            
            # 绘制面板背景
            self.draw_rounded_rect(x, y, width, height, 8, bg_color, fill=True)
            self.draw_rounded_rect(x, y, width, height, 8, self.colors.BORDER_MEDIUM, fill=False)
            
            # 面板标题
            self.draw_text(x + 10, y + 15, f"PV-{panel_id:02d}", 18, self.colors.DARK_BLUE)
            
            # 状态指示器
            indicator_status = 'normal' if status == 'normal' else 'error'
            self.draw_status_indicator(x + width - 25, y + 20, indicator_status, 10)
            
            # 状态显示 - 居中显示
            center_y = y + height // 2
            self.draw_text_centered(x + width // 2-4, center_y - 10, "状态:", 16, self.colors.DARK_BLUE)
            self.draw_text_centered(x + width // 2-4, center_y + 10, status_text, 20, self.colors.DARK_BLUE)
            
        except Exception as e:
            print(f"面板卡片绘制错误: {e}")
    
    def draw_power_monitor_section(self, x, y, width, height, system_status):
        """绘制功率监控区域 - 0-100W全范围优化动态曲线图"""
        try:
            self.draw_card(x, y, width, height, "功率监控 (0-100W)", self.colors.WHITE)
            
            system_info = system_status.get('system_info', {})
            power_history = system_info.get('power_history', [])
            current_power = system_info.get('total_power', 0)
            
            # 绘制曲线图区域
            chart_x = x + 20
            chart_y = y + 60
            chart_width = width - 80  # 增加左侧空间用于Y轴标签
            chart_height = height - 120  # 增加底部空间用于信息显示
            
            # 绘制图表背景
            self.draw_rect(chart_x + 40, chart_y, chart_width, chart_height, self.colors.LIGHT_GRAY, fill=True)
            self.draw_rect(chart_x + 40, chart_y, chart_width, chart_height, self.colors.BORDER_MEDIUM, fill=False)
            
            # === 0-100W全范围优化的图表数据处理 ===
            if len(power_history) > 1:
                # 针对0-100W功率范围的动态范围计算
                min_power = min(power_history)
                max_power = max(power_history)
                
                print(f"[DEBUG] 功率范围: {min_power:.2f}W ~ {max_power:.2f}W")
                
                # 针对不同功率变化幅度的自适应显示策略
                power_range = max_power - min_power
                
                if power_range < 1:  # 变化小于1W，精细显示
                    center = (max_power + min_power) / 2
                    min_power = max(0, center - 2)  # 显示±2W范围
                    max_power = min(100, center + 2)
                    power_range = max_power - min_power
                    print(f"[DEBUG] 微小变化(<1W)，使用±2W范围")
                elif power_range < 5:  # 变化小于5W，小范围显示
                    center = (max_power + min_power) / 2
                    min_power = max(0, center - 5)  # 显示±5W范围
                    max_power = min(100, center + 5)
                    power_range = max_power - min_power
                    print(f"[DEBUG] 小变化(<5W)，使用±5W范围")
                elif power_range < 15:  # 变化小于15W，中等范围显示
                    margin = power_range * 0.2  # 20%边距
                    min_power = max(0, min_power - margin)
                    max_power = min(100, max_power + margin)
                    power_range = max_power - min_power
                    print(f"[DEBUG] 中等变化(<15W)，使用20%边距")
                else:  # 变化较大，使用标准边距
                    margin = power_range * 0.1  # 10%边距
                    min_power = max(0, min_power - margin)
                    max_power = min(100, max_power + margin)  # 限制在100W以内
                    power_range = max_power - min_power
                    print(f"[DEBUG] 大变化(>=15W)，使用10%边距")
                
                # 确保范围合理
                if power_range <= 0:
                    power_range = 10
                    min_power = max(0, current_power - 5)
                    max_power = min(100, current_power + 5)
                
                print(f"[DEBUG] 最终显示范围: {min_power:.2f}W ~ {max_power:.2f}W (范围:{power_range:.2f}W)")
                
                # === 绘制自适应Y轴网格线和标签 ===
                grid_lines = 4
                y_labels = []
                
                for i in range(grid_lines + 1):
                    # 计算网格线位置
                    grid_y = chart_y + (chart_height * i // grid_lines)
                    
                    # 计算对应的功率值
                    grid_value = max_power - (power_range * i / grid_lines)
                    y_labels.append((grid_y, grid_value))
                    
                    # 绘制网格线
                    if i > 0 and i < grid_lines:
                        self.draw_line(chart_x + 40, grid_y, chart_x + 40 + chart_width, grid_y, 
                                     self.colors.BORDER_LIGHT, 1)
                    
                    # 绘制Y轴标签 - 自适应精度（适配0-100W范围）
                    if power_range < 5:
                        # 小范围时显示1位小数
                        label_text = f"{grid_value:.1f}W"
                    elif power_range < 20:
                        # 中等范围时显示1位小数或整数
                        if grid_value == int(grid_value):
                            label_text = f"{int(grid_value)}W"
                        else:
                            label_text = f"{grid_value:.1f}W"
                    else:
                        # 大范围时显示整数
                        label_text = f"{int(grid_value)}W"
                    
                    # 标签显示在图表左侧
                    self.draw_text(chart_x, grid_y - 6, label_text, 12, self.colors.MEDIUM_GRAY)
                
                # === 高精度的曲线点计算 ===
                points = []
                for i, power in enumerate(power_history):
                    # X坐标：均匀分布在图表区域
                    if len(power_history) > 1:
                        point_x = chart_x + 40 + int(chart_width * i / (len(power_history) - 1))
                    else:
                        point_x = chart_x + 40 + chart_width // 2
                    
                    # Y坐标：高精度计算
                    normalized_power = (power - min_power) / power_range
                    normalized_power = max(0, min(1, normalized_power))  # 限制在0-1范围
                    point_y = chart_y + chart_height - int(chart_height * normalized_power)
                    
                    points.append((point_x, point_y))
                    print(f"[DEBUG] 点{i}: 功率{power:.2f}W -> 坐标({point_x}, {point_y})")
                
                # === 绘制增强的曲线 ===
                if len(points) >= 2:
                    # 1. 绘制填充区域
                    if len(points) > 2:
                        self._draw_curve_fill_area(points, chart_y + chart_height, self.colors.PRIMARY_LIGHT)
                    
                    # 2. 绘制主曲线
                    self._draw_enhanced_smooth_curve(points, self.colors.PRIMARY_BLUE, 3)
                    
                    # 3. 绘制数据点
                    for i, (px, py) in enumerate(points):
                        if i == len(points) - 1:
                            # 最新点用特殊标记
                            self.draw_circle(px, py, 5, self.colors.SUCCESS_GREEN, fill=True)
                            self.draw_circle(px, py, 7, self.colors.SUCCESS_GREEN, fill=False)
                            # 显示数值
                            value_text = f"{power_history[i]:.1f}W"
                            self.draw_text(px - 15, py - 20, value_text, 12, self.colors.SUCCESS_GREEN)
                        elif i % max(1, len(points) // 8) == 0:  # 间隔显示历史点
                            self.draw_circle(px, py, 2, self.colors.PRIMARY_BLUE, fill=True)
                
                # === 显示详细的统计信息 ===
                stats_y = y + height - 45
                
                # 当前功率（突出显示）
                current_text = f"当前: {current_power:.2f}W"
                self.draw_text(x + 20, stats_y, current_text, 16, self.colors.DARK_BLUE)
                
                # 最大值
                max_text = f"峰值: {max(power_history):.2f}W"
                max_color = self.colors.SUCCESS_GREEN if max(power_history) > min(power_history) else self.colors.MEDIUM_GRAY
                self.draw_text(x + 150, stats_y, max_text, 14, max_color)
                
                # 最小值
                min_text = f"最低: {min(power_history):.2f}W"
                min_color = self.colors.INFO_BLUE
                self.draw_text(x + 280, stats_y, min_text, 14, min_color)
                
                # 变化幅度
                amplitude = max(power_history) - min(power_history)
                amp_text = f"波动: {amplitude:.2f}W"
                self.draw_text(x + 150, stats_y + 20, amp_text, 14, self.colors.MEDIUM_GRAY)
                
                # 变化趋势
                if len(power_history) >= 2:
                    recent_change = power_history[-1] - power_history[-2]
                    trend_text = f"趋势: {recent_change:+.2f}W"
                    trend_color = self.colors.SUCCESS_GREEN if recent_change > 0 else self.colors.ERROR_RED if recent_change < 0 else self.colors.MEDIUM_GRAY
                    self.draw_text(x +280, stats_y+20, trend_text, 14, trend_color)
                
                # === 时间轴标注 ===
                time_start = "0s"
                time_end = f"{len(power_history)}s"
                self.draw_text(chart_x + 40, chart_y + chart_height + 5, time_start, 12, self.colors.MEDIUM_GRAY)
                self.draw_text(chart_x + 40 + chart_width - 25, chart_y + chart_height + 5, time_end, 12, self.colors.MEDIUM_GRAY)
                
            else:
                # 无数据时的显示
                no_data_text = "等待功率数据..."
                self.draw_text_centered(chart_x + 40 + chart_width // 2, chart_y + chart_height // 2, 
                                      no_data_text, 18, self.colors.MEDIUM_GRAY)
                
                # 显示当前功率值
                if current_power > 0:
                    power_text = f"当前功率: {current_power:.2f}W"
                    self.draw_text_centered(chart_x + 40 + chart_width // 2, chart_y + chart_height // 2 + 25, 
                                          power_text, 16, self.colors.DARK_BLUE)
            
        except Exception as e:
            print(f"功率曲线绘制错误: {e}")
            import sys
            sys.print_exception(e)
    
    def _draw_curve_fill_area(self, points, baseline_y, fill_color):
        """绘制曲线下方的填充区域"""
        try:
            if len(points) < 2:
                return
            
            # 简单的填充方法：绘制垂直线条
            for i in range(len(points) - 1):
                x1, y1 = points[i]
                x2, y2 = points[i + 1]
                
                # 在两点之间绘制垂直填充线
                for x in range(x1, x2 + 1):
                    # 线性插值计算当前x对应的y值
                    if x2 != x1:
                        y = y1 + (y2 - y1) * (x - x1) // (x2 - x1)
                    else:
                        y = y1
                    
                    # 绘制从曲线到基线的垂直线（使用半透明效果）
                    for fill_y in range(y, baseline_y, 3):  # 每隔3像素绘制一次，产生半透明效果
                        self.pixel(x, fill_y, fill_color)
                        
        except Exception as e:
            print(f"填充区域绘制错误: {e}")
    
    def _draw_enhanced_smooth_curve(self, points, color, thickness=2):
        """绘制增强的平滑曲线"""
        try:
            if len(points) < 2:
                return
            
            # 使用线性插值创建平滑曲线
            for i in range(len(points) - 1):
                x1, y1 = points[i]
                x2, y2 = points[i + 1]
                
                # 计算插值步数
                steps = max(abs(x2 - x1), abs(y2 - y1), 5)
                
                for step in range(steps + 1):
                    t = step / steps if steps > 0 else 0
                    
                    # 线性插值
                    x = int(x1 + (x2 - x1) * t)
                    y = int(y1 + (y2 - y1) * t)
                    
                    # 绘制粗线条
                    for dx in range(-thickness//2, thickness//2 + 1):
                        for dy in range(-thickness//2, thickness//2 + 1):
                            if 0 <= x + dx < self.display_width and 0 <= y + dy < self.display_height:
                                try:
                                    self.pixel(x + dx, y + dy, color)
                                except:
                                    pass
            
            # 在每个数据点处绘制强调圆点
            for px, py in points:
                self.draw_circle(px, py, thickness//2 + 1, color, fill=True)
                
        except Exception as e:
            print(f"平滑曲线绘制错误: {e}")
            # 如果增强绘制失败，使用基本线段
            for i in range(len(points) - 1):
                x1, y1 = points[i]
                x2, y2 = points[i + 1]
                self.draw_line(x1, y1, x2, y2, color, thickness)
    
    def draw_ai_system_section(self, x, y, width, height, system_status):
        """绘制AI诊断和系统状态区域 - 简洁数字版"""
        try:
            self.draw_card(x, y, width, height, "系统状态监控", self.colors.WHITE)
            
            system_info = system_status.get('system_info', {})
            latest_data = system_status.get('latest_data', {})
            bluetooth_status = system_status.get('bluetooth_status', {})
            comm_stats = system_status.get('comm_stats', {})
            
            # 计算内容区域
            content_x = x + 20
            content_y = y + 50
            content_width = width - 40
            content_height = height - 70
            
            # 三列布局：AI状态 | 系统性能 | 通信设备
            col_width = (content_width - 20) // 3  # 减去间距
            
            # === 第一列：AI状态 ===
            self.draw_ai_status_column(content_x, content_y, col_width, content_height, latest_data, system_info)
            
            # === 第二列：系统性能 ===
            col2_x = content_x + col_width + 10
            self.draw_performance_column(col2_x, content_y, col_width, content_height, system_info)
            
            # === 第三列：通信设备 ===
            col3_x = col2_x + col_width + 10
            self.draw_communication_column(col3_x, content_y, col_width, content_height, 
                                         system_status, bluetooth_status, comm_stats, latest_data)
            
        except Exception as e:
            print(f"AI系统区域绘制错误: {e}")
    
    def draw_ai_status_column(self, x, y, width, height, latest_data, system_info):
        """绘制AI状态列"""
        try:
            # 列标题
            self.draw_text(x, y, "AI 引擎", 16, self.colors.DARK_BLUE)
            self.draw_line(x, y + 20, x + width - 10, y + 20, self.colors.BORDER_LIGHT, 1)
            
            # AI状态
            ai_status_code = latest_data.get('ai_status', 0)
            ai_status_text = 'DIAGNOSING' if ai_status_code == 1 else 'STANDBY'
            ai_indicator = 'warning' if ai_status_code == 1 else 'normal'
            
            status_y = y + 30
            self.draw_text(x, status_y-4, "状态:", 14, self.colors.MEDIUM_GRAY)
            self.draw_status_indicator(x + 5, status_y + 25, ai_indicator, 10)
            self.draw_text(x + 20, status_y +18, ai_status_text, 14, self.colors.DARK_BLUE)
            
            # 工作模式
            mode_y = status_y + 40
            self.draw_text(x, mode_y, "模式:", 14, self.colors.MEDIUM_GRAY)
            mode_text = "实时诊断" if ai_status_code == 1 else "待机模式"
            self.draw_text(x, mode_y +20, mode_text, 14, self.colors.DARK_BLUE)
            
            # 处理速度
            speed_y = mode_y + 38
            self.draw_text(x, speed_y, "响应:", 14, self.colors.MEDIUM_GRAY)
            avg_time = system_info.get('avg_response_time', 150)
            self.draw_text(x+40, speed_y , f"{avg_time}ms", 14, self.colors.INFO_BLUE)
            
        except Exception as e:
            print(f"AI状态列绘制错误: {e}")
    
    def draw_performance_column(self, x, y, width, height, system_info):
        """绘制系统性能列"""
        try:
            # 列标题
            self.draw_text(x, y, "系统性能", 16, self.colors.DARK_BLUE)
            self.draw_line(x, y + 20, x + width - 10, y + 20, self.colors.BORDER_LIGHT, 1)
            
            # CPU使用率
            cpu_y = y + 30
            cpu_numeric = system_info.get('cpu_usage_numeric', 0)
            cpu_color = self.colors.SUCCESS_GREEN if cpu_numeric < 70 else self.colors.WARNING_ORANGE if cpu_numeric < 90 else self.colors.ERROR_RED
            
            self.draw_text(x, cpu_y, "CPU:", 14, self.colors.MEDIUM_GRAY)
            self.draw_text(x + 40, cpu_y, f"{cpu_numeric}%", 16, cpu_color)
            
            # 内存使用率
            mem_y = cpu_y + 25
            mem_numeric = system_info.get('memory_usage_numeric', 0)
            mem_color = self.colors.SUCCESS_GREEN if mem_numeric < 70 else self.colors.WARNING_ORANGE if mem_numeric < 90 else self.colors.ERROR_RED
            
            self.draw_text(x, mem_y, "MEM:", 14, self.colors.MEDIUM_GRAY)
            self.draw_text(x + 40, mem_y, f"{mem_numeric}%", 16, mem_color)
            
            # 系统负载
            load_y = mem_y + 25
            load_avg = system_info.get('load_average', 0)
            load_color = self.colors.SUCCESS_GREEN if load_avg < 0.7 else self.colors.WARNING_ORANGE if load_avg < 0.9 else self.colors.ERROR_RED
            
            self.draw_text(x, load_y, "负载:", 14, self.colors.MEDIUM_GRAY)
            self.draw_text(x + 40, load_y, f"{load_avg:.2f}", 16, load_color)
            
            # 运行时间
            uptime_y = load_y + 25
            uptime = system_info.get('uptime', 0)
            uptime_hours = uptime // 3600
            uptime_mins = (uptime % 3600) // 60
            
            self.draw_text(x, uptime_y, "运行:", 14, self.colors.MEDIUM_GRAY)
            self.draw_text(x+40, uptime_y , f"{uptime_hours}h{uptime_mins}m", 14, self.colors.INFO_BLUE)
            
        except Exception as e:
            print(f"性能列绘制错误: {e}")
    
    def draw_communication_column(self, x, y, width, height, system_status, bluetooth_status, comm_stats, latest_data):
        """绘制通信设备列"""
        try:
            # 列标题
            self.draw_text(x, y, "通信设备", 16, self.colors.DARK_BLUE)
            self.draw_line(x, y + 20, x + width - 10, y + 20, self.colors.BORDER_LIGHT, 1)
            
            # UART状态
            uart_y = y + 30
            uart_ok = system_status.get('uart_status') == 'ok'
            uart_color = self.colors.SUCCESS_GREEN if uart_ok else self.colors.ERROR_RED
            uart_text = 'OK' if uart_ok else 'ERROR'
            
            self.draw_text(x, uart_y, "UART:", 14, self.colors.MEDIUM_GRAY)
            self.draw_text(x + 45, uart_y, uart_text, 14, uart_color)
            
            # 蓝牙状态
            bt_y = uart_y + 25
            bt_connected = bluetooth_status.get('connected', False)
            bt_color = self.colors.SUCCESS_GREEN if bt_connected else self.colors.ERROR_RED
            bt_text = 'CONN' if bt_connected else 'DISC'
            
            self.draw_text(x, bt_y, "蓝牙:", 14, self.colors.MEDIUM_GRAY)
            self.draw_text(x + 45, bt_y, bt_text, 14, bt_color)
            
            # 数据包统计
            packets_y = bt_y + 25
            packets_rx = comm_stats.get('packets_received', 0)
            
            self.draw_text(x, packets_y, "数据:", 14, self.colors.MEDIUM_GRAY)
            self.draw_text(x + 45, packets_y, str(packets_rx), 14, self.colors.INFO_BLUE)
            
            # 系统温度
            temp_y = packets_y + 25
            temperature = latest_data.get('temperature', 25)
            temp_color = self.colors.SUCCESS_GREEN if temperature < 60 else self.colors.WARNING_ORANGE if temperature < 80 else self.colors.ERROR_RED
            
            self.draw_text(x, temp_y, "温度:", 14, self.colors.MEDIUM_GRAY)
            self.draw_text(x + 45, temp_y, f"{temperature}°C", 14, temp_color)
            
        except Exception as e:
            print(f"通信设备列绘制错误: {e}")
    
    def draw_status_footer(self, system_status):
        """绘制底部状态栏"""
        try:
            footer_y = self.display_height - self.footer_height
            
            # 背景
            self.draw_gradient_rect(0, footer_y, self.display_width, self.footer_height,
                                  self.colors.LIGHT_BLUE, self.colors.WHITE, True)
            
            # 分割线
            self.draw_line(0, footer_y, self.display_width, footer_y, self.colors.BORDER_MEDIUM, 1)
            
            # 实时数据滚动显示
            pv_data = system_status.get('pv_data', {})
            latest_data = system_status.get('latest_data', {})
            total_power = latest_data.get('total_power', 0)
            
            # 静态信息显示
            info_items = [
                f"总功率: {total_power:.2f}W",
                f"在线面板: {len(pv_data)}",
                f"系统状态: 正常运行",
                f"功率范围: 0-100W"
            ]
            
            x_start = 30
            for i, item in enumerate(info_items):
                item_x = x_start + i * 200
                if item_x < self.display_width - 150:
                    self.draw_text(item_x, footer_y + 20, item, 18, self.colors.DARK_BLUE)
            
        except Exception as e:
            print(f"底部状态栏绘制错误: {e}")
    
    def draw_loading_interface(self, message="正在处理中..."):
        """绘制加载界面"""
        try:
            self.create_canvas(self.colors.VERY_LIGHT_GRAY)
            
            # 绘制头部
            self.draw_gradient_rect(0, 0, self.display_width, self.header_height,
                                  self.colors.WHITE, self.colors.LIGHT_BLUE, True)
            self.draw_text(30, 30, "光伏显示系统 - 处理中", 24, self.colors.DARK_BLUE)
            
            # 居中显示加载信息
            center_x = self.display_width // 2
            center_y = self.display_height // 2
            
            # 加载框
            box_width = 500
            box_height = 200
            box_x = center_x - box_width // 2
            box_y = center_y - box_height // 2
            
            self.draw_card(box_x, box_y, box_width, box_height, "", self.colors.WHITE)
            
            # 加载图标区域
            icon_y = box_y + 40
            self.draw_circle(center_x, icon_y, 30, self.colors.PRIMARY_BLUE, fill=False)
            
            # 加载文字
            self.draw_text_centered(center_x, center_y - 10, message, 20, self.colors.DARK_BLUE)
            
            # 动态进度条
            import time
            progress = (time.ticks_ms() // 100) % 100 / 100.0
            self.draw_progress_bar(box_x + 50, center_y + 30, box_width - 100, 25, progress,
                                 self.colors.LIGHT_GRAY, self.colors.PRIMARY_BLUE, 12)
            
            self.display()
            
        except Exception as e:
            print(f"加载界面绘制错误: {e}")
    
    def draw_error_interface(self, error_message):
        """绘制错误界面"""
        try:
            self.create_canvas(self.colors.VERY_LIGHT_GRAY)
            
            # 绘制头部
            self.draw_gradient_rect(0, 0, self.display_width, self.header_height,
                                  self.colors.WHITE, self.colors.ERROR_LIGHT, True)
            self.draw_text(30, 30, "光伏显示系统 - 系统错误", 24, self.colors.ERROR_RED)
            
            # 居中显示错误信息
            center_x = self.display_width // 2
            center_y = self.display_height // 2
            
            # 错误框
            box_width = 600
            box_height = 250
            box_x = center_x - box_width // 2
            box_y = center_y - box_height // 2
            
            self.draw_card(box_x, box_y, box_width, box_height, "", self.colors.WHITE)
            
            # 错误图标
            icon_size = 40
            self.draw_circle(center_x, box_y + 60, icon_size, self.colors.ERROR_RED, fill=True)
            self.draw_text_centered(center_x, box_y + 50, "!", 36, self.colors.WHITE)
            
            # 错误标题
            self.draw_text_centered(center_x, center_y - 20, "系统发生错误", 24, self.colors.ERROR_RED)
            
            # 错误消息
            self.draw_text_centered(center_x, center_y + 10, error_message, 16, self.colors.DARK_BLUE)
            
            # 重试提示
            self.draw_text_centered(center_x, center_y + 60, "请检查系统状态或联系管理员", 14, self.colors.MEDIUM_GRAY)
            
            self.display()
            
        except Exception as e:
            print(f"错误界面绘制错误: {e}")


class K230ScreenManager:
    """K230屏幕管理器 - 0-100W功率全范围优化版"""
    
    def __init__(self):
        self.driver = K230ScreenDriver()
        self.current_interface = 'main'
        self.last_update_time = 0
        self.update_interval = 1000  # 1秒更新间隔
        
    def initialize(self):
        """初始化屏幕"""
        if self.driver.init():
            # 显示启动动画
            self.driver.draw_startup_animation()
            return True
        return False
    
    def show_init_progress(self, module_name, progress):
        """显示初始化进度"""
        message = f"正在初始化 {module_name}..."
        self.driver.show_init_progress(message, progress)
    
    def cleanup(self):
        """清理屏幕"""
        self.driver.deinit()
    
    def update_main_interface(self, pv_data, system_status):
        """更新主界面"""
        self.current_interface = 'main'
        self.driver.draw_main_interface(pv_data, system_status)
    
    def update_loading_interface(self, message="正在处理中..."):
        """更新加载界面"""
        self.current_interface = 'loading'
        self.driver.draw_loading_interface(message)
    
    def update_error_interface(self, error_message):
        """更新错误界面"""
        self.current_interface = 'error'
        self.driver.draw_error_interface(error_message)
    
    def should_update(self):
        """检查是否需要更新"""
        current_time = time.ticks_ms()
        if time.ticks_diff(current_time, self.last_update_time) >= self.update_interval:
            self.last_update_time = current_time
            return True
        return False