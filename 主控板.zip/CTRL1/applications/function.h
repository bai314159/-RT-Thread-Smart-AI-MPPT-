#ifndef __FUNCTION_H
#define __FUNCTION_H

#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <stdint.h>

/* 定义最大光伏数量 */
#define MAX_IVNUM 9

/* 函数声明 */
void function_init(void);
void Display_RTT(void);
void status(void);
void gpio_init(void);
void PV_select(int pvnum);
void Data_clean1(void);
void Data_clean2(void);
void IVline_save(int ivnum);
void IVline_get(int ivnum);
void Send_IV_Data(void);
void ma_dataup1(void);
void ma_dataup2(void);
void dataflag_init(void);

/* 定义UART设备名 */
#define UART1_NAME "uart1"
#define UART2_NAME "uart2"
#define UART3_NAME "uart3"

#endif /* __FUNCTION_H */
