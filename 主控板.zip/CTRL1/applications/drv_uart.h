#ifndef __UART_H
#define __UART_H

#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>

/* 串口接收缓冲区定义 */
#define USART_REC_LEN 200
extern uint8_t USART_RX_BUF[USART_REC_LEN];
extern uint16_t USART_RX_STA;

/* 函数声明 */
void USART1_SendString(const char* str);
void USART2_SendString(const char* str);
void USART3_SendString(const char* str);
int USART1_SendChar(int ch);
int USART2_SendChar(int ch);
int USART3_SendChar(int ch);

/* 串口接收回调函数声明 */
rt_err_t uart1_input(rt_device_t dev, rt_size_t size);
rt_err_t uart2_input(rt_device_t dev, rt_size_t size);
rt_err_t uart3_input(rt_device_t dev, rt_size_t size);

#endif /* __UART_H */
