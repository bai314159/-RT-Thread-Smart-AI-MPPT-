#include "function.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_IVNUM 9

/* 全局变量 */
int once = 1;
int select_PV = 0; // 光伏标号（1-3）
int device_get = 0; // 采集板标号

uint8_t direct[4] = {0, 0, 0, 0}; // 服务器指令
uint8_t receive_data[6] = {0, 0, 0, 0, 0, 0}; // 服务器数据
uint8_t receive2_data[6] = {0, 0, 0, 0, 0, 0}; // 采集板数据
uint8_t receive3_data[6] = {0, 0, 0, 0, 0, 0}; // 采集板数据

float main_data[3][7]; // 总运维数据
uint8_t recv_iv_line_flage = 0; // 光伏采集标志位
float vin, iin, vout, iout, temp, mppt_Duty; // 临时数据转化
float vin2, iin2, vout2, iout2, temp2, mppt_Duty2; // 临时数据转化

float IV_vol[100];
float IV_cur[100];
float IV_vol_sent[100];
float IV_cur_sent[100];
float IV_vol1[100], IV_cur1[100];
float IV_vol2[100], IV_cur2[100];
float IV_vol3[100], IV_cur3[100];
float IV_vol4[100], IV_cur4[100];
float IV_vol5[100], IV_cur5[100];
float IV_vol6[100], IV_cur6[100];
float IV_vol7[100], IV_cur7[100];
float IV_vol8[100], IV_cur8[100];
float IV_vol9[100], IV_cur9[100];

/* RTT设备句柄 */
static rt_device_t uart1_dev;
static rt_device_t uart2_dev;
static rt_device_t uart3_dev;

/* 定时器 */
static rt_timer_t data_report_timer;

/* RTT中断回调函数声明 */
extern rt_err_t uart1_input(rt_device_t dev, rt_size_t size);
extern rt_err_t uart2_input(rt_device_t dev, rt_size_t size);
extern rt_err_t uart3_input(rt_device_t dev, rt_size_t size);

/* 定时器回调函数，替代原TIM4_IRQHandler功能 */
static void timer_callback(void *parameter)
{
    static int send_counter = 0;
    char buffer[50];

    if (recv_iv_line_flage == 0) {
        sprintf(buffer, "S,3,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,T",
                main_data[1][3], main_data[1][4], main_data[2][5],
                main_data[2][3], main_data[2][4], main_data[1][5],
                main_data[1][3]+main_data[2][3], main_data[1][4]+main_data[2][4]);

        rt_device_write(uart1_dev, 0, buffer, strlen(buffer));
        send_counter = (send_counter + 1) % 2;
    }
}

/* 初始化函数 */
void function_init(void)
{
    /* 初始化GPIO */
    gpio_init2();

    /* 打开串口设备 */
    uart1_dev = rt_device_find(UART1_NAME);
    uart2_dev = rt_device_find(UART2_NAME);
    uart3_dev = rt_device_find(UART3_NAME);

    /* 检查设备是否获取成功 */
    if (uart1_dev == RT_NULL || uart2_dev == RT_NULL || uart3_dev == RT_NULL) {
        rt_kprintf("串口设备查找失败\n");
        return;
    }

    /* 配置串口设备 */
    struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;
    config.baud_rate = BAUD_RATE_115200;

    /* 配置串口1 */
    rt_device_control(uart1_dev, RT_DEVICE_CTRL_CONFIG, &config);
    rt_device_open(uart1_dev, RT_DEVICE_FLAG_RDWR | RT_DEVICE_FLAG_INT_RX);
    rt_device_set_rx_indicate(uart1_dev, uart1_input);

    /* 配置串口2 */
    rt_device_control(uart2_dev, RT_DEVICE_CTRL_CONFIG, &config);
    rt_device_open(uart2_dev, RT_DEVICE_FLAG_RDWR | RT_DEVICE_FLAG_INT_RX);
    rt_device_set_rx_indicate(uart2_dev, uart2_input);

    /* 配置串口3 */
    rt_device_control(uart3_dev, RT_DEVICE_CTRL_CONFIG, &config);
    rt_device_open(uart3_dev, RT_DEVICE_FLAG_RDWR | RT_DEVICE_FLAG_INT_RX);
    rt_device_set_rx_indicate(uart3_dev, uart3_input);

    /* 创建定时器，替代原TIM4功能 */
    data_report_timer = rt_timer_create("data_report",
                                      timer_callback,
                                      RT_NULL,
                                      RT_TICK_PER_SECOND * 1.2,
                                      RT_TIMER_FLAG_PERIODIC);

    if (data_report_timer != RT_NULL) {
        rt_timer_start(data_report_timer);
    }

    /* 选择初始PV */
    PV_select(10);

    rt_kprintf("系统初始化完成\n");
}

/* 数据显示函数，通过RTT输出替代LCD显示 */
void Display_RTT(void)
{
    rt_kprintf("======= 系统状态 =======\n");
    rt_kprintf("RX Z: %d%d%d%d\n", direct[0], direct[1], direct[2], direct[3]);
    rt_kprintf("RX S1: %d%d%d%d%d%d\n",
               receive2_data[0], receive2_data[1], receive2_data[2],
               receive2_data[3], receive2_data[4], receive2_data[5]);
    rt_kprintf("RX S2: %d%d%d%d%d%d\n",
               receive3_data[0], receive3_data[1], receive3_data[2],
               receive3_data[3], receive3_data[4], receive3_data[5]);
    rt_kprintf("设备-PV: %d-%d\n", device_get, select_PV);

    if (recv_iv_line_flage != 0) {
        rt_kprintf("IV-line: -ON-\n");
    } else {
        rt_kprintf("IV-line: NULL\n");
    }

    rt_kprintf("IN: %.1fV %.1fA\n", vin+vin2, iin+iin2);
    rt_kprintf("OUT: %.1fV %.1fA\n", vout+vout2, iout+iout2);
    rt_kprintf("========================\n");
}

/* IV曲线保存函数 */
void IVline_save(int ivnum)
{
    if (ivnum < 1 || ivnum > MAX_IVNUM) return;

    switch(ivnum) {
        case 1:
            memcpy(IV_vol1, IV_vol, sizeof(IV_vol));
            memcpy(IV_cur1, IV_cur, sizeof(IV_cur));
            break;
        case 2:
            memcpy(IV_vol2, IV_vol, sizeof(IV_vol));
            memcpy(IV_cur2, IV_cur, sizeof(IV_cur));
            break;
        case 3:
            memcpy(IV_vol3, IV_vol, sizeof(IV_vol));
            memcpy(IV_cur3, IV_cur, sizeof(IV_cur));
            break;
        case 4:
            memcpy(IV_vol4, IV_vol, sizeof(IV_vol));
            memcpy(IV_cur4, IV_cur, sizeof(IV_cur));
            break;
        case 5:
            memcpy(IV_vol5, IV_vol, sizeof(IV_vol));
            memcpy(IV_cur5, IV_cur, sizeof(IV_cur));
            break;
        case 6:
            memcpy(IV_vol6, IV_vol, sizeof(IV_vol));
            memcpy(IV_cur6, IV_cur, sizeof(IV_cur));
            break;
        case 7:
            memcpy(IV_vol7, IV_vol, sizeof(IV_vol));
            memcpy(IV_cur7, IV_cur, sizeof(IV_cur));
            break;
        case 8:
            memcpy(IV_vol8, IV_vol, sizeof(IV_vol));
            memcpy(IV_cur8, IV_cur, sizeof(IV_cur));
            break;
        case 9:
            memcpy(IV_vol9, IV_vol, sizeof(IV_vol));
            memcpy(IV_cur9, IV_cur, sizeof(IV_cur));
            break;
    }
}

/* IV曲线获取函数 */
void IVline_get(int ivnum)
{
    if (ivnum < 1 || ivnum > MAX_IVNUM) return;

    switch(ivnum) {
        case 1:
            memcpy(IV_vol_sent, IV_vol1, sizeof(IV_vol1));
            memcpy(IV_cur_sent, IV_cur1, sizeof(IV_cur1));
            break;
        case 2:
            memcpy(IV_vol_sent, IV_vol2, sizeof(IV_vol2));
            memcpy(IV_cur_sent, IV_cur2, sizeof(IV_cur2));
            break;
        case 3:
            memcpy(IV_vol_sent, IV_vol3, sizeof(IV_vol3));
            memcpy(IV_cur_sent, IV_cur3, sizeof(IV_cur3));
            break;
        case 4:
            memcpy(IV_vol_sent, IV_vol4, sizeof(IV_vol4));
            memcpy(IV_cur_sent, IV_cur4, sizeof(IV_cur4));
            break;
        case 5:
            memcpy(IV_vol_sent, IV_vol5, sizeof(IV_vol5));
            memcpy(IV_cur_sent, IV_cur5, sizeof(IV_cur5));
            break;
        case 6:
            memcpy(IV_vol_sent, IV_vol6, sizeof(IV_vol6));
            memcpy(IV_cur_sent, IV_cur6, sizeof(IV_cur6));
            break;
        case 7:
            memcpy(IV_vol_sent, IV_vol7, sizeof(IV_vol7));
            memcpy(IV_cur_sent, IV_cur7, sizeof(IV_cur7));
            break;
        case 8:
            memcpy(IV_vol_sent, IV_vol8, sizeof(IV_vol8));
            memcpy(IV_cur_sent, IV_cur8, sizeof(IV_cur8));
            break;
        case 9:
            memcpy(IV_vol_sent, IV_vol9, sizeof(IV_vol9));
            memcpy(IV_cur_sent, IV_cur9, sizeof(IV_cur9));
            break;
    }
}

/* 数据清理函数1 */
void Data_clean1(void)
{
    if(receive2_data[1]==1) vin=receive2_data[2]*10+receive2_data[3]+receive2_data[4]*0.1+receive2_data[5]*0.01;
    if(receive2_data[1]==2) iin=receive2_data[2]*10+receive2_data[3]+receive2_data[4]*0.1+receive2_data[5]*0.01;
    if(receive2_data[1]==3) vout=receive2_data[2]*10+receive2_data[3]+receive2_data[4]*0.1+receive2_data[5]*0.01;
    if(receive2_data[1]==4) iout=receive2_data[2]*10+receive2_data[3]+receive2_data[4]*0.1+receive2_data[5]*0.01;
    if(receive2_data[1]==5) temp=receive2_data[2]*10+receive2_data[3]+receive2_data[4]*0.1+receive2_data[5]*0.01;
    if(receive2_data[1]==6) mppt_Duty=receive2_data[2]*10+receive2_data[3]+receive2_data[4]*0.1+receive2_data[5]*0.01;

    ma_dataup1();
}

/* 数据清理函数2 */
void Data_clean2(void)
{
    if(receive3_data[1]==1) vin2=receive3_data[2]*10+receive3_data[3]+receive3_data[4]*0.1+receive3_data[5]*0.01;
    if(receive3_data[1]==2) iin2=receive3_data[2]*10+receive3_data[3]+receive3_data[4]*0.1+receive3_data[5]*0.01;
    if(receive3_data[1]==3) vout2=receive3_data[2]*10+receive3_data[3]+receive3_data[4]*0.1+receive3_data[5]*0.01;
    if(receive3_data[1]==4) iout2=receive3_data[2]*10+receive3_data[3]+receive3_data[4]*0.1+receive3_data[5]*0.01;
    if(receive3_data[1]==5) temp2=receive3_data[2]*10+receive3_data[3]+receive3_data[4]*0.1+receive3_data[5]*0.01;
    if(receive3_data[1]==6) mppt_Duty2=receive3_data[2]*10+receive3_data[3]+receive3_data[4]*0.1+receive3_data[5]*0.01;

    ma_dataup2();
}

/* 数据更新函数1 */
void ma_dataup1(void)
{
    main_data[1][1]=vin;
    main_data[1][2]=iin;
    main_data[1][3]=vout;
    main_data[1][4]=iout;
    main_data[1][5]=temp;
    main_data[1][6]=mppt_Duty;
}

/* 数据更新函数2 */
void ma_dataup2(void)
{
    main_data[2][1]=vin2;
    main_data[2][2]=iin2;
    main_data[2][3]=vout2;
    main_data[2][4]=iout2;
    main_data[2][5]=temp2;
    main_data[2][6]=mppt_Duty2;
}

/* 数据标志初始化 */
void dataflag_init(void)
{
    recv_iv_line_flage = 0;
    direct[0] = 0;
    direct[1] = 0;
    direct[2] = 0;
    direct[3] = 0;
    once = 1;
    PV_select(10);
    select_PV = 0;
    device_get = 0;
}

/* 状态更新函数 */
void status(void)
{
    char buffer[20];

    if (direct[0] == 1 && direct[1] == 2) {
        if (direct[2] == 2 && once == 1) {
            select_PV = (direct[3] - 1) % 3 + 1;
            device_get = (direct[3] - 1) / 3 + 1;
            PV_select(direct[3]);
            rt_thread_mdelay(2500);

            sprintf(buffer, "Z,2,4,2,1,T");
            rt_device_write(uart1_dev, 0, buffer, strlen(buffer));
            once = 0;
        }
    }

    if (IV_vol[49] != 0 || recv_iv_line_flage == 1) {
        IVline_save(direct[3]);
        IVline_get(direct[3]);
        Send_IV_Data();
        dataflag_init();
    }

    ma_dataup1();
}

/* GPIO初始化 */
void gpio_init(void)
{
    /* 使用RTT的GPIO API进行初始化 */
    rt_pin_mode(GET_PIN(C, 1), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 2), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 3), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 4), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 5), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 6), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 7), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 8), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 9), PIN_MODE_OUTPUT);

    /* 设置默认电平 */
    rt_pin_write(GET_PIN(C, 1), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 2), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 3), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 4), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 5), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 6), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 7), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 8), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 9), PIN_HIGH);
}

/* PV选择函数 */
void PV_select(int pvnum)
{
    /* 先将所有引脚置为默认状态 */
    int i;
    for (i = 1; i <= 9; i++) {
        rt_pin_write(GET_PIN(C, i), PIN_LOW);
    }

    /* 根据pvnum选择对应的PV */
    if (pvnum >= 1 && pvnum <= 9) {
        rt_pin_write(GET_PIN(C, pvnum), PIN_HIGH);
    } else if (pvnum == 0) {
        /* 所有引脚置为低电平 */
    } else if (pvnum == 10) {
        /* 所有引脚置为高电平 */
        for (i = 1; i <= 9; i++) {
            rt_pin_write(GET_PIN(C, i), PIN_HIGH);
        }
    }
}

/* 发送IV数据函数 */
void Send_IV_Data(void)
{
    char buffer[20];
    int i;

    rt_thread_mdelay(200);

    /* 发送开始标记 */
    rt_device_write(uart1_dev, 0, "start,", 6);

    /* 发送所有电压和电流对 */
    for (i = 10; i <= 90; i++) {
        /* 转换并发送电压值 */
        snprintf(buffer, sizeof(buffer), "%.2f,", IV_vol_sent[i]);
        rt_device_write(uart1_dev, 0, buffer, strlen(buffer));

        /* 转换并发送电流值 */
        snprintf(buffer, sizeof(buffer), "%.2f,", IV_cur_sent[i]);
        rt_device_write(uart1_dev, 0, buffer, strlen(buffer));

        /* 每10对添加一个小延迟避免缓冲区溢出 */
        if (i % 10 == 9)
            rt_thread_mdelay(200);
    }

    /* 发送结束标记 */
    rt_device_write(uart1_dev, 0, "over", 4);

    /* 重置标志和数据 */
    for (i = 0; i <= 100; i++) {
        IV_vol[i] = 0;
        IV_cur[i] = 0;
        IV_vol_sent[i] = 0;
        IV_cur_sent[i] = 0;
    }
    recv_iv_line_flage = 0;
}
