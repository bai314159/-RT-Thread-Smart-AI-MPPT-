#include <rtthread.h>
#include "function.h"

/* 定义线程控制块和堆栈 */
static struct rt_thread status_thread;
static struct rt_thread display_thread;
static rt_uint8_t status_stack[2048];
static rt_uint8_t display_stack[1024];

/* 状态更新线程入口函数 */
static void status_thread_entry(void *parameter)
{
    while (1) {
        status(); // 状态更新
        rt_thread_mdelay(100); // 适当延时
    }
}

/* 显示线程入口函数（RTT日志输出） */
static void display_thread_entry(void *parameter)
{
    while (1) {
        Display_RTT(); // 显示更新，通过RTT输出
        rt_thread_mdelay(500); // 每500ms更新一次
    }
}

int main(void)
{
    /* 硬件初始化 */
    function_init();

    /* 创建状态更新线程 */
    rt_thread_init(&status_thread,
                   "status",
                   status_thread_entry,
                   RT_NULL,
                   &status_stack[0],
                   sizeof(status_stack),
                   3, 10);
    rt_thread_startup(&status_thread);

    /* 创建数据线程 */
    rt_thread_init(&display_thread,
                   "display",
                   display_thread_entry,
                   RT_NULL,
                   &display_stack[0],
                   sizeof(display_stack),
                   4, 10);
    rt_thread_startup(&display_thread);

    return 0;
}
