#include <rtthread.h>
#include <rtdevice.h>
#include "function.h"
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

/* 外部变量引用 */
extern uint8_t direct[4];
extern uint8_t receive_data[6];
extern uint8_t receive2_data[6];
extern uint8_t receive3_data[6];
extern float IV_vol[100];
extern float IV_cur[100];
extern uint8_t recv_iv_line_flage;

/* UART1 接收缓冲区 */
#define UART1_RX_BUFFER_SIZE 16
static uint8_t uart1_rx_buffer[UART1_RX_BUFFER_SIZE];
static uint8_t uart1_rx_index = 0;

/* UART1 接收状态机状态 */
typedef enum {
    STATE_WAIT_CMD,               // 等待命令字符 'Z' 或 'S'
    STATE_WAIT_COMMA_AFTER_CMD,   // 等待命令后的逗号 ','
    STATE_RECEIVE_DIGIT,          // 接收数字
    STATE_WAIT_COMMA_AFTER_DIGIT, // 等待数字后的 ',' 或者结束 'T'
    STATE_WAIT_T                   // 等待结束字符 'T'
} ReceiveState;

/* 命令类型 */
typedef enum {
    NONE,   // 无命令
    CMD_Z,  // 'Z' 命令
    CMD_S   // 'S' 命令
} CommandType;

/* UART1 状态变量 */
static volatile CommandType current_command = NONE;
static volatile ReceiveState recv_state = STATE_WAIT_CMD;
static uint8_t digit_index = 0;

/* UART1 接收回调函数 */
rt_err_t uart1_input(rt_device_t dev, rt_size_t size)
{
    uint8_t received;

    /* 读取数据 */
    while (rt_device_read(dev, -1, &received, 1) == 1) {

        /* 状态机处理接收数据 */
        switch(recv_state) {
            case STATE_WAIT_CMD:
                if(received == 'Z' || received == 'S') {
                    current_command = (received == 'Z') ? CMD_Z : CMD_S;
                    uart1_rx_buffer[uart1_rx_index++] = received;
                    digit_index = 0;
                    recv_state = STATE_WAIT_COMMA_AFTER_CMD;
                }
                else {
                    current_command = NONE;
                    uart1_rx_index = 0;
                }
                break;

            case STATE_WAIT_COMMA_AFTER_CMD:
                if(received == ',') {
                    uart1_rx_buffer[uart1_rx_index++] = received;
                    recv_state = STATE_RECEIVE_DIGIT;
                }
                else {
                    current_command = NONE;
                    uart1_rx_index = 0;
                }
                break;

            case STATE_RECEIVE_DIGIT:
                if(isdigit(received)) {
                    uart1_rx_buffer[uart1_rx_index++] = received;
                    if(current_command == CMD_Z && digit_index < 4) {
                        direct[digit_index++] = received - '0';
                        recv_state = STATE_WAIT_COMMA_AFTER_DIGIT;
                    }
                    else if(current_command == CMD_S && digit_index < 6) {
                        receive_data[digit_index++] = received - '0';
                        recv_state = STATE_WAIT_COMMA_AFTER_DIGIT;
                    }

                    /* 如果数字接收完毕，等待结束字符 'T' */
                    if((current_command == CMD_Z && digit_index == 4) ||
                       (current_command == CMD_S && digit_index == 6)) {
                        recv_state = STATE_WAIT_T;
                    }
                }
                else {
                    current_command = NONE;
                    uart1_rx_index = 0;
                    digit_index = 0;
                }
                break;

            case STATE_WAIT_COMMA_AFTER_DIGIT:
                if(received == ',') {
                    uart1_rx_buffer[uart1_rx_index++] = received;
                    recv_state = STATE_RECEIVE_DIGIT;
                }
                else if(received == 'T') {
                    uart1_rx_buffer[uart1_rx_index++] = received;

                    /* 命令接收完成，记录日志 */
                    rt_kprintf("UART1 RX %s: ", current_command == CMD_Z ? "Z" : "S");
                    if(current_command == CMD_Z) {
                        rt_kprintf("%d%d%d%d\n", direct[0], direct[1], direct[2], direct[3]);
                    }
                    else if(current_command == CMD_S) {
                        rt_kprintf("%d%d%d%d%d%d\n",
                                  receive_data[0], receive_data[1], receive_data[2],
                                  receive_data[3], receive_data[4], receive_data[5]);
                    }

                    /* 重置状态 */
                    current_command = NONE;
                    uart1_rx_index = 0;
                    digit_index = 0;
                    recv_state = STATE_WAIT_CMD;
                }

                else {
                                    /* 不是 ',' 也不是 'T'，重置状态 */
                                    current_command = NONE;
                                    uart1_rx_index = 0;
                                    digit_index = 0;
                                    recv_state = STATE_WAIT_CMD;
                                }
                                break;

                            case STATE_WAIT_T:
                                if(received == 'T') {
                                    uart1_rx_buffer[uart1_rx_index++] = received;

                                    /* 命令接收完成，记录日志 */
                                    rt_kprintf("UART1 RX %s: ", current_command == CMD_Z ? "Z" : "S");
                                    if(current_command == CMD_Z) {
                                        rt_kprintf("%d%d%d%d\n", direct[0], direct[1], direct[2], direct[3]);
                                    }
                                    else if(current_command == CMD_S) {
                                        rt_kprintf("%d%d%d%d%d%d\n",
                                                  receive_data[0], receive_data[1], receive_data[2],
                                                  receive_data[3], receive_data[4], receive_data[5]);
                                    }

                                    /* 重置状态 */
                                    current_command = NONE;
                                    uart1_rx_index = 0;
                                    digit_index = 0;
                                    recv_state = STATE_WAIT_CMD;
                                }
                                else {
                                    /* 不是 'T'，重置 */
                                    current_command = NONE;
                                    uart1_rx_index = 0;
                                    digit_index = 0;
                                    recv_state = STATE_WAIT_CMD;
                                }
                                break;

                            default:
                                current_command = NONE;
                                uart1_rx_index = 0;
                                digit_index = 0;
                                recv_state = STATE_WAIT_CMD;
                                break;
                        }

                        /* 缓冲区溢出保护 */
                        if(uart1_rx_index >= UART1_RX_BUFFER_SIZE) {
                            current_command = NONE;
                            uart1_rx_index = 0;
                            digit_index = 0;
                            recv_state = STATE_WAIT_CMD;
                        }
                    }

                    return RT_EOK;
                }

                /* UART2 接收状态机状态 */
                typedef enum {
                    USART2_STATE_WAIT_CMD,               // 等待命令 (S或A)
                    USART2_STATE_WAIT_COMMA_AFTER_CMD,   // 等待逗号 (',')
                    USART2_STATE_RECEIVE_DIGIT,          // 接收数字
                    USART2_STATE_WAIT_COMMA_AFTER_DIGIT, // 等待数字后的逗号
                    USART2_STATE_WAIT_T,                 // 等待T结束
                    USART2_STATE_WAIT_CMD_END,           // 等待命令结束
                    USART2_STATE_RECEIVE_START,          // 接收ASTART命令
                    USART2_STATE_RECEIVE_VOL,            // 接收电压值
                    USART2_STATE_RECEIVE_CUR,            // 接收电流值
                    USART2_STATE_RECEIVE_OVER            // 接收OVER命令
                } ReceiveState_USART2;

                /* UART2 状态变量 */
                static volatile ReceiveState_USART2 recv_state_USART2 = USART2_STATE_WAIT_CMD;
                static uint8_t cmd_buffer_USART2[32];         // 命令缓冲区
                static uint8_t cmd_index_USART2 = 0;          // 命令索引
                static uint8_t digit_index_USART2 = 0;        // 数字索引

                /* IV曲线数据接收变量 */
                static uint16_t array_receive_index = 0;      // 数组索引
                static uint8_t float_index = 0;               // 浮点数索引
                static char float_str[16];                    // 浮点数字符串
                static uint8_t start_cmd_match = 0;           // ASTART命令匹配标志
                static uint8_t over_cmd_match = 0;            // OVER命令匹配标志
                static uint8_t is_vol = 1;                    // 电压标志(1)或电流标志(0)

                /* 声明外部函数 */
                extern void Data_clean1(void);

                /* UART2 接收回调函数 */
                rt_err_t uart2_input(rt_device_t dev, rt_size_t size)
                {
                    uint8_t received;

                    /* 读取数据 */
                    while (rt_device_read(dev, -1, &received, 1) == 1) {

                        /* 状态机处理接收数据 */
                        switch (recv_state_USART2) {
                            case USART2_STATE_WAIT_CMD:
                                if (received == 'S') {
                                    /* UART2接收到 'S' */
                                    cmd_buffer_USART2[cmd_index_USART2++] = received;
                                    digit_index_USART2 = 0;
                                    recv_state_USART2 = USART2_STATE_WAIT_COMMA_AFTER_CMD;
                                }
                                else if (received == 'A') {
                                    /* 接收ASTART命令开始 */
                                    cmd_buffer_USART2[cmd_index_USART2++] = received;
                                    start_cmd_match = 1;
                                    recv_state_USART2 = USART2_STATE_RECEIVE_START;
                                }
                                else {
                                    /* 无效字符 */
                                    cmd_index_USART2 = 0;
                                }
                                break;

                            case USART2_STATE_WAIT_COMMA_AFTER_CMD:
                                if (received == ',') {
                                    /* UART2命令后的逗号 */
                                    cmd_buffer_USART2[cmd_index_USART2++] = received;
                                    recv_state_USART2 = USART2_STATE_RECEIVE_DIGIT;
                                    digit_index_USART2 = 0; // 重置数字索引
                                }
                                else {
                                    /* 无效格式 */
                                    recv_state_USART2 = USART2_STATE_WAIT_CMD;
                                    cmd_index_USART2 = 0;
                                }
                                break;

                            case USART2_STATE_RECEIVE_DIGIT:
                                if (isdigit(received)) {
                                    /* 接收有效数字 */
                                    cmd_buffer_USART2[cmd_index_USART2++] = received;
                                    if (digit_index_USART2 < 6) {
                                        receive2_data[digit_index_USART2++] = received - '0'; // 转换为整数
                                    }

                                    /* 根据命令格式判断下一个状态 */
                                    if (digit_index_USART2 == 1) {
                                        /* 第一个数字后是逗号 */
                                        recv_state_USART2 = USART2_STATE_WAIT_COMMA_AFTER_DIGIT;
                                    }
                                    else if (digit_index_USART2 >= 2 && digit_index_USART2 < 6) {
                                        recv_state_USART2 = USART2_STATE_WAIT_COMMA_AFTER_DIGIT;
                                    }
                                    else if (digit_index_USART2 == 6) {
                                        /* 接收完所有数字，等待T */
                                        recv_state_USART2 = USART2_STATE_WAIT_T;
                                    }
                                }
                                else if (received == 'T' && digit_index_USART2 == 6) {
                                    /* 刚好接收完所有数字，直接接收到T */
                                    cmd_buffer_USART2[cmd_index_USART2++] = received;
                                    recv_state_USART2 = USART2_STATE_WAIT_CMD_END;
                                }
                                else {
                                    /* 无效格式 */
                                    recv_state_USART2 = USART2_STATE_WAIT_CMD;
                                    cmd_index_USART2 = 0;
                                    digit_index_USART2 = 0;
                                }
                                break;

                            case USART2_STATE_WAIT_COMMA_AFTER_DIGIT:
                                if (received == ',') {
                                    /* 数字后的逗号，继续接收数字 */
                                    cmd_buffer_USART2[cmd_index_USART2++] = received;
                                    recv_state_USART2 = USART2_STATE_RECEIVE_DIGIT;
                                }
                                else if (received == 'T' && digit_index_USART2 == 6) {
                                    /* 接收到 'T'，命令结束 */
                                    cmd_buffer_USART2[cmd_index_USART2++] = received;
                                    recv_state_USART2 = USART2_STATE_WAIT_CMD_END;
                                }
                                else {
                                    /* 无效格式 */
                                    recv_state_USART2 = USART2_STATE_WAIT_CMD;
                                    cmd_index_USART2 = 0;
                                    digit_index_USART2 = 0;
                                }
                                break;

                            case USART2_STATE_WAIT_T:
                                if (received == 'T') {
                                    cmd_buffer_USART2[cmd_index_USART2++] = received;
                                    recv_state_USART2 = USART2_STATE_WAIT_CMD_END;
                                }
                                else {
                                    /* 无效格式 */
                                    recv_state_USART2 = USART2_STATE_WAIT_CMD;
                                    cmd_index_USART2 = 0;
                                    digit_index_USART2 = 0;
                                }
                                break;

                            case USART2_STATE_WAIT_CMD_END:
                                /* 处理完整接收到的'S'命令 */
                                rt_kprintf("UART2 RX S: %d%d%d%d%d%d\n",
                                          receive2_data[0], receive2_data[1], receive2_data[2],
                                          receive2_data[3], receive2_data[4], receive2_data[5]);

                                Data_clean1(); // 清理数据
                                recv_state_USART2 = USART2_STATE_WAIT_CMD;  // 重置状态
                                cmd_index_USART2 = 0;
                                digit_index_USART2 = 0;
                                break;

                            case USART2_STATE_RECEIVE_START:
                                /* ASTART 序列检测 */
                                if (start_cmd_match == 1 && received == 'S') {
                                    cmd_buffer_USART2[cmd_index_USART2++] = received;
                                    start_cmd_match = 2;
                                }
                                else if (start_cmd_match == 2 && received == 'T') {
                                    cmd_buffer_USART2[cmd_index_USART2++] = received;
                                    start_cmd_match = 3;
                                }
                                else if (start_cmd_match == 3 && received == 'A') {
                                    cmd_buffer_USART2[cmd_index_USART2++] = received;
                                    start_cmd_match = 4;
                                }
                                else if (start_cmd_match == 4 && received == 'R') {
                                    cmd_buffer_USART2[cmd_index_USART2++] = received;
                                    start_cmd_match = 5;
                                }
                                else if (start_cmd_match == 5 && received == 'T') {
                                    cmd_buffer_USART2[cmd_index_USART2++] = received;
                                    /* "ASTART"序列完成，准备接收电压值 */
                                    rt_kprintf("开始接收IV曲线数据\n");
                                    recv_state_USART2 = USART2_STATE_RECEIVE_VOL;
                                    array_receive_index = 0;
                                    is_vol = 1;
                                    float_index = 0;
                                    memset(float_str, 0, sizeof(float_str));
                                }
                                else {
                                    /* 无效序列 */
                                    recv_state_USART2 = USART2_STATE_WAIT_CMD;
                                    cmd_index_USART2 = 0;
                                    start_cmd_match = 0;
                                }
                                break;

                            case USART2_STATE_RECEIVE_VOL:
                                if (received == ',') {
                                    /* 电压值后的逗号，转换为浮点数 */
                                    float_str[float_index] = '\0'; // 字符串结束符
                                    if (array_receive_index < 100) {
                                        IV_vol[array_receive_index] = atof(float_str);
                                    }

                                    is_vol = 0;
                                    float_index = 0;
                                    memset(float_str, 0, sizeof(float_str));
                                    recv_state_USART2 = USART2_STATE_RECEIVE_CUR;
                                }
                                else if (received == 'O') {
                                    /* OVER命令开始 */
                                    over_cmd_match = 1;
                                    recv_state_USART2 = USART2_STATE_RECEIVE_OVER;
                                }
                                else if (isdigit(received) || received == '.' || received == '-' || received == '+') {
                                    /* 有效浮点数字符 */
                                    if (float_index < sizeof(float_str) - 1) {
                                        float_str[float_index++] = received;
                                    }
                                }
                                else {
                                    /* 无效字符 - 空格等字符略过不处理 */
                                }
                                break;

                            case USART2_STATE_RECEIVE_CUR:
                                if (received == ',') {
                                    /* 电流值后的逗号，处理电流值 */
                                    float_str[float_index] = '\0';
                                    if (array_receive_index < 100) {
                                        IV_cur[array_receive_index++] = atof(float_str);
                                    }

                                    /* 接收下一组 */
                                    is_vol = 1;
                                    float_index = 0;
                                    memset(float_str, 0, sizeof(float_str));
                                    recv_state_USART2 = USART2_STATE_RECEIVE_VOL;
                                }
                                else if (received == 'O') {
                                    /* 处理最后一个电流值并开始OVER序列 */
                                    float_str[float_index] = '\0';
                                    if (array_receive_index < 100) {
                                        IV_cur[array_receive_index++] = atof(float_str);
                                    }

                                    over_cmd_match = 1;
                                    recv_state_USART2 = USART2_STATE_RECEIVE_OVER;
                                }
                                else if (isdigit(received) || received == '.' || received == '-' || received == '+') {
                                    /* 有效浮点数字符 */
                                    if (float_index < sizeof(float_str) - 1) {
                                        float_str[float_index++] = received;
                                    }
                                }
                                else {
                                    /* 无效字符 - 空格等字符略过不处理 */
                                }
                                break;

                            case USART2_STATE_RECEIVE_OVER:
                                /* 检测"OVER"序列 */
                                if (over_cmd_match == 1 && received == 'V') {
                                    over_cmd_match = 2;
                                }
                                else if (over_cmd_match == 2 && received == 'E') {
                                    over_cmd_match = 3;
                                }
                                else if (over_cmd_match == 3 && received == 'R') {
                                    /* "OVER"序列完成，重置状态 */
                                    recv_state_USART2 = USART2_STATE_WAIT_CMD;
                                    cmd_index_USART2 = 0;
                                    digit_index_USART2 = 0;
                                    over_cmd_match = 0;
                                    recv_iv_line_flage = 1;

                                    /* 记录IV曲线接收完成日志 */
                                    rt_kprintf("IV曲线数据接收完成，共 %d 组数据\n", array_receive_index);
                                }
                                else {
                                    /* 无效序列，但继续尝试匹配OVER序列 */
                                    over_cmd_match = 0;
                                    if (received == 'O') {
                                        over_cmd_match = 1;
                                    }
                                }
                                break;

                            default:
                                /* 未知状态，重置 */
                                recv_state_USART2 = USART2_STATE_WAIT_CMD;
                                cmd_index_USART2 = 0;
                                digit_index_USART2 = 0;
                                break;
                        }

                        /* 缓冲区溢出保护 */
                        if (cmd_index_USART2 >= sizeof(cmd_buffer_USART2)) {
                            recv_state_USART2 = USART2_STATE_WAIT_CMD;
                            cmd_index_USART2 = 0;
                            digit_index_USART2 = 0;
                        }
                    }

                    return RT_EOK;
                }

                /* UART3 接收状态机变量，与UART2相似 */
                static volatile ReceiveState_USART2 recv_state_USART3 = USART2_STATE_WAIT_CMD;
                static uint8_t cmd_buffer_USART3[32];
                static uint8_t cmd_index_USART3 = 0;
                static uint8_t digit_index_USART3 = 0;

                /* 声明外部函数 */
                extern void Data_clean2(void);

                /* UART3 接收回调函数 */
                rt_err_t uart3_input(rt_device_t dev, rt_size_t size)
                {
                    uint8_t received;

                    /* 读取数据 */
                    while (rt_device_read(dev, -1, &received, 1) == 1) {

                        /* 状态机处理接收数据 */
                        switch (recv_state_USART3) {
                            case USART2_STATE_WAIT_CMD:
                                if (received == 'S') {
                                    /* UART3接收到 'S' */
                                    cmd_buffer_USART3[cmd_index_USART3++] = received;
                                    digit_index_USART3 = 0;
                                    recv_state_USART3 = USART2_STATE_WAIT_COMMA_AFTER_CMD;
                                }
                                else {
                                    /* 无效字符 */
                                    cmd_index_USART3 = 0;
                                }
                                break;

                            case USART2_STATE_WAIT_COMMA_AFTER_CMD:
                                if (received == ',') {
                                    /* 命令后的逗号 */
                                    cmd_buffer_USART3[cmd_index_USART3++] = received;
                                    recv_state_USART3 = USART2_STATE_RECEIVE_DIGIT;
                                    digit_index_USART3 = 0; // 重置数字索引
                                }
                                else {
                                    /* 无效格式 */
                                    recv_state_USART3 = USART2_STATE_WAIT_CMD;
                                    cmd_index_USART3 = 0;
                                }
                                break;

                            case USART2_STATE_RECEIVE_DIGIT:
                                if (isdigit(received)) {
                                    /* 接收有效数字 */
                                    cmd_buffer_USART3[cmd_index_USART3++] = received;
                                    if (digit_index_USART3 < 6) {
                                        receive3_data[digit_index_USART3++] = received - '0'; // 转换为整数
                                    }

                                    /* 根据命令格式判断下一个状态 */
                                    if (digit_index_USART3 == 1) {
                                        /* 第一个数字后是逗号 */
                                        recv_state_USART3 = USART2_STATE_WAIT_COMMA_AFTER_DIGIT;
                                    }
                                    else if (digit_index_USART3 >= 2 && digit_index_USART3 < 6) {
                                        recv_state_USART3 = USART2_STATE_WAIT_COMMA_AFTER_DIGIT;
                                    }
                                    else if (digit_index_USART3 == 6) {
                                        /* 接收完所有数字，等待T */
                                        recv_state_USART3 = USART2_STATE_WAIT_T;
                                    }
                                }
                                else if (received == 'T' && digit_index_USART3 == 6) {
                                    /* 刚好接收完所有数字，直接接收到T */
                                    cmd_buffer_USART3[cmd_index_USART3++] = received;
                                    recv_state_USART3 = USART2_STATE_WAIT_CMD_END;
                                }
                                else {
                                    /* 无效格式 */
                                    recv_state_USART3 = USART2_STATE_WAIT_CMD;
                                    cmd_index_USART3 = 0;
                                    digit_index_USART3 = 0;
                                }
                                break;

                            case USART2_STATE_WAIT_COMMA_AFTER_DIGIT:
                                if (received == ',') {
                                    /* 数字后的逗号，继续接收数字 */
                                    cmd_buffer_USART3[cmd_index_USART3++] = received;
                                    recv_state_USART3 = USART2_STATE_RECEIVE_DIGIT;
                                }
                                else if (received == 'T' && digit_index_USART3 == 6) {
                                    /* 接收到 'T'，命令结束 */
                                    cmd_buffer_USART3[cmd_index_USART3++] = received;
                                    recv_state_USART3 = USART2_STATE_WAIT_CMD_END;
                                }
                                else {
                                    /* 无效格式 */
                                    recv_state_USART3 = USART2_STATE_WAIT_CMD;
                                    cmd_index_USART3 = 0;
                                    digit_index_USART3 = 0;
                                }
                                break;

                            case USART2_STATE_WAIT_T:
                                if (received == 'T') {
                                    cmd_buffer_USART3[cmd_index_USART3++] = received;
                                    recv_state_USART3 = USART2_STATE_WAIT_CMD_END;
                                }
                                else {
                                    /* 无效格式 */
                                    recv_state_USART3 = USART2_STATE_WAIT_CMD;
                                    cmd_index_USART3 = 0;
                                    digit_index_USART3 = 0;
                                }
                                break;

                            case USART2_STATE_WAIT_CMD_END:
                                /* 处理完整接收到的'S'命令 */
                                rt_kprintf("UART3 RX S: %d%d%d%d%d%d\n",
                                          receive3_data[0], receive3_data[1], receive3_data[2],
                                          receive3_data[3], receive3_data[4], receive3_data[5]);

                                Data_clean2(); // 清理数据，注意这里调用的是Data_clean2
                                recv_state_USART3 = USART2_STATE_WAIT_CMD;  // 重置状态
                                cmd_index_USART3 = 0;
                                digit_index_USART3 = 0;
                                break;

                            default:
                                /* 未知状态，重置 */
                                recv_state_USART3 = USART2_STATE_WAIT_CMD;
                                cmd_index_USART3 = 0;
                                digit_index_USART3 = 0;
                                break;
                        }

                        /* 缓冲区溢出保护 */
                        if (cmd_index_USART3 >= sizeof(cmd_buffer_USART3)) {
                            recv_state_USART3 = USART2_STATE_WAIT_CMD;
                            cmd_index_USART3 = 0;
                            digit_index_USART3 = 0;
                        }
                    }

                    return RT_EOK;
                }
