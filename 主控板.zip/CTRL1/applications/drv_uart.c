#include <drv_uart.h>
#include <string.h>

/* 全局变量定义 */
uint8_t USART_RX_BUF[USART_REC_LEN];
uint16_t USART_RX_STA = 0;

/* 发送字符到UART1 */
int USART1_SendChar(int ch)
{
    rt_device_t dev = rt_device_find("uart1");
    if (dev != RT_NULL) {
        rt_device_write(dev, 0, &ch, 1);
    }
    return ch;
}

/* 发送字符到UART2 */
int USART2_SendChar(int ch)
{
    rt_device_t dev = rt_device_find("uart2");
    if (dev != RT_NULL) {
        rt_device_write(dev, 0, &ch, 1);
    }
    return ch;
}

/* 发送字符到UART3 */
int USART3_SendChar(int ch)
{
    rt_device_t dev = rt_device_find("uart3");
    if (dev != RT_NULL) {
        rt_device_write(dev, 0, &ch, 1);
    }
    return ch;
}

/* 发送字符串到UART1 */
void USART1_SendString(const char* str)
{
    rt_device_t dev = rt_device_find("uart1");
    if (dev != RT_NULL) {
        rt_device_write(dev, 0, str, strlen(str));
    }
}

/* 发送字符串到UART2 */
void USART2_SendString(const char* str)
{
    rt_device_t dev = rt_device_find("uart2");
    if (dev != RT_NULL) {
        rt_device_write(dev, 0, str, strlen(str));
    }
}

/* 发送字符串到UART3 */
void USART3_SendString(const char* str)
{
    rt_device_t dev = rt_device_find("uart3");
    if (dev != RT_NULL) {
        rt_device_write(dev, 0, str, strlen(str));
    }
}
