#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include "function.h"

/* GPIO初始化 */
void gpio_init2(void)
{
    /* 使用RTT的GPIO API进行初始化 */
    rt_pin_mode(GET_PIN(C, 1), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 2), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 3), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 4), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 5), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 6), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 7), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 8), PIN_MODE_OUTPUT);
    rt_pin_mode(GET_PIN(C, 9), PIN_MODE_OUTPUT);

    /* 设置默认电平 */
    rt_pin_write(GET_PIN(C, 1), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 2), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 3), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 4), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 5), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 6), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 7), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 8), PIN_HIGH);
    rt_pin_write(GET_PIN(C, 9), PIN_HIGH);
}
