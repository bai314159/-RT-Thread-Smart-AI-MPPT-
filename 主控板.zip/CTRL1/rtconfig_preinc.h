
#ifndef RTCONFIG_PREINC_H__
#define RTCONFIG_PREINC_H__

/* Automatically generated file; DO NOT EDIT. */
/* RT-Thread pre-include file */

#define HAVE_CCONFIG_H
#define RT_USING_NEWLIB
#define __RTTHREAD__
#define _REENT_SMALL

#endif /*RTCONFIG_PREINC_H__*/
