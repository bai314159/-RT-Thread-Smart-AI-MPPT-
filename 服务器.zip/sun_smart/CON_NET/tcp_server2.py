import socket
import sys
import time
import re
import datetime
import json
import threading
from threading import Thread, Lock
import paho.mqtt.client as mqtt
from DATA.dataproces import DataProcessor
from CON_NET.mysql_database import write_data_to_tables
from DATA.data_storage import PVIVCurveManager


class TcpServer:
    def __init__(self, mqtt_client):
        # TCP服务器初始化
        self.tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.tcp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.my_addr = ('0.0.0.0', 9999)
        self.tcp_socket.bind(self.my_addr)

        # 数据缓存和处理
        self.buffer = ""
        self.run_data = [0 for _ in range(9)]
        self.main_data = [[0 for _ in range(4)] for _ in range(9)]
        self.receiving_data = 0

        # 组件实例
        self.mqtt_client = mqtt_client
        self.data_manager = PVIVCurveManager()
        self.data_processor = DataProcessor()

        # 连接状态
        self.conn = None
        self.addr = None

        # IV曲线采集相关标志
        self.iv_select = 0
        self.iv_flag_stage = [0, 0, 0, 1, 0, 0, 0]
        '''
         iv_flag_stage: 
                        [0] - 光伏接收标志
                        [1] - 光伏采集标志
                        [2] - 光伏一键采集标志 (置1开启一键采集，置0关闭)
                        [3] - 光伏一键采集数量 (范围1～9)
                        [4] - 光伏一键发送标志
                        [5] - 光伏收发互锁标志 (置1开启发送，置0开启接收)
                        [6] - 未使用
        '''

        # 【新增】MPPT val3触发机制相关变量
        self.last_val3 = 0          # 记录上一次val3的值，用于上升沿检测
        self.mppt_trigger_enabled = True  # MPPT触发总开关

        # 【修复】光伏状态管理
        self.pv_status = [0, 0, 0, 0]  # 四块光伏状态，默认都是0(normal)
        self.classification_map = {     # 故障分类映射
            'normal': 0,
            'short': 1,
            'open': 2,
            'shelter': 3,
            'old': 4,
            # 添加可能的其他映射
            '正常': 0,
            '短路': 1,
            '开路': 2,
            '遮挡': 3,
            '老化': 4
        }
        
        # 【新增】状态码到名称的反向映射
        self.status_names = {0: 'normal', 1: 'short', 2: 'open', 3: 'shelter', 4: 'old'}

        # 线程安全锁
        self.lock = Lock()

        # 调试设置
        self.iv_row = 2  # 光伏行数，实际上机的行数
        self.iv_col = 2  # 光伏列数，2×2配置
        
        # 【修复】调整轮询和状态发送启动顺序，避免竞态条件
        # 启动轮询线程
        self.start_polling()
        
        # 【新增】启动状态发送线程
        self.start_status_sender()
        
        print(self.get_time(), "系统：TCP服务器初始化完成")

    def start(self):
        """启动TCP服务器，等待客户端连接"""
        self.tcp_socket.listen(10)
        print(self.get_time(), "系统：TCP服务器等待连接")

        while True:
            try:
                self.conn, self.addr = self.tcp_socket.accept()
                print(f"系统：接收到客户端连接，客户端信息：{self.addr}")
                self.conn.setblocking(1)

                # 创建并启动客户端处理线程
                t = Thread(target=self.do_request, args=(self.conn,))
                t.daemon = True  # 设置为守护线程
                t.start()

            except KeyboardInterrupt:
                self.tcp_socket.close()
                sys.exit("\n" + self.get_time() + "系统：服务器安全退出！")
            except Exception as e:
                print(f"系统：连接出错 - {e}")
                continue

    def do_request(self, conn):
        """处理客户端请求"""
        try:
            while True:
                try:
                    recv_data = conn.recv(4096).decode('utf8', 'ignore')
                    if not recv_data:
                        # 连接已关闭
                        print(f"系统：客户端 {self.addr} 断开连接")
                        break

                    # 【修复】移除重复的一键采集发送逻辑，统一在轮询线程中处理
                    # 不在这里处理发送条件，避免与轮询线程竞争

                    # 处理数据接收开始标记
                    if "start" in recv_data:
                        with self.lock:
                            self.iv_flag_stage[0] = 1
                            self.buffer = ""
                            self.receiving_data = 1
                        print(f"系统：接收数据: {recv_data.strip()}")
                        print("系统：开始接收数据包...")

                    # 处理数据接收结束标记
                    elif "over" in recv_data and self.receiving_data:
                        with self.lock:
                            self.iv_flag_stage[0] = 0
                            self.receiving_data = 0

                        print("系统：数据包接收完毕，处理数据...")
                        print(self.buffer)

                        try:
                            # 处理接收到的完整数据
                            with self.lock:
                                print("系统：开始处理IV数据...")
                                result = self.data_processor.process_data(self.buffer, 1)
                                if result:
                                    print("系统：IV数据处理完成，开始存储...")
                                    
                                    # 【修复】确定当前处理的光伏索引
                                    if self.iv_flag_stage[2] == 1:
                                        # 一键采集模式：使用iv_flag_stage[3]
                                        current_pv_index = self.iv_flag_stage[3]
                                        row, col = 0, 0
                                        if self.iv_flag_stage[3] > 2:
                                            row = 2
                                            col = self.iv_flag_stage[3] - 3
                                        else:
                                            row = 1
                                            col = self.iv_flag_stage[3] - 1
                                    else:
                                        # 单块采集模式：使用iv_select
                                        current_pv_index = self.iv_select
                                        if current_pv_index > 2:
                                            row = 2
                                            col = current_pv_index - 3
                                        else:
                                            row = 1
                                            col = current_pv_index - 1

                                    self.data_manager.store_iv_curve(row, col, result)

                                    # 【修复】更新光伏状态 - 使用正确的pv_index
                                    classification = result.get('classification', 'normal')
                                    print(f"系统：准备更新光伏{current_pv_index}状态为{classification}")
                                    self.update_pv_status(current_pv_index, classification, use_lock=False)

                                    # 处理一键采集模式
                                    if self.iv_flag_stage[2] == 1:
                                        print("系统：一键采集模式处理...")
                                        if self.iv_flag_stage[3] == (self.iv_row * 2):
                                            # 一键采集完成，设置发送标志
                                            print("系统：一键采集完成，准备发送到数据库...")
                                            self.iv_flag_stage[4] = 1
                                            # 【关键修复】不在这里直接调用发送函数，而是启动异步线程
                                            # 避免在锁内执行长时间操作
                                            threading.Thread(target=self.async_send_to_database, daemon=True).start()
                                        elif self.iv_flag_stage[3] < (self.iv_row * 2) and self.iv_flag_stage[5] == 0:
                                            # 继续一键采集下一个
                                            self.iv_flag_stage[3] += 1
                                            self.iv_flag_stage[5] = 1
                                            print(f"系统：继续一键采集，下一个光伏{self.iv_flag_stage[3]}")

                                    # 处理单个光伏诊断模式
                                    if (result and self.iv_flag_stage[1] == 1 and
                                            self.iv_flag_stage[2] == 0 and self.iv_flag_stage[4] == 0):
                                        print("系统：单光伏诊断模式处理...")
                                        # 发布诊断结果
                                        self.mqtt_client.publish_result(result['classification'], self.iv_select)
                                        print(f"系统：诊断结果 - {result['classification']}")

                                        # 发布MPPT数据
                                        print(f"发布MPPT，光伏{self.iv_select}")
                                        self.mqtt_client.publish_mppt_data(
                                            result['vol_max'], result['cur_max'],
                                            result['pow_max'], self.iv_select
                                        )
                                        # 写入数据库
                                        print("发布数据库")
                                        write_data_to_tables(
                                            result['powers'], result['currents'],
                                            result['voltages'], self.iv_select
                                        )

                                        # 清除单光伏诊断标记位
                                        self.iv_flag_stage[1] = 0
                                        print("系统：单光伏诊断完成，清除标志位")

                        except Exception as e:
                            print(f"系统：处理数据时出错 - {e}")

                        # 清除单光伏诊断标记（如果不是一键采集模式）
                        with self.lock:
                            if self.iv_flag_stage[1] == 1 and self.iv_flag_stage[2] == 0:
                                self.iv_flag_stage[1] = 0

                            # 清空缓冲区
                            self.buffer = ""

                    # 累积接收数据
                    elif self.receiving_data:
                        with self.lock:
                            self.buffer += recv_data.strip().replace("start", "").replace("over", "")

                    # 处理MPPT数据上报指令 (格式: S,1,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,T)
                    elif recv_data.startswith("S,") and recv_data.endswith(",T"):
                        pattern = r'^S,(\d+),(-?\d+\.\d+),(-?\d+\.\d+),(-?\d+),(-?\d+\.\d+),(-?\d+\.\d+),(-?\d+\.\d+),(-?\d+\.\d+),(-?\d+\.\d+),T$'
                        match = re.match(pattern, recv_data)

                        if match:
                            # 收集数据：1个整型和8个浮点数
                            data_to_send = [
                                int(match.group(1)),  # 整型数据
                                float(match.group(2)),  # 第一个浮点数
                                float(match.group(3)),  # 第二个浮点数
                                int(match.group(4)),  # 第三个浮点数 (val3)
                                float(match.group(5)),  # 第四个浮点数
                                float(match.group(6)),  # 第五个浮点数
                                float(match.group(7)),  # 第六个浮点数
                                float(match.group(8)),  # 第七个浮点数
                                float(match.group(9))  # 第八个浮点数
                            ]

                            # 更新运行数据
                            with self.lock:
                                self.run_data = data_to_send

                            # 【新增】处理val3触发逻辑
                            self.handle_val3_trigger(data_to_send[3])

                            # 调用 MPPT 数据处理函数
                            self.mpptsent_data(data_to_send)
                        else:
                            print(f"系统：MPPT指令格式不正确 - {recv_data}")
                            self.all_data_init()

                    # 处理其他类型数据
                    else:
                        print(f"系统：接收其他数据 - {recv_data}")

                except ConnectionResetError:
                    print(f"系统：客户端 {self.addr} 连接重置")
                    self.all_data_init()
                    break
                except Exception as e:
                    print(f"系统：接收数据时出错 - {e}")
                    self.all_data_init()
                    break

        finally:
            # 确保连接关闭并重置状态
            try:
                conn.close()
            except:
                pass

            print(f"系统：客户端 {self.addr} 连接已关闭")
            self.all_data_init()

    def async_send_to_database(self):
        """
        【新增】异步发送数据到数据库的函数
        在单独的线程中执行，避免阻塞主处理流程
        """
        try:
            print("系统：异步发送线程启动，开始发送到数据库...")
            # 短暂延迟确保状态稳定
            time.sleep(0.1)
            self.loalstorage_sent_database()
        except Exception as e:
            print(f"系统：异步发送数据库异常 - {e}")
            # 发生异常时重置标志位
            with self.lock:
                self.iv_flag_stage[1] = 0
                self.iv_flag_stage[2] = 0
                self.iv_flag_stage[3] = 0
                self.iv_flag_stage[4] = 0
                self.iv_flag_stage[5] = 0

    def handle_val3_trigger(self, current_val3):
        """
        【新增】处理val3字段的上升沿触发逻辑
        
        Args:
            current_val3 (float): 当前接收到的val3值
        """
        if not self.mppt_trigger_enabled:
            return
            
        # 转换为整数进行判断
        current_val3_int = int(current_val3)
        
        # 检查是否正在采集中（忙碌状态检查）
        is_busy = any([
            self.iv_flag_stage[0],  # 正在接收数据
            self.iv_flag_stage[1],  # 正在采集
            self.iv_flag_stage[2],  # 一键采集模式
            self.iv_flag_stage[4],  # 正在发送
            self.iv_flag_stage[5]   # 收发互锁
        ])
        
        # 上升沿检测：从0变为1-5才触发
        is_rising_edge = (self.last_val3 == 0 and 1 <= current_val3_int <= 5)
        
        # 更新last_val3
        self.last_val3 = current_val3_int
        
        # 如果正在忙碌，忽略触发
        if is_busy:
            if is_rising_edge:
                print(f"系统：MPPT val3上升沿检测到({current_val3_int})，但系统正忙，忽略触发")
            return
        
        # 上升沿触发处理
        if is_rising_edge:
            print(f"系统：MPPT val3上升沿触发 - 值为{current_val3_int}")
            
            if 1 <= current_val3_int <= 4:
                # 单块光伏采集触发
                print(f"系统：MPPT触发单块采集 - 光伏{current_val3_int}")
                self.trigger_single_pv_collection(current_val3_int)
                
            elif current_val3_int == 5:
                # 一键采集触发
                print("系统：MPPT触发一键采集")
                self.trigger_batch_collection()
        
        # 调试信息
        elif current_val3_int != 0:
            print(f"系统：MPPT val3={current_val3_int}，非上升沿，忽略 (last_val3={self.last_val3})")

    def trigger_single_pv_collection(self, pv_index):
        """
        【修复】触发单块光伏采集
        
        Args:
            pv_index (int): 光伏索引 (1-4)
        """
        try:
            with self.lock:
                self.iv_select = pv_index
                self.iv_flag_stage[1] = 1  # 设置采集标志
                # 【修复】为单块采集也设置iv_flag_stage[3]，以确保状态更新正确
                # 但保留iv_select作为主要的单块采集标识
                self.iv_flag_stage[3] = pv_index
            
            # 发送采集指令
            success = self.send_message_via_api(f"Z,1,2,2,{pv_index},T\n")
            if success:
                print(f"系统：MPPT触发成功 - 开始采集光伏{pv_index}")
            else:
                print(f"系统：MPPT触发失败 - 光伏{pv_index}采集指令发送失败")
                with self.lock:
                    self.iv_flag_stage[1] = 0  # 清除采集标志
                    
        except Exception as e:
            print(f"系统：MPPT触发单块采集异常 - {e}")
            with self.lock:
                self.iv_flag_stage[1] = 0

    def trigger_batch_collection(self):
        """
        【新增】触发一键采集
        """
        try:
            print("系统：MPPT触发一键诊断开始......")
            with self.lock:
                self.iv_flag_stage[1] = 1  # 采集标志
                self.iv_flag_stage[2] = 1  # 一键采集标志  
                self.iv_flag_stage[3] = 1  # 起始光伏编号
                self.iv_flag_stage[5] = 1  # 发送互锁标志
                
            print("系统：MPPT触发成功 - 开始一键采集")
            
        except Exception as e:
            print(f"系统：MPPT触发一键采集异常 - {e}")
            with self.lock:
                self.iv_flag_stage[1] = 0
                self.iv_flag_stage[2] = 0
                self.iv_flag_stage[3] = 0
                self.iv_flag_stage[5] = 0

    def update_pv_status(self, pv_index, classification, use_lock=True):
        """
        【修复】更新光伏状态
        
        Args:
            pv_index (int): 光伏索引 (1-4)
            classification (str/int): 诊断分类结果（字符串或数字）
            use_lock (bool): 是否使用锁，当已经在锁内时设为False
        """
        try:
            if 1 <= pv_index <= 4:
                # 处理不同类型的classification输入
                if isinstance(classification, (int, float)):
                    # 如果是数字，直接使用
                    status_code = int(classification)
                    # 确保状态码在有效范围内
                    if status_code < 0 or status_code > 4:
                        status_code = 0
                    classification_str = self.status_names.get(status_code, 'normal')
                else:
                    # 如果是字符串，转换为状态码
                    classification_str = str(classification).lower()
                    status_code = self.classification_map.get(classification_str, 0)
                
                if use_lock:
                    with self.lock:
                        self.pv_status[pv_index - 1] = status_code  # 数组索引从0开始
                else:
                    # 已经在锁内，直接更新
                    self.pv_status[pv_index - 1] = status_code
                
                print(f"系统：更新光伏{pv_index}状态 - {classification_str} -> {status_code}")
            else:
                print(f"系统：无效的光伏索引 - {pv_index}")
                
        except Exception as e:
            print(f"系统：更新光伏状态异常 - {e}")

    def get_collection_status(self):
        """
        【新增】获取当前采集状态
        
        Returns:
            int: 1=采集中, 0=空闲
        """
        with self.lock:
            # 单块采集或一键采集都算作采集状态
            if self.iv_flag_stage[1] == 1 or self.iv_flag_stage[2] == 1:
                return 1
            else:
                return 0

    def send_status_command(self):
        """
        【修复】发送状态指令给客户端
        
        格式: S,3,<pv1_status>,<pv2_status>,<pv3_status>,<pv4_status>,<collection_status>,T
        """
        try:
            # 获取当前光伏状态和采集状态（一次性获取，避免多次加锁）
            with self.lock:
                pv1_status = self.pv_status[0]
                pv2_status = self.pv_status[1]  
                pv3_status = self.pv_status[2]
                pv4_status = self.pv_status[3]
                # 同时获取采集状态，避免再次加锁
                collection_status = 1 if (self.iv_flag_stage[1] == 1 or self.iv_flag_stage[2] == 1) else 0
            
            # 构建状态指令
            status_command = f"S,3,{pv1_status},{pv2_status},{pv3_status},{pv4_status},{collection_status},T"
            
            # 发送状态指令
            success = self.send_message_via_api(status_command)
            
            # 【可选】添加调试信息（如果需要的话）
            # if success:
            #     print(f"系统：发送状态指令成功 - {status_command}")

        except Exception as e:
            print(f"系统：发送状态指令异常 - {e}")

    def status_sender_worker(self):
        """
        【新增】状态发送工作线程
        """
        while True:
            try:
                # 只有在有客户端连接时才发送
                if self.conn is not None:
                    self.send_status_command()
                
                time.sleep(1)  # 每秒发送一次
                
            except Exception as e:
                print(f"系统：状态发送线程异常 - {e}")
                time.sleep(1)

    def start_status_sender(self):
        """
        【新增】启动状态发送线程
        """
        status_thread = threading.Thread(target=self.status_sender_worker, daemon=True)
        status_thread.start()
        print("系统：状态发送线程已启动")

    def reset_val3_trigger(self):
        """
        【新增】重置val3触发状态（调试用）
        """
        with self.lock:
            self.last_val3 = 0
        print("系统：val3触发状态已重置")

    def set_mppt_trigger_enabled(self, enabled):
        """
        【新增】设置MPPT触发开关
        
        Args:
            enabled (bool): True=启用, False=禁用
        """
        self.mppt_trigger_enabled = enabled
        status = "启用" if enabled else "禁用"
        print(f"系统：MPPT触发功能已{status}")

    def reset_pv_status(self):
        """
        【新增】重置所有光伏状态为正常（调试用）
        """
        with self.lock:
            self.pv_status = [0, 0, 0, 0]
        print("系统：所有光伏状态已重置为正常")

    def set_pv_status(self, pv_index, status_code):
        """
        【新增】手动设置光伏状态（调试用）
        
        Args:
            pv_index (int): 光伏索引 (1-4)
            status_code (int): 状态码 (0-4)
        """
        if 1 <= pv_index <= 4 and 0 <= status_code <= 4:
            with self.lock:
                self.pv_status[pv_index - 1] = status_code
            classification_str = self.status_names.get(status_code, 'normal')
            print(f"系统：手动设置光伏{pv_index}状态为{status_code}({classification_str})")
        else:
            print(f"系统：无效的光伏索引或状态码 - PV{pv_index}, Status{status_code}")

    def get_current_status(self):
        """
        【新增】获取当前状态信息（调试用）
        
        Returns:
            dict: 当前状态信息
        """
        with self.lock:
            return {
                'pv_status': self.pv_status.copy(),
                'collection_status': 1 if (self.iv_flag_stage[1] == 1 or self.iv_flag_stage[2] == 1) else 0,
                'iv_flag_stage': self.iv_flag_stage.copy(),
                'last_val3': self.last_val3,
                'mppt_trigger_enabled': self.mppt_trigger_enabled,
                'iv_select': self.iv_select,
                'receiving_data': self.receiving_data
            }

    def all_data_init(self):
        """重置所有状态和标志"""
        with self.lock:
            self.iv_flag_stage = [0, 0, 0, 0, 0, 0, 0]
            self.iv_select = 0
            # 【新增】重置val3相关状态
            self.last_val3 = 0

    def send_message_via_api(self, message):
        """通过 API 向客户端发送消息"""
        if self.conn is None:
            #print("系统：当前没有有效的客户端连接，无法发送消息")
            return False

        attempts = 0
        max_attempts = 3
        delay = 1  # 重试延迟时间（秒）

        while attempts < max_attempts:
            try:
                message_bytes = message.encode('utf-8')
                print(f"系统：发送字节数据 - {message_bytes}")
                self.conn.sendall(message_bytes)
                print(f"系统：已发送消息到客户端 - {message}")
                return True  # 成功发送后返回
            except (ConnectionResetError, BrokenPipeError, socket.error) as e:
                print(f"系统：连接错误 - {e}")
                self.conn = None  # 重置连接
                break
            except Exception as e:
                print(f"系统：发送消息时出错 - {e}")
                attempts += 1
                if attempts < max_attempts:
                    print(f"系统：尝试重新发送，第 {attempts} 次...")
                    time.sleep(delay)
                else:
                    print("系统：达到最大重试次数，放弃发送")
                    break

        return False

    def mpptsent_data(self, run_data):
        """处理 MPPT 数据并通过 MQTT 发布"""
        try:
            print(f"系统：收到 MPPT 数据 - {run_data}")
            # 电压、电流、功率、温度，标号
            voltage = run_data[3]
            current = run_data[4]
            power = voltage * current
            temperature = run_data[5]
            pv_index = run_data[0]

            self.mqtt_client.publish_mode1_data(
                run_data[7], run_data[8], run_data[7]*run_data[8], run_data[6], pv_index-2
            )
        except Exception as e:
            print(f"系统：处理MPPT数据时出错 - {e}")

    def polling_function(self):
        """持续轮询运行的函数"""

        def poll_worker():
            while True:
                try:
                    # 加锁检查条件
                    with self.lock:
                        if (self.iv_flag_stage[2] == 1 and
                                self.iv_flag_stage[0] == 0 and
                                self.iv_flag_stage[5] == 1):
                            self.send_message_via_api(f"Z,1,2,2,{self.iv_flag_stage[3]},T")
                            self.iv_flag_stage[5] = 0

                    time.sleep(0.5)  # 轮询间隔
                except Exception as e:
                    print(f"系统：轮询过程中发生错误 - {e}")
                    time.sleep(1)  # 发生错误后短暂休眠再继续

        # 创建并启动轮询线程
        polling_thread = threading.Thread(target=poll_worker, daemon=True)
        polling_thread.start()

        return polling_thread

    def start_polling(self):
        """启动轮询线程"""
        self.polling_thread = self.polling_function()
        print("系统：轮询线程已启动")

    def loalstorage_sent_database(self):
        """【修复】将本地存储的IV曲线数据发送到数据库"""
        try:
            print("系统：开始发送本地存储数据到数据库...")
            matrix = self.data_manager.get_iv_curve_matrix()

            for i in range(1, self.iv_row+1 ):  # 行范围 1 到 实际上机的行数
                for j in range(0, self.iv_col):  # 列范围 0 到 1（包含 0 和 1）
                    iv_result = matrix[i][j]  # 读取对应位置数据
                    if not iv_result:
                        print(f"系统：位置 [{i}][{j}] 没有有效的IV曲线数据")
                        continue

                    iv_selects = (i - 1) * 2 + j  # 计算光伏标号 (0-3)
                    pv_index = iv_selects + 1     # 转换为1-4的索引

                    # 【修复】更新光伏状态 - 使用正确的pv_index
                    classification = iv_result.get('classification', 'normal')
                    self.update_pv_status(pv_index, classification)

                    # 发布诊断结果
                    self.mqtt_client.publish_result(
                        iv_result['classification'], f"{pv_index}"
                    )

                    # 发布MPPT数据
                    self.mqtt_client.publish_mppt_data(
                        iv_result['vol_max'], iv_result['cur_max'],
                        iv_result['pow_max'], f"{iv_selects}"
                    )

                    # 写入数据库
                    write_data_to_tables(
                        iv_result['powers'], iv_result['currents'],
                        iv_result['voltages'], pv_index  # 使用pv_index (1-4)
                    )
                    #print(iv_result)
                    time.sleep(0.2)

            # 【关键修复】完整重置所有标志位，包括互锁标志
            print("系统：重置一键采集标志位...")
            with self.lock:
                self.iv_flag_stage[1] = 0  # 采集标志
                self.iv_flag_stage[2] = 0  # 一键采集标志
                self.iv_flag_stage[3] = 0  # 采集数量
                self.iv_flag_stage[4] = 0  # 发送标志
                self.iv_flag_stage[5] = 0  # 【修复】重置互锁标志，防止卡死

            print("系统：所有IV曲线数据已发送到数据库，一键采集完成")
        except Exception as e:
            print(f"系统：发送存储数据到数据库出错 - {e}")
            # 【修复】发生异常时也要重置标志位
            with self.lock:
                self.iv_flag_stage[1] = 0
                self.iv_flag_stage[2] = 0
                self.iv_flag_stage[3] = 0
                self.iv_flag_stage[4] = 0
                self.iv_flag_stage[5] = 0

    def get_time(self):
        """获取当前时间字符串"""
        return '[' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + ']'


class MqttClient:
    def __init__(self, tcp_server):
        """初始化MQTT客户端"""
        self.client = mqtt.Client()
        self.tcp_server = tcp_server
        self.client.on_message = self.on_message
        self.client.on_connect = self.on_connect
        self.client.on_disconnect = self.on_disconnect
        self.pv_index = 0

        # 设置重连参数
        self.mqtt_server = "1.92.66.67"
        self.mqtt_port = 1883
        self.reconnect_delay = 5  # 重连延迟（秒）
        self.connected = False

    def connect_mqtt(self):
        """连接MQTT服务器，支持自动重连"""
        while True:
            try:
                print(f"系统：尝试连接MQTT服务器 {self.mqtt_server}...")
                self.client.connect(self.mqtt_server, self.mqtt_port)
                break
            except Exception as e:
                print(f"系统：MQTT连接失败 - {e}")
                print(f"系统：{self.reconnect_delay}秒后重试...")
                time.sleep(self.reconnect_delay)

    def on_connect(self, client, userdata, flags, rc):
        """MQTT连接回调"""
        if rc == 0:
            print("系统：MQTT服务器连接成功")
            self.connected = True
            # 重新订阅主题
            self.client.subscribe("box/qwer/data/command")
        else:
            print(f"系统：MQTT连接失败，返回码={rc}")
            self.connected = False

    def on_disconnect(self, client, userdata, rc):
        """MQTT断开连接回调"""
        print(f"系统：MQTT断开连接，返回码={rc}")
        self.connected = False

        if rc != 0:
            # 非正常断开，启动重连
            threading.Thread(target=self.reconnect, daemon=True).start()

    def reconnect(self):
        """MQTT重连逻辑"""
        while not self.connected:
            try:
                print(f"系统：尝试重新连接MQTT服务器...")
                self.client.reconnect()
                time.sleep(self.reconnect_delay)
            except Exception as e:
                print(f"系统：MQTT重连失败 - {e}")
                time.sleep(self.reconnect_delay)

    def on_message(self, client, userdata, msg):
        """当接收到消息时的回调函数"""
        curtime = datetime.datetime.now()
        strcurtime = curtime.strftime("%Y-%m-%d %H:%M:%S")
        print(f"系统：接收MQTT消息时间 - {strcurtime}, 主题 - {msg.topic}")
        print(f"系统：消息内容 - {msg.payload.decode()}")

        # 处理接收到的消息
        try:
            # 解析JSON数据
            data = json.loads(msg.payload.decode())

            # 检查是否为列表格式 [{"abc": "IV2"}]
            if isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict) and "abc" in data[0]:
                # 提取"abc"字段的值
                value = data[0]["abc"]
                print(f"系统：指令接收 - {value}")

                # 数字指令处理（提取数字作为光伏采集标号）
                if isinstance(value, str) and any(char.isdigit() for char in value):
                    # 提取字符串中的第一个数字
                    for char in value:
                        if char.isdigit():
                            # 将提取的数字赋值给pv_index
                            self.pv_index = int(char)
                            print(f"系统：光伏采集标号 - {self.pv_index}")

                            if self.pv_index > 0:
                                # 单个光伏采集
                                self.tcp_server.iv_select = self.pv_index
                                self.tcp_server.send_message_via_api(f"Z,1,2,2,{self.pv_index},T\n")
                                with self.tcp_server.lock:
                                    self.tcp_server.iv_flag_stage[1] = 1
                            elif self.pv_index == 0:
                                # 一键诊断所有光伏
                                print("系统：开始一键诊断......")
                                self.tcp_server.iv_flag_stage[3] = 1
                                with self.tcp_server.lock:
                                    self.tcp_server.iv_flag_stage[1] = 1
                                    self.tcp_server.iv_flag_stage[2] = 1
                                    self.tcp_server.iv_flag_stage[5] = 1
                            break  # 找到第一个数字后退出循环

                # IV指令处理（常见IV曲线采集指令）
                if isinstance(value, str) and value.startswith("IV"):
                    print("系统：接收到IV曲线采集指令")
                    # 这里可以添加特定IV指令的处理逻辑

            # 处理其他命令格式
            elif isinstance(data, dict) and "command" in data:
                command = data["command"]
                print(f"系统：执行指令 - {command}")
                # 这里可以添加更多的命令处理逻辑

        except json.JSONDecodeError:
            print("系统：MQTT消息JSON解析失败")
        except Exception as e:
            print(f"系统：处理MQTT消息时出错 - {str(e)}")

    def start(self):
        """启动MQTT客户端"""
        # 连接MQTT服务器
        self.connect_mqtt()

        # 启动消息循环
        self.client.loop_start()

        # 订阅主题
        self.client.subscribe("box/qwer/data/command")  # 替换为需要的主题
        print("系统：MQTT客户端已启动，等待消息...")

    def publish_result(self, classification, pv_index):
        """发布诊断结果"""
        try:
            # 这里根据实际需要实现发布逻辑
            print(f"系统：发布诊断结果 - 光伏{pv_index}: {classification}")
        except Exception as e:
            print(f"系统：发布诊断结果异常 - {e}")

    def publish_mppt_data(self, vol_max, cur_max, pow_max, pv_index):
        """发布MPPT数据"""
        try:
            # 这里根据实际需要实现发布逻辑
            print(f"系统：发布MPPT数据 - 光伏{pv_index}: V={vol_max}, I={cur_max}, P={pow_max}")
        except Exception as e:
            print(f"系统：发布MPPT数据异常 - {e}")

    def publish_mode1_data(self, voltage, current, power, temperature, pv_index):
        """发布模式1数据"""
        try:
            # 这里根据实际需要实现发布逻辑
            print(f"系统：发布模式1数据 - 光伏{pv_index}: V={voltage}, I={current}, P={power}, T={temperature}")
        except Exception as e:
            print(f"系统：发布模式1数据异常 - {e}")


# 主程序入口
if __name__ == "__main__":
    # 创建MQTT客户端实例
    mqtt_client = MqttClient(None)
    
    # 创建TCP服务器实例
    tcp_server = TcpServer(mqtt_client)
    
    # 将TCP服务器实例传递给MQTT客户端
    mqtt_client.tcp_server = tcp_server
    
    # 启动MQTT客户端
    mqtt_client.start()
    
    # 启动TCP服务器（这将阻塞主线程）
    tcp_server.start()