import sys
import datetime
import json
import time
import random
import schedule
from threading import Thread
#from CON_NET.tcp_server import TcpServer
try:
    import paho.mqtt.client as mqtt
except ImportError:
    print("MQTT client not found. Please install as follows:")
    print("git clone http://git.eclipse.org/gitroot/paho/org.eclipse.paho.mqtt.python.git")
    print("cd org.eclipse.paho.mqtt.python")
    print("sudo python setup.py install")


class MqttClient:
    def __init__(self):
        # 服务器地址
        self.strBroker = "1.92.66.67"
        # 通信端口
        self.port = 1883
        # 用户名
        self.username = 'admin'
        # 密码
        self.password = 'public'
        # 客户端ID
        self.clientId = "box/qwer/data"  # 为序列号
        # 发布主题
        self.publish_topic = "box/qwer/data"  # 发布主题保持不变
        # 订阅主题
        self.subscribe_topic = "box/qwer/data"  # 修改为新的订阅主题

        self.client = mqtt.Client(client_id=self.clientId)
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.client.on_subscribe = self.on_subscribe
        self.client.username_pw_set(self.username, password=self.password)
        self.client.connect(self.strBroker, self.port, 600)  # 600为keepalive的时间间隔
        self.curtime = datetime.datetime.now()
        #self.tcp_sent = TcpServer(MqttClient)
        self.msg_count = 0
        self.cur = [10, 20, 30, 40, 50, 60, 70]
        self.abc = 0
        self.vol = 18.5
        self.cur = 0.2
        self.pow = 3.7
        self.temp = 22.78
        self.get_plates = 1
        # 初始化 result 计数器
        self.result_counts = {
            "normal": 0,
            "short": 0,
            "open": 0,
            "shelter": 0,
            "oled": 0
        }
        self.result_map = {
            0: "normal",
            1: "short",
            2: "open",
            3: "shelter",
            4: "oled"
        }

    def reset_counts(self):
        for key in self.result_counts:
            self.result_counts[key] = 0

    def on_connect(self, client, userdata, flags, rc):
        print(self.get_time(),"OnConnect, rc: " + str(rc))
        # 订阅新的主题
        self.client.subscribe(self.subscribe_topic, 0)


    def on_subscribe(self, client, obj, mid, granted_qos):
        print(self.get_time(),"Subscribed: " + str(mid) + " " + str(granted_qos))

    def on_message(self, client, obj, msg):
        curtime = datetime.datetime.now()
        strcurtime = curtime.strftime("%Y-%m-%d %H:%M:%S")
        # 这里调用被移除了
        # self.on_exec(str(msg.payload))

    def get_time(self):
        return '[' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + ']'
    ###############################################################---发送部分应用--########################################################



    def publish_msg(self, msg):
        msg_send = json.dumps(msg, separators=(',', ':'))
        # 使用发布主题进行发布
        result = self.client.publish(self.publish_topic, msg_send)
        status = result[0]
        #if status == 0:
        #    print(f"Message published successfully to {self.publish_topic}")
        #else:
        #   print(f"Failed to publish message to {self.publish_topic}")

    #故障诊断数据累加（内部调用）
    def publish_add_results(self,result,PV_select):
        if result == 0:
            msg = {"id": "qwer", "values": {f"normal{PV_select}": 1}}
        elif result == 1:
            msg = {"id": "qwer", "values": {f"short{PV_select}": 1}}
        elif result == 2:
            msg = {"id": "qwer", "values": {f"open{PV_select}": 1}}
        elif result == 3:
            msg = {"id": "qwer", "values": {f"shelter{PV_select}": 1}}
        elif result == 4:
            msg = {"id": "qwer", "values": {f"oled{PV_select}": 1}}
        self.publish_msg(msg)

    # 光伏故障预测结果（外部调用）
    def publish_result(self, result,PV_select):#(诊断结果，光伏标号)
        self.msg_count = result
        msg = {"id": "qwer", "values": {f"zdjg{PV_select}": int(result)}}
        self.publish_msg(msg)
        self.publish_add_results(result,PV_select)

    # 上传MPPT最大功率点 电压、电流、功率（外部调用，与预测结果一起）
    def publish_mppt_data(self, vol_data, cur_data, pow_data,PV_select):#(电压，电流，功率，光伏标号)
        msg = {"id": "qwer", "values": {f"MPPTV{PV_select}": vol_data, f"MPPTA{PV_select}": cur_data, f"MPPTP{PV_select}": pow_data}}
        self.publish_msg(msg)

    # 上传运行的 输入电压、电流，输出电压、电流、输出功率，板载温度（外部调用，常运行）
    def publish_mode1_data(self, voltages, currents, powers, temp_plates,get_plates):
        self.vol = voltages
        self.cur = currents
        self.pow = powers
        self.temp = temp_plates
        self.get_plates = get_plates
        msg = {"id": "qwer",
               "values": {f"V{get_plates}": voltages, f"I{get_plates}": currents, f"P{get_plates}": powers,
                          f"tp": temp_plates}}
        self.publish_msg(msg)

    def start(self):
        # 归零计数器
        self.reset_counts()
        self.client.loop_start()
        self.vol = 0
        while True:
            time.sleep(2)


#######################################################--定时部分--#######################################################

# 定义定时任务
def time_s_task():
    #print(f"定时任务运行，当前时间：{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    #mqtt_client_instance.publish_mode1_data(mqtt_client_instance.vol, mqtt_client_instance.cur, mqtt_client_instance.pow, mqtt_client_instance.temp,mqtt_client_instance.get_plates)
    pass

# 设置定时器
def setup_scheduler():
    # 每10分钟运行一次定时任务
    #schedule.every(10).minutes.do(time_s_task)
    schedule.every(1).seconds.do(time_s_task)
    while True:
        schedule.run_pending()
        time.sleep(1)


# 创建MqttClient实例
mqtt_client_instance = MqttClient()

# 启动定时任务调度器
Thread(target=setup_scheduler).start()

