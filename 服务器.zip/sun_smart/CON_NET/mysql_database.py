import pymysql
from typing import Union, List


def write_data_to_tables(powers_list: Union[List[float], List[List[float]]],
                         currents_list: Union[List[float], List[List[float]]],
                         voltages_list: Union[List[float], List[List[float]]],
                         table_indices: Union[int, List[int]] = None):
    """
    将P、I、V数据写入到指定的qx表中，支持单组或多组数据。

    参数:
        powers_list: 功率数据，可以是单个列表[p1, p2, p3...]或嵌套列表[[p1, p2, p3...], [p1, p2, p3...], ...]
        currents_list: 电流数据，可以是单个列表[i1, i2, i3...]或嵌套列表[[i1, i2, i3...], [i1, i2, i3...], ...]
        voltages_list: 电压数据，可以是单个列表[v1, v2, v3...]或嵌套列表[[v1, v2, v3...], [v1, v2, v3...], ...]
        table_indices: 指定写入的表索引，可以是单个整数(0-4)或整数列表[0,1,3,...]，不指定时按照数据顺序写入

    返回:
        bool: 操作是否成功
    """
    conn = None
    cursor = None

    # 检查输入格式并规范化为嵌套列表格式
    # 判断是否为单组数据（单个列表）
    is_single_group = powers_list and not isinstance(powers_list[0], list)
    if is_single_group:
        powers_list = [powers_list]
        currents_list = [currents_list]
        voltages_list = [voltages_list]

    # 处理表索引参数
    if table_indices is None:
        # 如果未指定表索引，则按顺序使用0,1,2,...
        table_indices = list(range(len(powers_list)))
    elif isinstance(table_indices, int):
        # 如果是单个整数，转换为列表
        table_indices = [table_indices]
        # 如果是单组数据且指定了单个表索引，只用这个表
        if is_single_group and len(table_indices) == 1:
            pass
        # 如果是多组数据但只指定了一个表索引，复制这个索引以匹配数据组数
        elif len(table_indices) != len(powers_list):
            table_indices = [table_indices[0]] * len(powers_list)

    # 确保表索引数量与数据组数量匹配
    if len(table_indices) != len(powers_list):
        raise ValueError(f"表索引数量({len(table_indices)})与数据组数量({len(powers_list)})不匹配")

    # 验证三个列表长度是否相同
    if len(powers_list) != len(currents_list) or len(powers_list) != len(voltages_list):
        raise ValueError("输入的powers_list、currents_list和voltages_list必须包含相同数量的数据组")

    # 验证每组数据内部长度是否相等
    for i, (powers, currents, voltages) in enumerate(zip(powers_list, currents_list, voltages_list)):
        if len(powers) != len(currents) or len(powers) != len(voltages):
            raise ValueError(f"第{i}组数据中的功率、电流和电压列表长度不一致")

    # 验证表索引是否在有效范围内
    for idx in table_indices:
        if not 0 <= idx <= 6:
            raise ValueError(f"表索引必须在0-6范围内，收到无效索引: {idx}")

    try:
        # 连接到数据库
        conn = pymysql.connect(
            host="1.92.66.67",
            user="SUN_DATA",
            password="SUN123456",
            database="sun_data"
        )
        cursor = conn.cursor()

        # 检查数据库连接
        if not conn.open:
            raise ConnectionError("数据库连接失败")

        # 遍历数据组，写入到指定的表中
        for data_index, (powers, currents, voltages) in enumerate(zip(powers_list, currents_list, voltages_list)):
            # 获取当前数据组对应的表索引
            table_index = table_indices[data_index]

            # 确定表名
            table_name = f"qx{table_index}"

            # 检查表是否存在
            cursor.execute(f"SHOW TABLES LIKE '{table_name}'")
            if cursor.fetchone() is None:
                print(f"警告: 表 {table_name} 不存在，跳过此组数据")
                continue

            try:
                # 清空目标表数据
                cursor.execute(f"TRUNCATE TABLE {table_name}")

                # 构造插入数据的SQL语句
                insert_query = f"INSERT INTO {table_name} (P, I, V) VALUES (%s, %s, %s)"

                # 准备数据
                data = [(float(p), float(i), float(v)) for p, i, v in zip(powers, currents, voltages)]

                # 将数据插入到表中
                cursor.executemany(insert_query, data)

                print(f"数据已成功写入到表 {table_name} 中，共 {len(data)} 条记录。")

            except pymysql.Error as err:
                print(f"写入表 {table_name} 时出错: {err}")
                conn.rollback()  # 回滚该表的操作

        # 提交事务
        conn.commit()
        return True

    except pymysql.Error as err:
        print(f"数据库错误: {err}")
        if conn:
            conn.rollback()
        return False
    except Exception as ex:
        print(f"未预期的错误: {ex}")
        if conn:
            conn.rollback()
        return False
    finally:
        # 关闭资源
        if cursor:
            cursor.close()
        if conn and conn.open:
            conn.close()

