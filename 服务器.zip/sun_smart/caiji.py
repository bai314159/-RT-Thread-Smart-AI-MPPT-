#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
光伏数据采集Web服务器 + TCP服务端
Web界面运行在9991端口，TCP服务端监听9999端口等待客户端连接
优化版本：支持单块光伏循环采集指定次数
"""

import os
import csv
import json
import time
import socket
import threading
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_file
from flask_socketio import SocketIO, emit
import pandas as pd
import numpy as np
from threading import Lock

app = Flask(__name__)
app.config['SECRET_KEY'] = 'pv_data_collector_2025'
socketio = SocketIO(app, cors_allowed_origins="*")

class PVDataCollector:
    def __init__(self):
        # TCP服务端配置
        self.tcp_host = '0.0.0.0'  # 监听所有网络接口
        self.tcp_port = 9999       # TCP服务端口
        self.tcp_server_socket = None
        self.client_socket = None  # 当前连接的客户端
        self.client_address = None
        self.tcp_running = False
        
        # 数据采集状态
        self.collecting = False
        self.batch_collecting = False  # 批量采集状态
        self.current_pv = 1
        self.current_label = 'normal'
        self.batch_interval = 5  # 批量采集间隔（秒）
        
        # 数据存储
        self.csv_file = 'data5.csv'
        self.collected_data = []
        self.receiving_data = False
        self.data_buffer = ""
        
        # 批量采集控制
        self.batch_pv = 1
        self.batch_count_target = 10  # 目标采集次数
        self.batch_count_current = 0  # 当前已采集次数
        self.batch_label = 'normal'
        
        # 线程安全锁
        self.lock = Lock()
        
        # 统计信息
        self.collection_stats = {
            'total': 0,
            'normal': 0,
            'open': 0,
            'short': 0,
            'shelter': 0,
            'old': 0
        }
        
        # 初始化CSV文件
        self.init_csv_file()
        
        # 启动TCP服务端
        self.start_tcp_server()
    
    def init_csv_file(self):
        """初始化CSV文件，创建列标题"""
        if not os.path.exists(self.csv_file):
            # 创建列标题：vol1, cur1, vol2, cur2, ..., vol80, cur80, label
            columns = []
            for i in range(1, 81):
                columns.extend([f'vol{i}', f'cur{i}'])
            columns.append('label')
            
            # 创建空的DataFrame并保存
            df = pd.DataFrame(columns=columns)
            df.to_csv(self.csv_file, index=False)
            print(f"✅ 创建数据文件: {self.csv_file}")
        else:
            # 加载现有数据并更新统计
            self.update_stats_from_csv()
    
    def update_stats_from_csv(self):
        """从CSV文件更新统计信息"""
        try:
            if os.path.exists(self.csv_file):
                df = pd.read_csv(self.csv_file)
                if not df.empty and 'label' in df.columns:
                    label_counts = df['label'].value_counts()
                    self.collection_stats['total'] = len(df)
                    for label in ['normal', 'open', 'short', 'shelter', 'old']:
                        self.collection_stats[label] = int(label_counts.get(label, 0))
        except Exception as e:
            print(f"❌ 更新统计信息失败: {e}")
    
    def start_tcp_server(self):
        """启动TCP服务端，等待客户端连接"""
        def server_worker():
            try:
                self.tcp_server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.tcp_server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                self.tcp_server_socket.bind((self.tcp_host, self.tcp_port))
                self.tcp_server_socket.listen(1)
                self.tcp_running = True
                
                print(f"🚀 TCP服务端启动，监听端口: {self.tcp_port}")
                print(f"⏳ 等待客户端连接...")
                
                while self.tcp_running:
                    try:
                        # 等待客户端连接
                        client_socket, client_address = self.tcp_server_socket.accept()
                        
                        print(f"✅ 客户端已连接: {client_address}")
                        
                        # 更新连接状态
                        with self.lock:
                            self.client_socket = client_socket
                            self.client_address = client_address
                        
                        # 通知前端连接状态
                        socketio.emit('connection_status', {
                            'connected': True, 
                            'client_address': f"{client_address[0]}:{client_address[1]}"
                        })
                        
                        # 启动客户端处理线程
                        client_thread = threading.Thread(
                            target=self.handle_client, 
                            args=(client_socket, client_address), 
                            daemon=True
                        )
                        client_thread.start()
                        
                    except socket.error as e:
                        if self.tcp_running:
                            print(f"❌ TCP服务端错误: {e}")
                            time.sleep(1)
                        break
                    except Exception as e:
                        print(f"❌ TCP服务端异常: {e}")
                        break
                        
            except Exception as e:
                print(f"❌ 启动TCP服务端失败: {e}")
            
            finally:
                if self.tcp_server_socket:
                    try:
                        self.tcp_server_socket.close()
                    except:
                        pass
                print("🔌 TCP服务端已关闭")
        
        # 启动服务端线程
        server_thread = threading.Thread(target=server_worker, daemon=True)
        server_thread.start()
    
    def handle_client(self, client_socket, client_address):
        """处理客户端连接"""
        try:
            while True:
                try:
                    # 接收客户端数据
                    data = client_socket.recv(4096).decode('utf-8', 'ignore')
                    if not data:
                        print(f"❌ 客户端 {client_address} 断开连接")
                        break
                    
                    # 处理接收到的数据
                    self.process_received_data(data)
                    
                except ConnectionResetError:
                    print(f"❌ 客户端 {client_address} 连接重置")
                    break
                except Exception as e:
                    print(f"❌ 处理客户端数据错误: {e}")
                    break
        
        except Exception as e:
            print(f"❌ 客户端处理线程错误: {e}")
        
        finally:
            # 清理连接
            with self.lock:
                if self.client_socket == client_socket:
                    self.client_socket = None
                    self.client_address = None
            
            try:
                client_socket.close()
            except:
                pass
            
            print(f"🔌 客户端 {client_address} 连接已关闭")
            
            # 通知前端连接断开
            socketio.emit('connection_status', {'connected': False})
    
    def process_received_data(self, data):
        """处理接收到的数据"""
        with self.lock:
            if "start" in data:
                self.receiving_data = True
                self.data_buffer = ""
                print("📥 开始接收IV曲线数据...")
                socketio.emit('data_status', {'status': 'receiving', 'message': '正在接收数据...'})
                
            elif "over" in data and self.receiving_data:
                self.receiving_data = False
                print("📥 IV曲线数据接收完毕")
                
                # 处理完整的数据
                try:
                    self.process_iv_data(self.data_buffer)
                except Exception as e:
                    print(f"❌ 处理IV数据错误: {e}")
                    socketio.emit('data_status', {'status': 'error', 'message': f'数据处理错误: {e}'})
                
                self.data_buffer = ""
                
                # 检查是否需要继续批量采集
                if self.batch_collecting:
                    print(f"⏰ {self.batch_interval}秒后继续下一次采集...")
                    threading.Timer(self.batch_interval, self.batch_collect_next).start()
                
            elif self.receiving_data:
                # 累积数据
                clean_data = data.strip().replace("start", "").replace("over", "")
                self.data_buffer += clean_data
    
    def process_iv_data(self, raw_data):
        """处理IV曲线数据并保存到CSV"""
        try:
            # 数据清理
            cleaned_data = self.clean_data(raw_data)
            if not cleaned_data:
                raise ValueError("数据清理失败")
            
            # 转换为数值
            values = [float(x) for x in cleaned_data.split(',')]
            if len(values) % 2 != 0:
                raise ValueError(f"数据长度不匹配: 期望偶数个值，实际{len(values)}个")
            
            # 调整IV曲线长度到160个值（80对）
            iv_curve = self.adjust_iv_curve(values)
            
            # 保存到CSV
            self.save_to_csv(iv_curve, self.current_label)
            
            # 更新统计
            self.collection_stats['total'] += 1
            self.collection_stats[self.current_label] += 1
            
            # 计算基本参数
            voltages = iv_curve[0::2]
            currents = iv_curve[1::2]
            powers = [voltages[i] * abs(currents[i]) for i in range(len(voltages))]
            
            # 过滤无效值
            valid_powers = [p for p in powers if not (np.isnan(p) or np.isinf(p))]
            if valid_powers:
                max_power = max(valid_powers)
                max_index = powers.index(max_power)
                max_voltage = voltages[max_index]
                max_current = currents[max_index]
            else:
                max_power = 0.0
                max_voltage = 0.0
                max_current = 0.0
            
            # 更新批量采集进度
            if self.batch_collecting:
                self.batch_count_current += 1
                progress = (self.batch_count_current / self.batch_count_target) * 100
                socketio.emit('batch_progress', {
                    'current': self.batch_count_current,
                    'target': self.batch_count_target,
                    'progress': progress,
                    'pv': self.batch_pv,
                    'label': self.batch_label
                })
            
            # 重置单次采集状态
            self.collecting = False
            
            # 发送结果到前端
            result = {
                'success': True,
                'pv_index': self.current_pv,
                'label': self.current_label,
                'data_points': len(iv_curve) // 2,
                'max_power': round(max_power, 4),
                'max_voltage': round(max_voltage, 4),
                'max_current': round(max_current, 4),
                'timestamp': datetime.now().strftime('%H:%M:%S'),
                'stats': self.collection_stats.copy(),
                'batch_info': {
                    'is_batch': self.batch_collecting,
                    'current': self.batch_count_current if self.batch_collecting else None,
                    'target': self.batch_count_target if self.batch_collecting else None
                }
            }
            
            socketio.emit('collection_result', result)
            print(f"✅ 数据保存成功 - PV{self.current_pv}, 标签:{self.current_label}, 最大功率:{max_power:.4f}W")
            
            # 如果是批量采集，输出详细状态
            if self.batch_collecting:
                print(f"📊 批量采集进度: {self.batch_count_current}/{self.batch_count_target}")
            
            # 如果是批量采集且已完成，则停止
            if self.batch_collecting and self.batch_count_current >= self.batch_count_target:
                print("🎉 批量采集已完成所有目标次数")
                self.stop_batch_collection()
            
        except Exception as e:
            error_msg = f"处理数据失败: {str(e)}"
            print(f"❌ {error_msg}")
            socketio.emit('data_status', {'status': 'error', 'message': error_msg})
            self.collecting = False
    
    def clean_data(self, data):
        """数据清理函数"""
        try:
            # 替换换行符、回车符和空格
            data = data.replace('\n', '').replace('\r', '').replace(' ', '')
            data = data.replace(',,', ',').replace(';', ',')
            
            # 处理负号和数字
            fixed_data = []
            num_buffer = ''
            sign = ''
            
            for char in data:
                if char == '-':
                    sign = char
                elif char.isdigit() or char == '.':
                    num_buffer += char
                elif char == ',':
                    if num_buffer:
                        full_number = sign + num_buffer
                        fixed_data.append(full_number)
                        sign = ''
                        num_buffer = ''
                    fixed_data.append(',')
            
            # 处理最后一个数字
            if num_buffer:
                full_number = sign + num_buffer
                fixed_data.append(full_number)
            
            cleaned_data = ''.join(fixed_data)
            
            # 如果以逗号结尾，删除最后一个逗号
            if cleaned_data.endswith(','):
                cleaned_data = cleaned_data[:-1]
            
            return cleaned_data if cleaned_data else None
            
        except Exception as e:
            print(f"❌ 数据清理错误: {e}")
            return None
    
    def adjust_iv_curve(self, iv_curve):
        """调整IV曲线长度到160个值（80对电压电流）"""
        target_length = 160
        
        if len(iv_curve) < target_length:
            # 数据不足，使用插值补充
            voltages = np.array(iv_curve[0::2])
            currents = np.array(iv_curve[1::2])
            
            # 简单线性插值
            try:
                from scipy.interpolate import interp1d
                if len(voltages) > 1:
                    f_interp = interp1d(voltages, currents, kind='linear', fill_value='extrapolate')
                    
                    # 生成新的电压点
                    needed_pairs = (target_length - len(iv_curve)) // 2
                    if needed_pairs > 0:
                        v_min, v_max = voltages.min(), voltages.max()
                        step = (v_max - v_min) / (len(voltages) - 1) if len(voltages) > 1 else 0.1
                        
                        new_voltages = []
                        for i in range(needed_pairs):
                            new_v = v_max + step * (i + 1)
                            new_voltages.append(new_v)
                        
                        new_currents = f_interp(new_voltages)
                        
                        # 添加新的电压电流对
                        for v, i in zip(new_voltages, new_currents):
                            iv_curve.extend([round(v, 2), round(i, 2)])
            except ImportError:
                # 如果没有scipy，使用简单的线性延拓
                while len(iv_curve) < target_length:
                    iv_curve.extend([0.0, 0.0])
        
        elif len(iv_curve) > target_length:
            # 数据过多，截断
            iv_curve = iv_curve[:target_length]
        
        return iv_curve
    
    def save_to_csv(self, iv_curve, label):
        """保存数据到CSV文件"""
        try:
            # 准备数据行
            data_row = iv_curve + [label]
            
            # 追加到CSV文件
            with open(self.csv_file, 'a', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(data_row)
            
            print(f"✅ 数据已保存到 {self.csv_file}")
            
        except Exception as e:
            print(f"❌ 保存CSV失败: {e}")
            raise e
    
    def send_collection_command(self, pv_index):
        """发送采集指令给客户端"""
        with self.lock:
            if not self.client_socket:
                raise Exception("没有客户端连接")
        
        command = f"Z,1,2,2,{pv_index},T\n"
        try:
            self.client_socket.send(command.encode('utf-8'))
            print(f"📤 发送采集指令: PV{pv_index}")
            return True
        except Exception as e:
            print(f"❌ 发送指令失败: {e}")
            # 清理无效连接
            with self.lock:
                self.client_socket = None
                self.client_address = None
            socketio.emit('connection_status', {'connected': False})
            raise e
    
    def start_collection(self, pv_index, label, force=False):
        """开始单次采集"""
        with self.lock:
            if self.collecting and not force:
                raise Exception("正在采集中，请等待完成")
            
            self.collecting = True
            self.current_pv = pv_index
            self.current_label = label
        
        try:
            self.send_collection_command(pv_index)
            socketio.emit('data_status', {
                'status': 'collecting', 
                'message': f'开始采集PV{pv_index}数据...',
                'pv_index': pv_index,
                'label': label
            })
        except Exception as e:
            with self.lock:
                self.collecting = False
            raise e
    
    def start_batch_collection(self, pv_index, label, count, interval):
        """开始批量采集"""
        with self.lock:
            if self.batch_collecting:
                raise Exception("批量采集已在进行中")
            
            self.batch_collecting = True
            self.batch_pv = pv_index
            self.batch_label = label
            self.batch_count_target = count
            self.batch_count_current = 0
            self.batch_interval = interval
        
        print(f"🔄 开始批量采集: PV{pv_index}, 标签:{label}, 次数:{count}, 间隔:{interval}秒")
        
        # 发送批量采集开始状态
        socketio.emit('batch_collection_status', {
            'running': True,
            'pv': pv_index,
            'label': label,
            'target': count,
            'current': 0,
            'progress': 0
        })
        
        # 开始第一次采集
        self.direct_batch_collect()
    
    def direct_batch_collect(self):
        """直接进行批量采集，绕过状态检查"""
        if not self.batch_collecting:
            return
            
        if self.batch_count_current >= self.batch_count_target:
            print("✅ 批量采集完成")
            self.stop_batch_collection()
            return
        
        print(f"📤 直接发送批量采集指令: PV{self.batch_pv} (第{self.batch_count_current + 1}次)")
        
        try:
            # 直接发送指令
            with self.lock:
                self.collecting = True
                self.current_pv = self.batch_pv
                self.current_label = self.batch_label
            
            self.send_collection_command(self.batch_pv)
            
            socketio.emit('data_status', {
                'status': 'collecting', 
                'message': f'批量采集PV{self.batch_pv}... ({self.batch_count_current + 1}/{self.batch_count_target})',
                'pv_index': self.batch_pv,
                'label': self.batch_label
            })
            
        except Exception as e:
            print(f"❌ 批量采集发送指令失败: {e}")
            self.stop_batch_collection()

    def batch_collect_next(self):
        """批量采集下一次"""
        print(f"🔄 准备下一次采集: 当前{self.batch_count_current}/{self.batch_count_target}")
        
        if not self.batch_collecting:
            print("❌ 批量采集已停止，取消下一次采集")
            return
        
        if self.batch_count_current >= self.batch_count_target:
            print("✅ 批量采集目标已达成，准备停止")
            self.stop_batch_collection()
            return
        
        # 使用直接采集方法
        self.direct_batch_collect()
    
    def stop_batch_collection(self):
        """停止批量采集"""
        with self.lock:
            if not self.batch_collecting:
                return
                
            completed = self.batch_count_current >= self.batch_count_target
            self.batch_collecting = False
            self.collecting = False
        
        message = "批量采集完成" if completed else "批量采集已停止"
        print(f"✅ {message}")
        
        socketio.emit('batch_collection_status', {
            'running': False,
            'completed': completed,
            'message': message,
            'final_count': self.batch_count_current
        })
    
    def is_connected(self):
        """检查是否有客户端连接"""
        with self.lock:
            return self.client_socket is not None
    
    def get_client_info(self):
        """获取客户端连接信息"""
        with self.lock:
            if self.client_address:
                return f"{self.client_address[0]}:{self.client_address[1]}"
            return None

# 创建全局实例
collector = PVDataCollector()

# Web路由
@app.route('/')
def index():
    """主页面"""
    return render_template('index.html')

@app.route('/api/status')
def get_status():
    """获取系统状态"""
    return jsonify({
        'connected': collector.is_connected(),
        'client_info': collector.get_client_info(),
        'collecting': collector.collecting,
        'batch_collecting': collector.batch_collecting,
        'batch_info': {
            'pv': collector.batch_pv if collector.batch_collecting else None,
            'current': collector.batch_count_current if collector.batch_collecting else None,
            'target': collector.batch_count_target if collector.batch_collecting else None
        },
        'stats': collector.collection_stats
    })

@app.route('/api/collect', methods=['POST'])
def start_collect():
    """开始单次采集"""
    try:
        data = request.get_json()
        pv_index = int(data.get('pv_index', 1))
        label = data.get('label', 'normal')
        
        if pv_index < 1 or pv_index > 4:
            return jsonify({'success': False, 'message': '光伏索引必须在1-4之间'})
        
        if label not in ['normal', 'open', 'short', 'shelter', 'old']:
            return jsonify({'success': False, 'message': '无效的标签类型'})
        
        collector.start_collection(pv_index, label)
        return jsonify({'success': True, 'message': f'开始采集PV{pv_index}'})
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/batch_collect', methods=['POST'])
def start_batch_collect():
    """开始批量采集"""
    try:
        data = request.get_json()
        pv_index = int(data.get('pv_index', 1))
        label = data.get('label', 'normal')
        count = int(data.get('count', 10))
        interval = int(data.get('interval', 5))
        
        if pv_index < 1 or pv_index > 4:
            return jsonify({'success': False, 'message': '光伏索引必须在1-4之间'})
        
        if count < 1 or count > 1000:
            return jsonify({'success': False, 'message': '采集次数必须在1-1000之间'})
        
        if interval < 1:
            return jsonify({'success': False, 'message': '间隔时间必须大于0秒'})
        
        collector.start_batch_collection(pv_index, label, count, interval)
        return jsonify({'success': True, 'message': f'开始批量采集PV{pv_index}, {count}次'})
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/stop_batch', methods=['POST'])
def stop_batch_collect():
    """停止批量采集"""
    try:
        collector.stop_batch_collection()
        return jsonify({'success': True, 'message': '批量采集已停止'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/download')
def download_csv():
    """下载CSV文件"""
    try:
        if os.path.exists(collector.csv_file):
            return send_file(collector.csv_file, as_attachment=True, download_name='pv_data.csv')
        else:
            return jsonify({'success': False, 'message': 'CSV文件不存在'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

# WebSocket事件
@socketio.on('connect')
def handle_connect():
    """客户端连接"""
    print('📱 Web客户端已连接')
    emit('connection_status', {
        'connected': collector.is_connected(),
        'client_info': collector.get_client_info()
    })
    emit('collection_stats', collector.collection_stats)

@socketio.on('disconnect')
def handle_disconnect():
    """客户端断开"""
    print('📱 Web客户端已断开')

if __name__ == '__main__':
    print("🚀 启动光伏数据采集系统...")
    print(f"🌐 Web管理界面: http://localhost:9993")
    print(f"🔗 TCP服务端监听: 0.0.0.0:9999")
    print(f"📊 数据文件: {collector.csv_file}")
    print("⏳ 等待TCP客户端连接...")
    
    # 创建templates目录
    os.makedirs('templates', exist_ok=True)
    
    try:
        # 启动Flask应用
        socketio.run(app, host='0.0.0.0', port=9993, debug=False)
    except KeyboardInterrupt:
        print("\n🛑 正在关闭服务...")
        collector.tcp_running = False
    except Exception as e:
        print(f"❌ 启动失败: {e}")
    finally:
        print("👋 服务已关闭")