import numpy as np
import pandas as pd
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import VotingClassifier, StackingClassifier
from sklearn.preprocessing import StandardScaler, RobustScaler, PowerTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV, StratifiedKFold, cross_val_score
from sklearn.feature_selection import SelectFromModel, SelectKBest, f_classif, mutual_info_classif
from scipy.fft import fft
from scipy.signal import find_peaks, savgol_filter
from sklearn.metrics import classification_report, accuracy_score, f1_score
import xgboost as xgb
from sklearn.decomposition import PCA
import joblib
import os
import warnings
import time
import pickle

# 忽略警告
warnings.filterwarnings('ignore')

# 全局变量存储模型状态
_models_initialized = False
_preprocessor = None
_feature_selector = None
_pca = None
_svm_model = None
_rf_model = None
_gb_model = None
_xgb_model = None
_mlp_model = None
_ada_model = None
_ensemble_model = None
_feature_importance = None
_class_thresholds = None  # 类别特定阈值
_model_weights = None  # 各模型权重


def label_mapping(label):
    """将文本标签映射为数字"""
    label_dict = {'normal': 0, 'short': 1, 'open': 2, 'shelter': 3, 'old': 4}
    return label_dict.get(label, -1)  # 返回-1表示未知类别


def reverse_label_mapping(label_num):
    """将数字映射回文本标签"""
    label_dict = {0: 'normal', 1: 'short', 2: 'open', 3: 'shelter', 4: 'old'}
    return label_dict.get(label_num, 'unknown')


def safe_division(a, b, default=0.0):
    """安全除法，避免除以零的错误"""
    return np.divide(a, b, out=np.full_like(a, default, dtype=float), where=b != 0)


def normalize_curve(curve, norm_type='minmax'):
    """标准化曲线，以便更好地比较形状"""
    if norm_type == 'minmax':
        min_val = np.min(curve)
        max_val = np.max(curve)
        if max_val - min_val < 1e-6:
            return np.zeros_like(curve)
        return (curve - min_val) / (max_val - min_val)
    elif norm_type == 'max':
        max_val = np.max(np.abs(curve))
        if max_val < 1e-6:
            return np.zeros_like(curve)
        return curve / max_val
    else:
        return curve


def extract_curve_features(curve, n_peaks=3):
    """提取曲线的关键特征点"""
    # 平滑处理
    try:
        smooth_curve = savgol_filter(curve, 7, 3)
    except:
        smooth_curve = curve

    # 查找峰值
    try:
        peaks, _ = find_peaks(smooth_curve)
        peak_heights = smooth_curve[peaks] if len(peaks) > 0 else []

        # 提取最高的n_peaks个峰值
        if len(peak_heights) > 0:
            top_peak_idx = np.argsort(peak_heights)[-n_peaks:]
            top_peaks = peaks[top_peak_idx]
            top_heights = peak_heights[top_peak_idx]
        else:
            top_peaks = []
            top_heights = []

        # 补齐不足的峰值位置和高度
        while len(top_peaks) < n_peaks:
            top_peaks = np.append(top_peaks, 0)
            top_heights = np.append(top_heights, 0)

        # 计算曲线的曲率
        try:
            dx = np.gradient(smooth_curve)
            ddx = np.gradient(dx)
            curvature = np.abs(ddx) / (1 + dx ** 2) ** 1.5
            mean_curvature = np.mean(curvature)
            max_curvature = np.max(curvature)
        except:
            mean_curvature = 0
            max_curvature = 0

        features = np.concatenate([
            top_peaks / len(curve),  # 标准化位置
            top_heights,
            [np.mean(smooth_curve), np.std(smooth_curve)],
            [mean_curvature, max_curvature]
        ])

        return features
    except Exception as e:
        # 如果特征提取失败，返回零向量
        return np.zeros(2 * n_peaks + 4)


def detect_curve_anomalies(curve, window_size=5, threshold=2.0):
    """检测曲线中的异常点和不连续点"""
    if len(curve) <= window_size:
        return 0, 0

    # 计算局部平均值和标准差
    local_means = np.array([np.mean(curve[max(0, i - window_size):min(len(curve), i + window_size + 1)])
                            for i in range(len(curve))])
    local_stds = np.array([np.std(curve[max(0, i - window_size):min(len(curve), i + window_size + 1)])
                           for i in range(len(curve))])

    # 计算z分数
    with np.errstate(divide='ignore', invalid='ignore'):
        z_scores = np.abs((curve - local_means) / local_stds)
    z_scores = np.nan_to_num(z_scores)

    # 计算一阶差分
    diffs = np.abs(np.diff(curve))
    mean_diff = np.mean(diffs)
    std_diff = np.std(diffs)

    # 计算异常点数量
    anomaly_count = np.sum(z_scores > threshold)

    # 计算不连续点数量
    with np.errstate(divide='ignore', invalid='ignore'):
        discontinuity_count = np.sum(diffs > (mean_diff + threshold * std_diff))
    discontinuity_count = int(discontinuity_count) if np.isfinite(discontinuity_count) else 0

    return anomaly_count, discontinuity_count


def advanced_feature_extraction(data):
    """从IV曲线数据中提取高级特征，增强鲁棒性和区分能力"""
    n_samples = data.shape[0]

    # 提取基本的IV曲线特征
    voltages = np.zeros((n_samples, 80))
    currents = np.zeros((n_samples, 80))

    # 将数据分割为电压和电流
    for i in range(80):
        voltages[:, i] = data.iloc[:, 2 * i].values
        currents[:, i] = data.iloc[:, 2 * i + 1].values

    # 处理异常值：使用99%置信区间处理异常点
    for i in range(n_samples):
        v_mean, v_std = np.mean(voltages[i]), np.std(voltages[i])
        i_mean, i_std = np.mean(currents[i]), np.std(currents[i])

        v_mask = np.abs(voltages[i] - v_mean) > 3 * v_std
        i_mask = np.abs(currents[i] - i_mean) > 3 * i_std

        if np.sum(v_mask) > 0:
            voltages[i, v_mask] = np.interp(
                np.where(v_mask)[0],
                np.where(~v_mask)[0],
                voltages[i, ~v_mask]
            )

        if np.sum(i_mask) > 0:
            currents[i, i_mask] = np.interp(
                np.where(i_mask)[0],
                np.where(~i_mask)[0],
                currents[i, ~i_mask]
            )

    # 平滑处理
    smooth_voltages = np.copy(voltages)
    smooth_currents = np.copy(currents)

    for i in range(n_samples):
        try:
            smooth_voltages[i] = savgol_filter(voltages[i], 7, 3)
            smooth_currents[i] = savgol_filter(currents[i], 7, 3)
        except:
            # 如果平滑失败，保持原始数据
            pass

    # 计算功率曲线
    power = smooth_voltages * smooth_currents

    # 1. 提取基本特征
    # 最大功率点特征
    max_power_idx = np.argmax(power, axis=1)
    max_power = np.max(power, axis=1)

    # 安全提取MPP点的电压和电流
    v_mpp = np.zeros(n_samples)
    i_mpp = np.zeros(n_samples)
    for i in range(n_samples):
        v_mpp[i] = smooth_voltages[i, max_power_idx[i]]
        i_mpp[i] = smooth_currents[i, max_power_idx[i]]

    # 开路电压和短路电流
    v_oc = np.max(smooth_voltages, axis=1)
    i_sc = np.max(smooth_currents, axis=1)

    # 确保不为零，避免除法错误
    v_oc = np.maximum(v_oc, 1e-6)
    i_sc = np.maximum(i_sc, 1e-6)
    v_mpp = np.maximum(v_mpp, 1e-6)
    i_mpp = np.maximum(i_mpp, 1e-6)

    # 填充因子
    ff = safe_division(max_power, (v_oc * i_sc))

    # 2. IV曲线形状特征
    # 2.1 电流-电压比率特征
    iv_ratio_start = safe_division(smooth_currents[:, :10].mean(axis=1), smooth_voltages[:, :10].mean(axis=1))
    iv_ratio_middle = safe_division(smooth_currents[:, 30:50].mean(axis=1), smooth_voltages[:, 30:50].mean(axis=1))
    iv_ratio_end = safe_division(smooth_currents[:, -10:].mean(axis=1), smooth_voltages[:, -10:].mean(axis=1))

    iv_ratio_diff1 = iv_ratio_start - iv_ratio_middle
    iv_ratio_diff2 = iv_ratio_middle - iv_ratio_end

    # 3. 细粒度曲线特征
    iv_curve_features = []

    for i in range(n_samples):
        # 标准化曲线
        norm_v = normalize_curve(smooth_voltages[i])
        norm_i = normalize_curve(smooth_currents[i])
        norm_p = normalize_curve(power[i])

        # 提取曲线关键特征点
        v_features = extract_curve_features(norm_v)
        i_features = extract_curve_features(norm_i)
        p_features = extract_curve_features(norm_p)

        # 检测异常点
        v_anomalies, v_discontinuities = detect_curve_anomalies(norm_v)
        i_anomalies, i_discontinuities = detect_curve_anomalies(norm_i)

        # 特征：曲线分段统计
        # 将曲线分为4个区域，计算每个区域的均值和标准差
        segment_size = len(norm_v) // 4
        v_segments = [norm_v[j:j + segment_size] for j in range(0, len(norm_v), segment_size)]
        i_segments = [norm_i[j:j + segment_size] for j in range(0, len(norm_i), segment_size)]

        v_segment_means = [np.mean(seg) for seg in v_segments[:4]]  # 取前4段
        i_segment_means = [np.mean(seg) for seg in i_segments[:4]]
        v_segment_stds = [np.std(seg) for seg in v_segments[:4]]
        i_segment_stds = [np.std(seg) for seg in i_segments[:4]]

        # 组合所有特征
        curve_features = np.concatenate([
            v_features, i_features, p_features,
            [v_anomalies, v_discontinuities, i_anomalies, i_discontinuities],
            v_segment_means, i_segment_means,
            v_segment_stds, i_segment_stds
        ])

        iv_curve_features.append(curve_features)

    iv_curve_features = np.array(iv_curve_features)
    iv_curve_features = np.nan_to_num(iv_curve_features, nan=0.0)

    # 4. 曲线斜率特征
    # 计算电流曲线的斜率变化
    i_slopes = np.zeros((n_samples, 79))
    v_slopes = np.zeros((n_samples, 79))
    for i in range(n_samples):
        i_slopes[i] = np.diff(smooth_currents[i])
        v_slopes[i] = np.diff(smooth_voltages[i])

    # 计算斜率统计特征
    i_slope_mean = np.mean(i_slopes, axis=1)
    i_slope_std = np.std(i_slopes, axis=1)
    i_slope_max = np.max(i_slopes, axis=1)
    i_slope_min = np.min(i_slopes, axis=1)

    v_slope_mean = np.mean(v_slopes, axis=1)
    v_slope_std = np.std(v_slopes, axis=1)
    v_slope_max = np.max(v_slopes, axis=1)
    v_slope_min = np.min(v_slopes, axis=1)

    # 5. 类别特定特征
    # 5.1 shelter类特征 - 检测电流曲线中的突然下降
    shelter_features = np.zeros((n_samples, 3))
    for i in range(n_samples):
        # 找出大幅下降的点
        drops = i_slopes[i][i_slopes[i] < -np.std(smooth_currents[i]) * 0.5]
        shelter_features[i, 0] = len(drops)
        shelter_features[i, 1] = np.sum(np.abs(drops)) if len(drops) > 0 else 0

        # 检测电流曲线中的局部最小值数量（可能表示部分遮挡）
        min_indices = (i_slopes[i][:-1] < 0) & (i_slopes[i][1:] > 0)
        shelter_features[i, 2] = np.sum(min_indices)

    # 5.2 open类特征 - 检测电压平台和电流突然下降
    open_features = np.zeros((n_samples, 3))
    for i in range(n_samples):
        # 电压平台检测
        v_plateaus = v_slopes[i][np.abs(v_slopes[i]) < np.std(smooth_voltages[i]) * 0.1]
        open_features[i, 0] = len(v_plateaus) / len(v_slopes[i]) if len(v_slopes[i]) > 0 else 0

        # 电流接近零检测
        near_zero_current = np.sum(smooth_currents[i] < np.max(smooth_currents[i]) * 0.1) / len(smooth_currents[i])
        open_features[i, 1] = near_zero_current

        # 电流曲线形状：是否在高电压区急剧下降
        high_v_region = smooth_voltages[i] > np.max(smooth_voltages[i]) * 0.7
        if np.sum(high_v_region) > 0:
            open_features[i, 2] = np.mean(smooth_currents[i][high_v_region]) / np.max(smooth_currents[i])
        else:
            open_features[i, 2] = 1.0

    # 5.3 short类特征 - 检测电压接近零和电流梯度
    short_features = np.zeros((n_samples, 3))
    for i in range(n_samples):
        # 电压接近零检测
        near_zero_voltage = np.sum(smooth_voltages[i] < np.max(smooth_voltages[i]) * 0.1) / len(smooth_voltages[i])
        short_features[i, 0] = near_zero_voltage

        # 电流梯度特征
        low_v_region = smooth_voltages[i] < np.max(smooth_voltages[i]) * 0.3
        if np.sum(low_v_region) > 0:
            short_features[i, 1] = np.std(smooth_currents[i][low_v_region]) / np.mean(
                smooth_currents[i][low_v_region]) if np.mean(smooth_currents[i][low_v_region]) > 0 else 0
        else:
            short_features[i, 1] = 0

        # 电流-电压曲线起始段斜率
        start_region = slice(0, min(10, len(smooth_currents[i])))
        if np.ptp(smooth_voltages[i][start_region]) > 1e-6:
            short_features[i, 2] = np.polyfit(smooth_voltages[i][start_region], smooth_currents[i][start_region], 1)[0]
        else:
            short_features[i, 2] = 0

    # 5.4 old类特征 - 检测整体性能下降和曲线形状变化
    old_features = np.zeros((n_samples, 3))
    for i in range(n_samples):
        # 填充因子降低
        old_features[i, 0] = ff[i]

        # 最大功率点偏移
        max_power_position = max_power_idx[i] / len(smooth_voltages[i])
        old_features[i, 1] = max_power_position

        # 功率曲线"圆滑度"降低
        power_curve = power[i]
        # 使用多项式拟合度量曲线平滑度
        x = np.arange(len(power_curve))
        try:
            poly_coef = np.polyfit(x, power_curve, 4)
            poly_fit = np.polyval(poly_coef, x)
            fit_error = np.mean((power_curve - poly_fit) ** 2) / np.var(power_curve) if np.var(power_curve) > 0 else 1
            old_features[i, 2] = fit_error
        except:
            old_features[i, 2] = 1

    # 6. 曲线的傅里叶变换特征
    try:
        fft_features_v = np.abs(fft(smooth_voltages))[:, 1:11]  # 取前10个频率分量
        fft_features_i = np.abs(fft(smooth_currents))[:, 1:11]
        # 归一化
        fft_features_v = fft_features_v / np.maximum(np.sum(fft_features_v, axis=1)[:, np.newaxis], 1e-6)
        fft_features_i = fft_features_i / np.maximum(np.sum(fft_features_i, axis=1)[:, np.newaxis], 1e-6)
        # 确保没有NaN和无穷大值
        fft_features_v = np.nan_to_num(fft_features_v, nan=0.0, posinf=1e6, neginf=-1e6)
        fft_features_i = np.nan_to_num(fft_features_i, nan=0.0, posinf=1e6, neginf=-1e6)
    except Exception:
        # 如果FFT计算失败，使用零值替代
        fft_features_v = np.zeros((n_samples, 10))
        fft_features_i = np.zeros((n_samples, 10))

    # 将所有特征组合成一个数组
    basic_features = np.column_stack([
        max_power, v_mpp, i_mpp, v_oc, i_sc, ff,
        iv_ratio_start, iv_ratio_middle, iv_ratio_end,
        iv_ratio_diff1, iv_ratio_diff2,
        i_slope_mean, i_slope_std, i_slope_max, i_slope_min,
        v_slope_mean, v_slope_std, v_slope_max, v_slope_min
    ])

    # 合并所有特征
    final_features = np.hstack([
        basic_features,
        iv_curve_features,
        shelter_features,
        open_features,
        short_features,
        old_features,
        fft_features_v,
        fft_features_i
    ])

    # 最终确保所有值都是有限的
    final_features = np.nan_to_num(final_features, nan=0.0, posinf=1e6, neginf=-1e6)

    return final_features


def optimize_class_thresholds(y_true, y_pred_proba, n_classes=5, initial_thresholds=None):
    """优化每个类别的预测阈值，提高整体准确率"""
    if initial_thresholds is None:
        initial_thresholds = [0.5] * n_classes

    thresholds = initial_thresholds.copy()
    best_f1 = 0
    best_thresholds = thresholds.copy()

    # 使用网格搜索优化阈值
    for _ in range(10):  # 进行10次优化迭代
        for i in range(n_classes):
            best_local_f1 = 0
            best_local_threshold = thresholds[i]

            # 在当前阈值附近搜索
            for delta in [-0.1, -0.05, -0.02, 0, 0.02, 0.05, 0.1]:
                new_threshold = max(0.1, min(0.9, thresholds[i] + delta))
                temp_thresholds = thresholds.copy()
                temp_thresholds[i] = new_threshold

                # 应用阈值进行预测
                y_pred = np.zeros(len(y_true), dtype=int)
                for j in range(len(y_true)):
                    probs = y_pred_proba[j]
                    # 应用阈值调整后的概率
                    adjusted_probs = probs * (1 / np.array(temp_thresholds))
                    y_pred[j] = np.argmax(adjusted_probs)

                # 计算F1分数
                f1 = f1_score(y_true, y_pred, average='weighted')

                if f1 > best_local_f1:
                    best_local_f1 = f1
                    best_local_threshold = new_threshold

            # 更新当前类别的最佳阈值
            thresholds[i] = best_local_threshold

        # 应用当前最佳阈值进行预测
        y_pred = np.zeros(len(y_true), dtype=int)
        for j in range(len(y_true)):
            probs = y_pred_proba[j]
            adjusted_probs = probs * (1 / np.array(thresholds))
            y_pred[j] = np.argmax(adjusted_probs)

        # 计算总体F1分数
        f1 = f1_score(y_true, y_pred, average='weighted')

        if f1 > best_f1:
            best_f1 = f1
            best_thresholds = thresholds.copy()

    return best_thresholds, best_f1


def optimize_model_weights(models, X, y, n_splits=5):
    """优化集成模型中各基础模型的权重"""
    n_models = len(models)

    # 使用交叉验证获取每个模型在每个样本上的预测概率
    kf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
    probas = [np.zeros((len(y), 5)) for _ in range(n_models)]  # 假设有5个类别

    for train_idx, test_idx in kf.split(X, y):
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]

        for i, model in enumerate(models):
            model.fit(X_train, y_train)
            probas[i][test_idx] = model.predict_proba(X_test)

    # 网格搜索优化权重
    best_f1 = 0
    best_weights = np.ones(n_models) / n_models  # 初始权重相等

    # 尝试不同的权重组合
    weight_options = [0.1, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0]

    from itertools import product
    for weights_tuple in product(weight_options, repeat=n_models):
        weights = np.array(weights_tuple)
        weights = weights / np.sum(weights)  # 归一化权重

        # 加权组合各模型的预测概率
        ensemble_proba = np.zeros_like(probas[0])
        for i in range(n_models):
            ensemble_proba += weights[i] * probas[i]

        y_pred = np.argmax(ensemble_proba, axis=1)
        f1 = f1_score(y, y_pred, average='weighted')

        if f1 > best_f1:
            best_f1 = f1
            best_weights = weights.copy()

    return best_weights, best_f1


def dempster_shafer_fusion(probs_list, reliability_weights=None):
    """增强版的D-S证据理论融合算法，加入可靠性权重"""
    if not probs_list:
        return None

    if reliability_weights is None:
        reliability_weights = [1.0] * len(probs_list)

    # 确保权重归一化
    reliability_weights = np.array(reliability_weights) / np.sum(reliability_weights)

    # 根据可靠性调整概率
    adjusted_probs = []
    for i, probs in enumerate(probs_list):
        # 平滑并调整概率
        weight = reliability_weights[i]
        # 应用Softmax型调整，增强可靠性高的模型的影响
        adj_probs = np.power(probs, 1 + weight)
        # 归一化
        row_sums = np.sum(adj_probs, axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1.0  # 避免除以零
        adj_probs = adj_probs / row_sums

        adjusted_probs.append(adj_probs)

    if not adjusted_probs:
        return None

    # 初始化融合结果
    fused_prob = adjusted_probs[0].copy()

    # 逐个融合后续模型的预测
    for probs in adjusted_probs[1:]:
        fused_prob = adaptive_combine_probs(fused_prob, probs)

    return fused_prob


def adaptive_combine_probs(probs1, probs2):
    """自适应D-S组合规则，针对高冲突情况进行优化"""
    combined_probs = np.zeros_like(probs1)
    n_classes = probs1.shape[1]

    for i in range(probs1.shape[0]):
        # 计算冲突度
        K = 0
        for j in range(n_classes):
            for k in range(n_classes):
                if j != k:
                    K += probs1[i, j] * probs2[i, k]

        # 冲突度评估
        if K > 0.9:  # 极高冲突
            # 使用最大概率值作为决策依据
            max1 = np.max(probs1[i])
            max2 = np.max(probs2[i])

            if max1 >= max2:
                combined_probs[i] = probs1[i]
            else:
                combined_probs[i] = probs2[i]
        elif K > 0.7:  # 高冲突
            # 加权平均，更信任证据强的一方
                weights = [np.max(probs1[i]), np.max(probs2[i])]
                weights = np.array(weights) / np.sum(weights)
                combined_probs[i] = weights[0] * probs1[i] + weights[1] * probs2[i]
        else:  # 中低冲突，使用标准D-S组合规则
            norm_factor = 1 - K

            if abs(norm_factor) < 1e-6:
                # 规范化因子太小，使用加权平均
                combined_probs[i] = 0.5 * probs1[i] + 0.5 * probs2[i]
            else:
                # 标准D-S组合
                for j in range(n_classes):
                    numerator = probs1[i, j] * probs2[i, j]
                    combined_probs[i, j] = numerator / norm_factor

        # 确保概率有效：非负且和为1
    combined_probs = np.maximum(0, combined_probs)
    row_sums = np.sum(combined_probs, axis=1, keepdims=True)
    row_sums[row_sums == 0] = 1.0  # 避免除以零
    combined_probs = combined_probs / row_sums

    return combined_probs


def init_models(model_dir='.'):
    """初始化模型，如果模型文件存在就加载，否则返回False"""
    global _models_initialized, _preprocessor, _feature_selector, _pca, _svm_model
    global _rf_model, _gb_model, _xgb_model, _mlp_model, _ada_model, _ensemble_model
    global _feature_importance, _class_thresholds, _model_weights

    # 如果已经初始化过，直接返回
    if _models_initialized:
        return True

    # 尝试加载模型
    try:
        _preprocessor = joblib.load(os.path.join(model_dir, './MODE2/preprocessor.joblib'))
        _feature_selector = joblib.load(os.path.join(model_dir, './MODE2/feature_selector.joblib'))
        _pca = joblib.load(os.path.join(model_dir, './MODE2/pca.joblib'))
        _svm_model = joblib.load(os.path.join(model_dir, './MODE2/svm_model.joblib'))
        _rf_model = joblib.load(os.path.join(model_dir, './MODE2/rf_model.joblib'))
        _gb_model = joblib.load(os.path.join(model_dir, './MODE2/gb_model.joblib'))
        _xgb_model = joblib.load(os.path.join(model_dir, './MODE2/xgb_model.joblib'))
        _mlp_model = joblib.load(os.path.join(model_dir, './MODE2/mlp_model.joblib'))
        _ada_model = joblib.load(os.path.join(model_dir, './MODE2/ada_model.joblib'))
        _ensemble_model = joblib.load(os.path.join(model_dir, './MODE2/ensemble_model.joblib'))
        _feature_importance = joblib.load(os.path.join(model_dir, './MODE2/feature_importance.joblib'))
        _class_thresholds = joblib.load(os.path.join(model_dir, './MODE2/class_thresholds.joblib'))
        _model_weights = joblib.load(os.path.join(model_dir, './MODE2/model_weights.joblib'))

        _models_initialized = True
        print("模型加载成功!")
        return True
    except Exception as e:
        print(f"无法加载模型: {str(e)}")
        print("请确保已调用train_models()函数训练模型或模型文件存在于指定目录")
        return False


def train_models(data_path, model_dir='.'):
    """训练优化的模型集合，针对各类型缺陷特征自动区分"""
    global _models_initialized, _preprocessor, _feature_selector, _pca, _svm_model
    global _rf_model, _gb_model, _xgb_model, _mlp_model, _ada_model, _ensemble_model
    global _feature_importance, _class_thresholds, _model_weights

    print(f"使用数据 {data_path} 训练模型...")
    start_time = time.time()

    try:
        # 加载数据
        data = pd.read_csv(data_path)
        print(f"成功加载数据，共{data.shape[0]}行，{data.shape[1]}列")

        # 检查并处理缺失值
        if data.isnull().sum().sum() > 0:
            print(f"发现 {data.isnull().sum().sum()} 个缺失值，正在处理...")
            # 使用前后值填充缺失值，而不是直接丢弃
            data = data.interpolate(method='linear', axis=1).fillna(method='ffill').fillna(method='bfill')
            print(f"缺失值处理完成，剩余缺失值: {data.isnull().sum().sum()}")

        # 根据格式解析数据
        columns = []
        for i in range(1, 81):
            columns.extend([f'vol{i}', f'cur{i}'])
        columns.append('label')

        # 如果列名不匹配，则尝试重命名
        if data.shape[1] == len(columns) and list(data.columns) != columns:
            print("列名不匹配，尝试重命名...")
            data.columns = columns

        # 处理标签
        if 'label' in data.columns:
            print("处理标签...")
            data['label'] = data['label'].apply(label_mapping)

            # 检查是否有未知标签
            unknown_labels = (data['label'] == -1).sum()
            if unknown_labels > 0:
                print(f"警告: 发现 {unknown_labels} 个未知标签，将被移除")
                data = data[data['label'] != -1]

            # 打印各类别数量
            label_counts = data['label'].value_counts()
            print("各类别样本数量:")
            for label, count in label_counts.items():
                print(f"  {reverse_label_mapping(label)}: {count}")
        else:
            raise ValueError("数据中没有找到'label'列")

        # 提取特征
        print("提取高级特征...")
        X = advanced_feature_extraction(data)
        y = data['label'].values

        print(f"特征提取完成，特征维度: {X.shape}")

        # 检查特征中是否有NaN值
        if np.isnan(X).any():
            print(f"警告: 特征中存在 {np.isnan(X).sum()} 个NaN值，将被替换为0")
            X = np.nan_to_num(X, nan=0.0)

        # 分割训练集和测试集
        from sklearn.model_selection import train_test_split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )

        print(f"数据集分割完成: 训练集 {X_train.shape[0]} 样本，测试集 {X_test.shape[0]} 样本")

        # 创建预处理器
        print("创建数据预处理流水线...")
        _preprocessor = Pipeline([
            ('imputer', SimpleImputer(strategy='median')),
            ('scaler', RobustScaler())
        ])

        # 应用预处理
        X_train_preprocessed = _preprocessor.fit_transform(X_train)
        X_test_preprocessed = _preprocessor.transform(X_test)

        # 特征选择
        print("执行特征选择，移除冗余和噪声特征...")
        _feature_selector = SelectFromModel(
            RandomForestClassifier(n_estimators=100, random_state=42),
            threshold='median'
        )
        X_train_selected = _feature_selector.fit_transform(X_train_preprocessed, y_train)
        X_test_selected = _feature_selector.transform(X_test_preprocessed)

        print(f"特征选择完成，保留了 {X_train_selected.shape[1]} 个特征")

        # 应用PCA降维，保留足够的信息同时减少噪声
        print("应用PCA降维...")
        _pca = PCA(n_components=0.95)  # 保留95%的方差
        X_train_pca = _pca.fit_transform(X_train_selected)
        X_test_pca = _pca.transform(X_test_selected)

        print(f"PCA降维完成，降至 {X_train_pca.shape[1]} 个主成分")

        # 训练SVM模型
        print("训练SVM模型...")
        _svm_model = svm.SVC(
            C=15, kernel='rbf', gamma='scale',
            probability=True, class_weight='balanced',
            random_state=42
        )
        _svm_model.fit(X_train_pca, y_train)

        # 训练RandomForest模型
        print("训练RandomForest模型...")
        _rf_model = RandomForestClassifier(
            n_estimators=300, max_depth=20,
            min_samples_split=4, min_samples_leaf=2,
            class_weight='balanced', bootstrap=True,
            random_state=42
        )
        _rf_model.fit(X_train_pca, y_train)

        # 训练GradientBoosting模型
        print("训练GradientBoosting模型...")
        _gb_model = GradientBoostingClassifier(
            n_estimators=250, learning_rate=0.07,
            max_depth=7, subsample=0.85,
            random_state=42
        )
        _gb_model.fit(X_train_pca, y_train)

        # 训练XGBoost模型
        print("训练XGBoost模型...")
        _xgb_model = xgb.XGBClassifier(
            n_estimators=300, learning_rate=0.05,
            max_depth=8, subsample=0.8,
            colsample_bytree=0.8, reg_alpha=0.01,
            reg_lambda=1.0, random_state=42
        )
        _xgb_model.fit(X_train_pca, y_train)

        # 训练MLP模型
        print("训练MLP模型...")
        _mlp_model = MLPClassifier(
            hidden_layer_sizes=(150, 100, 70),
            activation='relu', solver='adam',
            alpha=0.0005, batch_size=32,
            learning_rate='adaptive',
            learning_rate_init=0.001,
            max_iter=2000, early_stopping=True,
            random_state=42
        )
        _mlp_model.fit(X_train_pca, y_train)

        # 训练AdaBoost模型
        print("训练AdaBoost模型...")
        _ada_model = AdaBoostClassifier(
            n_estimators=200,
            learning_rate=0.08,
            random_state=42
        )
        _ada_model.fit(X_train_pca, y_train)

        # 获取各个模型的预测概率
        svm_probs = _svm_model.predict_proba(X_test_pca)
        rf_probs = _rf_model.predict_proba(X_test_pca)
        gb_probs = _gb_model.predict_proba(X_test_pca)
        xgb_probs = _xgb_model.predict_proba(X_test_pca)
        mlp_probs = _mlp_model.predict_proba(X_test_pca)
        ada_probs = _ada_model.predict_proba(X_test_pca)

        # 优化各模型权重
        print("优化模型权重...")
        models = [_svm_model, _rf_model, _gb_model, _xgb_model, _mlp_model, _ada_model]
        _model_weights, weight_f1 = optimize_model_weights(
            models, X_train_pca, y_train, n_splits=5
        )

        print(f"优化权重完成，最佳F1: {weight_f1:.4f}")
        print(f"模型权重: {_model_weights}")

        # 创建基于优化权重的投票集成
        _ensemble_model = VotingClassifier(
            estimators=[
                ('svm', _svm_model),
                ('rf', _rf_model),
                ('gb', _gb_model),
                ('xgb', _xgb_model),
                ('mlp', _mlp_model),
                ('ada', _ada_model)
            ],
            voting='soft',
            weights=_model_weights
        )
        _ensemble_model.fit(X_train_pca, y_train)

        # 使用集成模型预测
        ensemble_probs = _ensemble_model.predict_proba(X_test_pca)

        # 优化类别阈值
        print("优化各类别预测阈值...")
        _class_thresholds, threshold_f1 = optimize_class_thresholds(
            y_test, ensemble_probs, n_classes=5
        )

        print(f"优化阈值完成，最佳F1: {threshold_f1:.4f}")
        print(f"类别阈值: {_class_thresholds}")

        # 应用优化后的阈值进行最终预测
        ensemble_preds = np.zeros(len(y_test), dtype=int)
        for i in range(len(y_test)):
            probs = ensemble_probs[i]
            adjusted_probs = probs * (1 / np.array(_class_thresholds))
            ensemble_preds[i] = np.argmax(adjusted_probs)

        # 获取特征重要性
        # 使用随机森林的特征重要性
        if hasattr(_feature_selector, 'get_support'):
            selected_indices = _feature_selector.get_support()
            importances = np.zeros(X.shape[1])

            # 获取随机森林的特征重要性
            if hasattr(_rf_model, 'feature_importances_'):
                rf_importances = _rf_model.feature_importances_
                # 将特征重要性映射回原始特征空间
                j = 0
                for i in range(len(selected_indices)):
                    if selected_indices[i]:
                        if j < len(rf_importances):  # 确保不越界
                            importances[i] = rf_importances[j]
                            j += 1

                _feature_importance = importances
            else:
                _feature_importance = None
        else:
            _feature_importance = None

        # 评估模型
        from sklearn.metrics import classification_report, confusion_matrix

        # 评估各个模型性能
        print("\n各模型性能评估:")
        class_names = [reverse_label_mapping(i) for i in range(5)]

        models_to_evaluate = {
            'SVM': _svm_model,
            'RandomForest': _rf_model,
            'GradientBoosting': _gb_model,
            'XGBoost': _xgb_model,
            'MLP': _mlp_model,
            'AdaBoost': _ada_model,
            '加权集成(优化阈值)': None  # 使用ensemble_preds
        }

        for name, model in models_to_evaluate.items():
            if model is not None:
                y_pred = model.predict(X_test_pca)
                accuracy = accuracy_score(y_test, y_pred)
                f1 = f1_score(y_test, y_pred, average='weighted')
                print(f"\n{name} - 准确率: {accuracy:.4f}, F1分数: {f1:.4f}")
                print(classification_report(y_test, y_pred, target_names=class_names, zero_division=0))
            else:
                # 使用预先计算的集成预测
                accuracy = accuracy_score(y_test, ensemble_preds)
                f1 = f1_score(y_test, ensemble_preds, average='weighted')
                print(f"\n{name} - 准确率: {accuracy:.4f}, F1分数: {f1:.4f}")
                print(classification_report(y_test, ensemble_preds, target_names=class_names, zero_division=0))
                print("\n混淆矩阵:")
                print(confusion_matrix(y_test, ensemble_preds))

        # 最优模型的混淆矩阵
        print("\n最终集成模型的混淆矩阵:")
        print(confusion_matrix(y_test, ensemble_preds))

        # 保存模型
        print("\n保存所有模型...")
        os.makedirs(model_dir, exist_ok=True)
        joblib.dump(_preprocessor, os.path.join(model_dir, 'preprocessor.joblib'))
        joblib.dump(_feature_selector, os.path.join(model_dir, 'feature_selector.joblib'))
        joblib.dump(_pca, os.path.join(model_dir, 'pca.joblib'))
        joblib.dump(_svm_model, os.path.join(model_dir, 'svm_model.joblib'))
        joblib.dump(_rf_model, os.path.join(model_dir, 'rf_model.joblib'))
        joblib.dump(_gb_model, os.path.join(model_dir, 'gb_model.joblib'))
        joblib.dump(_xgb_model, os.path.join(model_dir, 'xgb_model.joblib'))
        joblib.dump(_mlp_model, os.path.join(model_dir, 'mlp_model.joblib'))
        joblib.dump(_ada_model, os.path.join(model_dir, 'ada_model.joblib'))
        joblib.dump(_ensemble_model, os.path.join(model_dir, 'ensemble_model.joblib'))
        joblib.dump(_feature_importance, os.path.join(model_dir, 'feature_importance.joblib'))
        joblib.dump(_class_thresholds, os.path.join(model_dir, 'class_thresholds.joblib'))
        joblib.dump(_model_weights, os.path.join(model_dir, 'model_weights.joblib'))

        _models_initialized = True

        end_time = time.time()
        print(f"\n模型训练完成! 总耗时: {end_time - start_time:.2f} 秒")
        return True

    except Exception as e:
        print(f"模型训练过程中出错: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def predict(data, mode='ensemble', model_dir='.'):
    """
    增强版预测PV面板状态，保持输入输出接口不变

    参数:
    data: 可以是以下格式之一:
        - 逗号分隔的字符串，格式为"vol1,cur1,vol2,cur2,...,vol80,cur80"
        - 包含160个值的列表/数组，每对表示电压和电流
        - 带有vol和cur列的Pandas DataFrame
    mode: 预测模式
        - 'ensemble': 使用优化阈值的加权集成模型 (默认)
        - 'voting': 使用直接投票模型
        - 'ds': 使用D-S证据理论融合
        - 'expert': 使用基于专家规则的融合策略
    model_dir: 模型文件所在目录

    返回:
    (pred_class, pred_probs): (预测类别, 各类别概率字典)
    """
    # 标签映射
    labels = ['normal', 'short', 'open', 'shelter', 'old']

    # 确保模型已初始化
    if not _models_initialized:
        init_success = init_models(model_dir)
        if not init_success:
            return None, None

    try:
        # 根据输入类型处理数据
        if isinstance(data, str):
            # 处理逗号分隔的字符串
            values = [float(x) for x in data.split(',')]
            if len(values) != 160:
                raise ValueError(f"输入数据应包含160个值，但实际包含{len(values)}个")

            # 构建数据帧
            data_dict = {}
            for i in range(80):
                data_dict[f'vol{i + 1}'] = [values[2 * i]]
                data_dict[f'cur{i + 1}'] = [values[2 * i + 1]]

            sample_df = pd.DataFrame(data_dict)

        elif isinstance(data, (list, np.ndarray)):
            # 处理列表或数组
            values = data
            if len(values) != 160:
                raise ValueError(f"输入数据应包含160个值，但实际包含{len(values)}个")

            # 构建数据帧
            data_dict = {}
            for i in range(80):
                data_dict[f'vol{i + 1}'] = [values[2 * i]]
                data_dict[f'cur{i + 1}'] = [values[2 * i + 1]]

            sample_df = pd.DataFrame(data_dict)

        elif isinstance(data, pd.DataFrame):
            # 直接使用DataFrame
            sample_df = data.copy()

            # 检查列数
            if sample_df.shape[1] < 160:
                raise ValueError(f"输入DataFrame应至少包含160列(80对电压和电流)，但实际仅包含{sample_df.shape[1]}列")
        else:
            raise ValueError("不支持的数据类型，请使用字符串、列表或DataFrame")

        # 添加一个虚拟标签用于特征提取
        sample_df['label'] = 0

        # 检查并处理数据中的缺失值
        if sample_df.isnull().sum().sum() > 0:
            sample_df = sample_df.interpolate(method='linear', axis=1).fillna(method='ffill').fillna(method='bfill')

        # 提取特征
        X = advanced_feature_extraction(sample_df)

        # 检查特征中是否有NaN值
        if np.isnan(X).any():
            X = np.nan_to_num(X, nan=0.0)

        # 应用预处理和降维
        X_preprocessed = _preprocessor.transform(X)
        X_selected = _feature_selector.transform(X_preprocessed)
        X_pca = _pca.transform(X_selected)

        # 获取各模型预测概率
        svm_probs = _svm_model.predict_proba(X_pca)
        rf_probs = _rf_model.predict_proba(X_pca)
        gb_probs = _gb_model.predict_proba(X_pca)
        xgb_probs = _xgb_model.predict_proba(X_pca)
        mlp_probs = _mlp_model.predict_proba(X_pca)
        ada_probs = _ada_model.predict_proba(X_pca)

        if mode == 'ensemble':
            # 使用加权集成模型预测
            ensemble_probs = _ensemble_model.predict_proba(X_pca)[0]

            # 应用类别阈值优化
            adjusted_probs = ensemble_probs * (1 / np.array(_class_thresholds))
            pred_class = np.argmax(adjusted_probs)
            pred_probs = ensemble_probs

        elif mode == 'voting':
            # 使用投票集成模型预测，不应用阈值优化
            pred_class = _ensemble_model.predict(X_pca)[0]
            pred_probs = _ensemble_model.predict_proba(X_pca)[0]

        elif mode == 'ds':
            # 使用D-S证据理论融合
            all_probs = [svm_probs, rf_probs, gb_probs, xgb_probs, mlp_probs, ada_probs]
            ds_probs = dempster_shafer_fusion(all_probs, _model_weights)

            if ds_probs is None:
                # 如果融合失败，回退到集成模型
                pred_class = _ensemble_model.predict(X_pca)[0]
                pred_probs = _ensemble_model.predict_proba(X_pca)[0]
            else:
                # 应用类别阈值优化
                adjusted_probs = ds_probs[0] * (1 / np.array(_class_thresholds))
                pred_class = np.argmax(adjusted_probs)
                pred_probs = ds_probs[0]

        elif mode == 'expert':
            # 使用专家规则融合策略，根据各类型特殊识别规则进行调整
            # 首先获取基础预测
            base_probs = _ensemble_model.predict_proba(X_pca)[0]

            # 提取该样本的原始特征
            voltages = np.array([sample_df.iloc[0, 2 * i] for i in range(80)])
            currents = np.array([sample_df.iloc[0, 2 * i + 1] for i in range(80)])

            # 平滑处理
            try:
                smooth_voltages = savgol_filter(voltages, 7, 3)
                smooth_currents = savgol_filter(currents, 7, 3)
            except:
                smooth_voltages = voltages
                smooth_currents = currents

            # 计算关键特征
            # 短路特征 - 电压接近零
            near_zero_voltage = np.sum(smooth_voltages < np.max(smooth_voltages) * 0.1) / len(smooth_voltages)

            # 开路特征 - 电流接近零
            near_zero_current = np.sum(smooth_currents < np.max(smooth_currents) * 0.1) / len(smooth_currents)

            # 遮挡特征 - 电流曲线中的突然下降
            i_slopes = np.diff(smooth_currents)
            drops = i_slopes[i_slopes < -np.std(smooth_currents) * 0.5]
            current_drops = len(drops)

            # 老化特征 - 填充因子计算
            max_power = np.max(smooth_voltages * smooth_currents)
            v_oc = np.max(smooth_voltages)
            i_sc = np.max(smooth_currents)
            ff = max_power / (v_oc * i_sc) if v_oc * i_sc > 0 else 0

            # 应用专家规则调整概率
            adjusted_probs = base_probs.copy()

            # 短路调整：如果电压大部分接近零，增强短路概率
            if near_zero_voltage > 0.4:
                adjusted_probs[1] *= 1.5  # 增强short类概率

            # 开路调整：如果电流大部分接近零，增强开路概率
            if near_zero_current > 0.4:
                adjusted_probs[2] *= 1.5  # 增强open类概率

            # 遮挡调整：如果电流有多次显著下降，增强遮挡概率
            if current_drops >= 3:
                adjusted_probs[3] *= 1.5  # 增强shelter类概率

            # 老化调整：如果填充因子较低，增强老化概率
            if ff < 0.5:
                adjusted_probs[4] *= 1.5  # 增强old类概率

            # 归一化调整后的概率
            adjusted_probs = adjusted_probs / np.sum(adjusted_probs)

            # 应用类别阈值优化
            final_probs = adjusted_probs * (1 / np.array(_class_thresholds))
            pred_class = np.argmax(final_probs)
            pred_probs = adjusted_probs

        else:
            raise ValueError("模式参数必须是'ensemble'、'voting'、'ds'或'expert'")

        # 返回预测结果，确保是标量而不是数组
        if hasattr(pred_class, '__len__'):
            pred_class = pred_class[0]

        return int(pred_class), {label: float(prob) for label, prob in zip(labels, pred_probs)}

    except Exception as e:
        print(f"预测过程中出错: {str(e)}")
        import traceback
        traceback.print_exc()
        return None, None


# 集成模型评估函数
def evaluate_models(data_path, test_size=0.2, random_state=42):
    """
    评估各模型在测试数据上的性能，对比不同融合策略效果

    参数:
    data_path: 数据文件路径
    test_size: 测试集比例
    random_state: 随机种子

    返回:
    dict: 包含各模型性能指标的字典
    """
    try:
        # 确保模型已初始化
        if not _models_initialized:
            init_success = init_models()
            if not init_success:
                print("模型未初始化，无法进行评估")
                return None

        # 加载数据
        data = pd.read_csv(data_path)

        # 处理缺失值
        if data.isnull().sum().sum() > 0:
            data = data.interpolate(method='linear', axis=1).fillna(method='ffill').fillna(method='bfill')

        # 处理标签
        if 'label' in data.columns:
            data['label'] = data['label'].apply(label_mapping)
            data = data[data['label'] != -1]  # 移除未知标签
        else:
            raise ValueError("数据中没有找到'label'列")

        # 提取特征
        X = advanced_feature_extraction(data)
        y = data['label'].values

        # 确保没有NaN值
        X = np.nan_to_num(X, nan=0.0)

        # 分割训练集和测试集
        from sklearn.model_selection import train_test_split
        _, X_test, _, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=y)

        # 应用预处理和降维
        X_test_preprocessed = _preprocessor.transform(X_test)
        X_test_selected = _feature_selector.transform(X_test_preprocessed)
        X_test_pca = _pca.transform(X_test_selected)

        # 评估各个模型
        results = {}
        models = {
            'SVM': _svm_model,
            'RandomForest': _rf_model,
            'GradientBoosting': _gb_model,
            'XGBoost': _xgb_model,
            'MLP': _mlp_model,
            'AdaBoost': _ada_model,
            'Ensemble': _ensemble_model
        }

        from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, classification_report

        # 评估每个基础模型
        for name, model in models.items():
            y_pred = model.predict(X_test_pca)
            accuracy = accuracy_score(y_test, y_pred)
            f1 = f1_score(y_test, y_pred, average='weighted')
            precision = precision_score(y_test, y_pred, average='weighted', zero_division=0)
            recall = recall_score(y_test, y_pred, average='weighted', zero_division=0)

            results[name] = {
                'accuracy': accuracy,
                'f1_score': f1,
                'precision': precision,
                'recall': recall
            }

            print(f"\n{name} 模型评估结果:")
            print(f"准确率: {accuracy:.4f}")
            print(f"F1分数: {f1:.4f}")
            print(f"精确率: {precision:.4f}")
            print(f"召回率: {recall:.4f}")

        # 评估优化阈值的集成模型
        ensemble_probs = _ensemble_model.predict_proba(X_test_pca)
        adjusted_preds = np.zeros(len(y_test), dtype=int)

        for i in range(len(y_test)):
            probs = ensemble_probs[i]
            adjusted_probs = probs * (1 / np.array(_class_thresholds))
            adjusted_preds[i] = np.argmax(adjusted_probs)

        accuracy = accuracy_score(y_test, adjusted_preds)
        f1 = f1_score(y_test, adjusted_preds, average='weighted')
        precision = precision_score(y_test, adjusted_preds, average='weighted', zero_division=0)
        recall = recall_score(y_test, adjusted_preds, average='weighted', zero_division=0)

        results['Ensemble(优化阈值)'] = {
            'accuracy': accuracy,
            'f1_score': f1,
            'precision': precision,
            'recall': recall
        }

        print(f"\nEnsemble(优化阈值) 模型评估结果:")
        print(f"准确率: {accuracy:.4f}")
        print(f"F1分数: {f1:.4f}")
        print(f"精确率: {precision:.4f}")
        print(f"召回率: {recall:.4f}")

        # 评估DS融合方法
        # 获取各模型预测概率
        all_probs = [
            _svm_model.predict_proba(X_test_pca),
            _rf_model.predict_proba(X_test_pca),
            _gb_model.predict_proba(X_test_pca),
            _xgb_model.predict_proba(X_test_pca),
            _mlp_model.predict_proba(X_test_pca),
            _ada_model.predict_proba(X_test_pca)
        ]

        ds_probs = dempster_shafer_fusion(all_probs, _model_weights)
        ds_preds = np.argmax(ds_probs, axis=1)

        accuracy = accuracy_score(y_test, ds_preds)
        f1 = f1_score(y_test, ds_preds, average='weighted')
        precision = precision_score(y_test, ds_preds, average='weighted', zero_division=0)
        recall = recall_score(y_test, ds_preds, average='weighted', zero_division=0)

        results['DS融合'] = {
            'accuracy': accuracy,
            'f1_score': f1,
            'precision': precision,
            'recall': recall
        }

        print(f"\nDS融合模型评估结果:")
        print(f"准确率: {accuracy:.4f}")
        print(f"F1分数: {f1:.4f}")
        print(f"精确率: {precision:.4f}")
        print(f"召回率: {recall:.4f}")

        # 按类别评估
        class_names = [reverse_label_mapping(i) for i in range(5)]
        print("\n各类别详细性能报告(优化阈值集成模型):")
        print(classification_report(y_test, adjusted_preds, target_names=class_names, zero_division=0))

        # 返回结果
        return results

    except Exception as e:
        print(f"评估过程中出错: {str(e)}")
        import traceback
        traceback.print_exc()
        return None


# 特征重要性分析
def analyze_feature_importance(top_n=20, plot=False):
    """
    分析特征重要性，识别对分类最有影响的特征

    参数:
    top_n: 显示前n个重要特征
    plot: 是否绘制特征重要性图表

    返回:
    dict: 特征重要性字典
    """
    if not _models_initialized or _feature_importance is None:
        print("模型未初始化或特征重要性未计算")
        return None

    # 特征描述映射
    feature_descriptions = {
        # 基本特征
        0: "最大功率(max_power)",
        1: "最大功率点电压(v_mpp)",
        2: "最大功率点电流(i_mpp)",
        3: "开路电压(v_oc)",
        4: "短路电流(i_sc)",
        5: "填充因子(ff)",
        6: "起始段IV比率(iv_ratio_start)",
        7: "中段IV比率(iv_ratio_middle)",
        8: "末段IV比率(iv_ratio_end)",
        9: "起始-中段IV比率差(iv_ratio_diff1)",
        10: "中段-末段IV比率差(iv_ratio_diff2)",
        11: "电流斜率均值(i_slope_mean)",
        12: "电流斜率标准差(i_slope_std)",
        13: "电流斜率最大值(i_slope_max)",
        14: "电流斜率最小值(i_slope_min)",
        15: "电压斜率均值(v_slope_mean)",
        16: "电压斜率标准差(v_slope_std)",
        17: "电压斜率最大值(v_slope_max)",
        18: "电压斜率最小值(v_slope_min)",
    }

    # 对特征重要性进行排序
    indices = np.argsort(_feature_importance)[::-1]

    # 显示前top_n个特征的重要性
    print(f"前{top_n}个重要特征:")
    importance_dict = {}

    for i in range(min(top_n, len(indices))):
        idx = indices[i]
        importance = _feature_importance[idx]
        description = feature_descriptions.get(idx, f"特征_{idx}")
        print(f"{i + 1}. {description}: {importance:.4f}")
        importance_dict[description] = float(importance)


    return importance_dict


# 类别预测解释函数
def explain_prediction(data, mode='ensemble'):
    """
    解释PV面板类别预测的原因

    参数:
    data: 样本数据
    mode: 预测模式

    返回:
    dict: 预测解释字典
    """
    # 首先进行预测
    pred_class, pred_probs = predict(data, mode=mode)

    if pred_class is None:
        return None

    # 类别特征特征描述
    class_features = {
        0: "normal",  # 正常
        1: "short",  # 短路
        2: "open",  # 开路
        3: "shelter",  # 遮挡
        4: "old"  # 老化
    }

    # 特征阈值和描述
    feature_thresholds = {
        "short": {
            "near_zero_voltage": 0.3,
            "high_current_std": 0.2
        },
        "open": {
            "near_zero_current": 0.3,
            "voltage_plateaus": 0.4
        },
        "shelter": {
            "current_drops": 2,
            "local_minima": 3
        },
        "old": {
            "fill_factor": 0.6,
            "power_curve_smoothness": 0.7
        }
    }

    # 处理样本数据
    sample_df = None

    if isinstance(data, str):
        values = [float(x) for x in data.split(',')]
        data_dict = {}
        for i in range(80):
            data_dict[f'vol{i + 1}'] = [values[2 * i]]
            data_dict[f'cur{i + 1}'] = [values[2 * i + 1]]
        sample_df = pd.DataFrame(data_dict)
    elif isinstance(data, (list, np.ndarray)):
        values = data
        data_dict = {}
        for i in range(80):
            data_dict[f'vol{i + 1}'] = [values[2 * i]]
            data_dict[f'cur{i + 1}'] = [values[2 * i + 1]]
        sample_df = pd.DataFrame(data_dict)
    elif isinstance(data, pd.DataFrame):
        sample_df = data.copy()

    # 提取电压和电流数据
    voltages = np.array([sample_df.iloc[0, 2 * i] for i in range(80)])
    currents = np.array([sample_df.iloc[0, 2 * i + 1] for i in range(80)])

    # 计算关键特征
    # 短路特征
    near_zero_voltage = np.sum(voltages < np.max(voltages) * 0.1) / len(voltages)
    current_std_ratio = np.std(currents) / np.mean(currents) if np.mean(currents) > 0 else 0

    # 开路特征
    near_zero_current = np.sum(currents < np.max(currents) * 0.1) / len(currents)
    v_plateaus = np.diff(voltages)
    voltage_plateaus = np.sum(np.abs(v_plateaus) < np.std(voltages) * 0.1) / len(v_plateaus)

    # 遮挡特征
    i_slopes = np.diff(currents)
    drops = i_slopes[i_slopes < -np.std(currents) * 0.5]
    current_drops = len(drops)
    min_indices = (i_slopes[:-1] < 0) & (i_slopes[1:] > 0)
    local_minima = np.sum(min_indices)

    # 老化特征
    power = voltages * currents
    max_power = np.max(power)
    v_oc = np.max(voltages)
    i_sc = np.max(currents)
    fill_factor = max_power / (v_oc * i_sc) if v_oc * i_sc > 0 else 0

    # 功率曲线平滑度
    x = np.arange(len(power))
    try:
        poly_coef = np.polyfit(x, power, 4)
        poly_fit = np.polyval(poly_coef, x)
        power_curve_smoothness = 1 - (np.mean((power - poly_fit) ** 2) / np.var(power)) if np.var(power) > 0 else 0
    except:
        power_curve_smoothness = 0

    # 生成解释
    explanation = {
        "prediction": class_features[pred_class],
        "confidence": float(max(pred_probs.values())),
        "class_probabilities": pred_probs,
        "key_features": {
            "short_circuit_indicators": {
                "near_zero_voltage": float(near_zero_voltage),
                "current_std_ratio": float(current_std_ratio),
                "is_significant": near_zero_voltage > feature_thresholds["short"]["near_zero_voltage"]
            },
            "open_circuit_indicators": {
                "near_zero_current": float(near_zero_current),
                "voltage_plateaus": float(voltage_plateaus),
                "is_significant": near_zero_current > feature_thresholds["open"]["near_zero_current"]
            },
            "shelter_indicators": {
                "current_drops": int(current_drops),
                "local_minima": int(local_minima),
                "is_significant": current_drops > feature_thresholds["shelter"]["current_drops"]
            },
            "aging_indicators": {
                "fill_factor": float(fill_factor),
                "power_curve_smoothness": float(power_curve_smoothness),
                "is_significant": fill_factor < feature_thresholds["old"]["fill_factor"]
            }
        }
    }

    # 添加文本说明
    text_explanation = f"预测结果为: {class_features[pred_class]}，置信度: {max(pred_probs.values()):.2f}\n\n"

    if pred_class == 0:  # normal
        text_explanation += "正常状态特征:\n"
        text_explanation += f"- 填充因子较高: {fill_factor:.2f}\n"
        text_explanation += f"- 无电流急剧下降\n"
        text_explanation += f"- 电压和电流曲线平滑\n"
    elif pred_class == 1:  # short
        text_explanation += "短路状态特征:\n"
        text_explanation += f"- 电压近零区域占比: {near_zero_voltage:.2f}\n"
        text_explanation += f"- 电流变化大: {current_std_ratio:.2f}\n"
    elif pred_class == 2:  # open
        text_explanation += "开路状态特征:\n"
        text_explanation += f"- 电流近零区域占比: {near_zero_current:.2f}\n"
        text_explanation += f"- 电压平台比例: {voltage_plateaus:.2f}\n"
    elif pred_class == 3:  # shelter
        text_explanation += "遮挡状态特征:\n"
        text_explanation += f"- 电流曲线下降次数: {current_drops}\n"
        text_explanation += f"- 电流局部最小值数量: {local_minima}\n"
    elif pred_class == 4:  # old
        text_explanation += "老化状态特征:\n"
        text_explanation += f"- 填充因子降低: {fill_factor:.2f}\n"
        text_explanation += f"- 功率曲线平滑度: {power_curve_smoothness:.2f}\n"

    explanation["text_explanation"] = text_explanation

    return explanation


# 批量预测函数
def batch_predict(data_path, output_path=None, mode='ensemble'):
    """
    对CSV文件中的多个样本进行批量预测

    参数:
    data_path: 输入CSV文件路径
    output_path: 输出结果CSV文件路径，如果为None则不保存结果
    mode: 预测模式

    返回:
    DataFrame: 预测结果
    """
    try:
        # 加载数据
        data = pd.read_csv(data_path)
        print(f"已加载数据，共{data.shape[0]}行")

        # 处理缺失值
        if data.isnull().sum().sum() > 0:
            data = data.interpolate(method='linear', axis=1).fillna(method='ffill').fillna(method='bfill')

        # 初始化结果列表
        results = []

        # 逐行预测
        for i in range(data.shape[0]):
            row = data.iloc[i:i + 1, :]

            # 如果数据包含标签列，移除它再预测
            if 'label' in row.columns:
                true_label = row['label'].values[0]
                row = row.drop(columns=['label'])
            else:
                true_label = None

            # 预测
            pred_class, pred_probs = predict(row, mode=mode)

            if pred_class is not None:
                result = {
                    'sample_id': i,
                    'predicted_class': pred_class,
                    'predicted_label': reverse_label_mapping(pred_class),
                    'confidence': max(pred_probs.values())
                }

                # 添加各类别概率
                for label, prob in pred_probs.items():
                    result[f'{label}_probability'] = prob

                # 如果有真实标签，添加到结果中
                if true_label is not None:
                    result['true_label'] = true_label
                    result['true_label_text'] = reverse_label_mapping(label_mapping(true_label))
                    result['correct'] = (reverse_label_mapping(pred_class) == true_label)

                results.append(result)
            else:
                print(f"样本 {i} 预测失败，跳过")

        # 创建结果DataFrame
        results_df = pd.DataFrame(results)

        # 如果指定了输出路径，保存结果
        if output_path:
            results_df.to_csv(output_path, index=False)
            print(f"预测结果已保存至: {output_path}")

        # 计算精度（如果有真实标签）
        if 'correct' in results_df.columns:
            accuracy = results_df['correct'].mean()
            print(f"预测准确率: {accuracy:.4f}")

            # 计算各类别准确率
            if 'true_label_text' in results_df.columns:
                print("各类别准确率:")
                for label in ['normal', 'short', 'open', 'shelter', 'old']:
                    class_df = results_df[results_df['true_label_text'] == label]
                    if len(class_df) > 0:
                        class_acc = class_df['correct'].mean()
                        print(f"  {label}: {class_acc:.4f} ({len(class_df)} 样本)")

        return results_df

    except Exception as e:
        print(f"批量预测过程中出错: {str(e)}")
        import traceback
        traceback.print_exc()
        return None


# 样本可视化函数
def visualize_sample(data, save_path=None):
    """
    可视化样本的IV曲线和功率曲线

    参数:
    data: 样本数据
    save_path: 保存图像的路径，如果为None则显示图像

    返回:
    None
    """
    try:
        import matplotlib.pyplot as plt

        # 处理样本数据
        sample_df = None

        if isinstance(data, str):
            values = [float(x) for x in data.split(',')]
            data_dict = {}
            for i in range(80):
                data_dict[f'vol{i + 1}'] = [values[2 * i]]
                data_dict[f'cur{i + 1}'] = [values[2 * i + 1]]
            sample_df = pd.DataFrame(data_dict)
        elif isinstance(data, (list, np.ndarray)):
            values = data
            data_dict = {}
            for i in range(80):
                data_dict[f'vol{i + 1}'] = [values[2 * i]]
                data_dict[f'cur{i + 1}'] = [values[2 * i + 1]]
            sample_df = pd.DataFrame(data_dict)
        elif isinstance(data, pd.DataFrame):
            sample_df = data.copy()

        # 提取电压和电流数据
        voltages = np.array([sample_df.iloc[0, 2 * i] for i in range(80)])
        currents = np.array([sample_df.iloc[0, 2 * i + 1] for i in range(80)])

        # 计算功率
        power = voltages * currents

        # 获取预测结果
        pred_class, pred_probs = predict(data)
        pred_label = reverse_label_mapping(pred_class)

        # 创建图形
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

        # IV曲线
        ax1.plot(voltages, currents, 'b-', linewidth=2)
        ax1.set_xlabel('电压 (V)')
        ax1.set_ylabel('电流 (A)')
        ax1.set_title('IV曲线')
        ax1.grid(True)

        # 功率曲线
        ax2.plot(voltages, power, 'r-', linewidth=2)
        ax2.set_xlabel('电压 (V)')
        ax2.set_ylabel('功率 (W)')
        ax2.set_title('功率曲线')
        ax2.grid(True)

        # 添加预测结果信息
        plt.suptitle(f'预测类别: {pred_label} (置信度: {max(pred_probs.values()):.2f})', fontsize=14)

        # 添加关键点标记
        # 最大功率点
        max_power_idx = np.argmax(power)
        ax1.plot(voltages[max_power_idx], currents[max_power_idx], 'ro', markersize=8, label='MPP')
        ax2.plot(voltages[max_power_idx], power[max_power_idx], 'ro', markersize=8, label='最大功率点')

        # 短路电流点
        isc_idx = np.argmax(currents)
        ax1.plot(voltages[isc_idx], currents[isc_idx], 'go', markersize=8, label='Isc')

        # 开路电压点
        voc_idx = np.argmax(voltages)
        ax1.plot(voltages[voc_idx], currents[voc_idx], 'mo', markersize=8, label='Voc')

        # 添加图例
        ax1.legend()
        ax2.legend()

        plt.tight_layout()

        # 保存或显示图像
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"图像已保存至: {save_path}")
        else:
            plt.show()

    except Exception as e:
        print(f"可视化过程中出错: {str(e)}")
        import traceback
        traceback.print_exc()


# 主函数，简单使用示例
if __name__ == "__main__":
    # 初始化模型
    if not init_models():
        print("模型未初始化，尝试训练...")
        train_success = train_models('data1.csv')

        if train_success:
            print("训练成功，进行模型评估...")
            evaluate_models('data1.csv')

            # 分析特征重要性
            analyze_feature_importance(top_n=20, plot=True)
        else:
            print("训练失败，请检查数据和错误信息")