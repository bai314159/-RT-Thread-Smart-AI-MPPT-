import re
import numpy as np
from scipy.interpolate import interp1d
from sklearn.linear_model import LinearRegression
from MODE.SVM_80_base import predict
#from MODE.SVM_80_base import predict

class DataProcessor:
    def smart_predict(self, data):
        """
        智能预测函数 - 自动选择最佳策略
        【修复】缩进问题，正确放置在类内部
        """
        try:
            if USE_OPTIMIZED_MODEL:
                # 使用优化模型进行预测
                pred_class, pred_probs = predict(data, mode='ensemble')
                
                if pred_class is None:
                    return {'error': '优化模型预测失败，请检查数据'}
                
                # 计算置信度
                confidence = max(pred_probs.values())
                
                # 获取标签
                labels = {0: 'normal', 1: 'short', 2: 'open', 3: 'shelter', 4: 'old'}
                predicted_label = labels[pred_class]
                
                # 智能决策建议
                if confidence >= 0.90:
                    recommendation = f"✅ 高置信度({confidence:.3f})，直接采用结果: {predicted_label}"
                    action = "立即执行相应维护操作" if pred_class != 0 else "继续正常监控"
                elif confidence >= 0.80:
                    recommendation = f"🟡 中等置信度({confidence:.3f})，建议二次确认: {predicted_label}"
                    action = "结合人工判断后执行"
                else:
                    recommendation = f"🔴 低置信度({confidence:.3f})，建议重新检测"
                    action = "重新采集数据或人工复核"
                
                # 学习状态评估
                if confidence >= 0.85:
                    sorted_probs = sorted(pred_probs.values(), reverse=True)
                    if len(sorted_probs) > 1 and sorted_probs[1] <= 0.3:
                        learning_status = "✅ 高质量样本，将被自动学习"
                    else:
                        learning_status = "❌ 预测不够确定，不会触发学习"
                else:
                    learning_status = "❌ 置信度过低，不会触发学习"
                
                return {
                    'predicted_class': pred_class,
                    'predicted_label': predicted_label,
                    'confidence': confidence,
                    'probabilities': pred_probs,
                    'recommendation': recommendation,
                    'action': action,
                    'learning_status': learning_status
                }
                
            else:
                # 使用原始模型进行预测
                pred_class, pred_probs = predict(data, "ensemble")
                
                if pred_class is None:
                    return {'error': '原始模型预测失败，请检查数据'}
                
                confidence = max(pred_probs.values())
                labels = {0: 'normal', 1: 'short', 2: 'open', 3: 'shelter', 4: 'old'}
                predicted_label = labels[pred_class]
                
                return {
                    'predicted_class': pred_class,
                    'predicted_label': predicted_label,
                    'confidence': confidence,
                    'probabilities': pred_probs,
                    'recommendation': f"原始模型预测: {predicted_label}",
                    'action': "根据预测结果采取相应措施",
                    'learning_status': "原始模型不支持在线学习"
                }
                
        except Exception as e:
            print(f"❌ 预测过程中出错: {e}")
            return {'error': f'预测异常: {str(e)}'}


    def process_data(self, raw_data ,pv_select):
        cleaned_data = self.clean_data(raw_data)
        #print(cleaned_data)

        if cleaned_data is None:
            print("数据清理失败")
            return None

        try:
            values = [float(x) for x in cleaned_data.split(',')]
            if len(values) % 2 != 0:
                print(f"数据长度不匹配: {values}")
                return None

            iv_curve = self.adjust_iv_curve(values)

            print(f"IV曲线数据: {iv_curve}")
            labels = ['normal', 'short', 'open', 'shelter', 'old']
            iv_curve_str = ",".join(map(str, iv_curve))
            classification ,pred_probs = predict(iv_curve_str,"ds")
            #classification ,pred_probs = predict(iv_curve_str)
            print(f"预测结果: {labels[classification]}")
            print(f"各类型概率：{pred_probs}")

            voltages = iv_curve[0::2]
            currents = iv_curve[1::2]
            powers = [voltages[i] * abs(currents[i]) for i in range(len(voltages))]

            pow_max = max(powers)
            max_index = powers.index(pow_max)  # 找到最大功率的索引
            vol_max = voltages[max_index]
            cur_max = currents[max_index]

            #数据库
            #write_data_to_tables(powers, currents, voltages, self.iv_select)

            return {
                'classification': int(classification),
                'vol_max' : round(vol_max, 4),  #电压
                'cur_max' : round(cur_max, 4),  #
                'pow_max' : round(pow_max, 4),   #
                'voltages': voltages,
                'currents': currents,
                'powers'  : powers
            }
        except ValueError as e:
            print(f"数据格式错误: {e}")
            return None
        except Exception as e:
            print(f"数据处理出错: {e}")
            return None

    import re

    def clean_data(self, data):
        try:
            # 替换换行符、回车符和空格
            data = data.replace('\n', '').replace('\r', '').replace(' ', '')

            # 替换双逗号和分号
            data = data.replace(',,', ',').replace(';', ',')

            # 创建新的清理方法，保留负号
            fixed_data = []
            num_buffer = ''
            sign = ''

            for char in data:
                if char == '-':
                    # 捕获负号
                    sign = char
                elif char.isdigit() or char == '.':
                    # 构建数字缓冲区，包括负号（如果存在）
                    num_buffer += char
                elif char == ',':
                    # 遇到逗号时，将完整数字添加到 fixed_data
                    if num_buffer:
                        # 如果存在负号，则添加到数字前
                        full_number = sign + num_buffer
                        fixed_data.append(full_number)
                        # 重置负号和数字缓冲区
                        sign = ''
                        num_buffer = ''
                    # 添加逗号
                    fixed_data.append(',')

            # 处理最后一个数字（如果存在）
            if num_buffer:
                full_number = sign + num_buffer
                fixed_data.append(full_number)

            # 将 fixed_data 连接成字符串
            cleaned_data = ''.join(fixed_data)

            # 如果以逗号结尾，则删除最后一个逗号
            if cleaned_data.endswith(','):
                cleaned_data = cleaned_data[:-1]

            # 处理特殊的小数点和逗号情况
            cleaned_data = re.sub(r'(\d+\.\d{2})(\d)', r'\1,\2', cleaned_data)
            cleaned_data = re.sub(r'(\d+)\.(\d+)(?=\d+\.)', r'\1.\2,', cleaned_data)

            return cleaned_data if cleaned_data else None
        except Exception as e:
            print(f"数据清理时出错: {e}")
            return None

    def adjust_iv_curve(self, iv_curve):
        max_length = 160
        num_pairs = max_length // 2

        if len(iv_curve) < max_length:
            # 将数据拆分为电压和电流
            voltages = np.array(iv_curve[0::2])
            currents = np.array(iv_curve[1::2])

            # 使用线性插值
            interpolator = interp1d(voltages, currents, kind='linear', fill_value='extrapolate')

            # 计算需要补充的数据点数
            additional_data_needed = max_length - len(iv_curve)

            # 生成新的电压点
            last_voltage = voltages[-1]
            first_voltage = voltages[0]
            step = (last_voltage - first_voltage) / (len(voltages) - 1)
            new_voltages = np.linspace(last_voltage + step, last_voltage + step * (additional_data_needed // 2),
                                       additional_data_needed // 2)

            # 使用插值器生成新的电流点
            new_currents = interpolator(new_voltages)

            # 将新点添加到原始IV曲线
            new_points = [round(val, 2) for pair in zip(new_voltages, new_currents) for val in pair]
            iv_curve.extend(new_points)

        # 如果长度超过最大长度，截断
        if len(iv_curve) > max_length:
            iv_curve = iv_curve[:max_length]

        return iv_curve

