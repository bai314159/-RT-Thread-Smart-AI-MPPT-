import os
import csv
import json
import pandas as pd
from datetime import datetime


"""

本地储存的使用方法：
# 创建管理器实例
manager = PVIVCurveManager()

# 存储IV曲线数据（从process_data获取的结果）
manager.store_iv_curve(1, 2, result)

# 获取IV曲线数据
data = manager.get_iv_curve(1, 2)

# 矩阵形式访问
matrix = manager.get_iv_curve_matrix()
iv_data = matrix[1][2]  # 获取第2行第3列的光伏数据


"""

class PVIVCurveManager:
    """
    光伏IV曲线管理器类
    用于存储和检索3x3光伏阵列的IV曲线数据
    """

    def __init__(self, data_dir="./lin_data"):
        """
        初始化光伏IV曲线管理器

        参数:
            data_dir (str): 数据存储目录
        """
        self.data_dir = data_dir
        self.ensure_data_dir()
        self.current_date = datetime.now().strftime("%Y%m%d")
        self.file_path = os.path.join(self.data_dir, f"{self.current_date}.csv")

        # 创建或加载当天的数据文件
        self.init_data_file()

    def ensure_data_dir(self):
        """确保数据目录存在"""
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)

    def init_data_file(self):
        """初始化或加载当天的数据文件"""
        if not os.path.exists(self.file_path):
            # 创建新文件并写入表头
            with open(self.file_path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'row', 'col', 'classification', 'vol_max', 'cur_max',
                    'pow_max', 'voltages', 'currents', 'powers'
                ])

    def update_date(self):
        """更新当前日期并相应地更新文件路径"""
        new_date = datetime.now().strftime("%Y%m%d")
        if new_date != self.current_date:
            self.current_date = new_date
            self.file_path = os.path.join(self.data_dir, f"{self.current_date}.csv")
            self.init_data_file()

    def store_iv_curve(self, row, col, result):
        """
        存储IV曲线数据

        参数:
            row (int): 光伏所在行 (0-2)
            col (int): 光伏所在列 (0-2)
            result (dict): process_data处理后的结果

        返回:
            bool: 存储成功返回True，否则返回False
        """
        try:
            # 确保日期是最新的
            self.update_date()

            # 验证行列索引
            if not (0 <= row <= 2 and 0 <= col <= 2):
                print(f"错误: 行列索引超出范围 (row={row}, col={col})")
                return False

            # 准备数据
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            voltages_json = json.dumps(result['voltages'])
            currents_json = json.dumps(result['currents'])
            powers_json = json.dumps(result['powers'])

            # 写入CSV文件
            with open(self.file_path, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    timestamp, row, col, result['classification'],
                    result['vol_max'], result['cur_max'], result['pow_max'],
                    voltages_json, currents_json, powers_json
                ])

            print(f"成功存储光伏 [{row}][{col}] 的IV曲线数据")
            return True

        except Exception as e:
            print(f"存储IV曲线时出错: {e}")
            return False

    def get_iv_curve(self, row, col, date=None):
        """
        获取指定位置光伏的最新IV曲线数据

        参数:
            row (int): 光伏所在行 (0-2)
            col (int): 光伏所在列 (0-2)
            date (str, optional): 指定日期，格式为"YYYYMMDD"，默认为当天

        返回:
            dict: 包含IV曲线数据的字典，格式与process_data输出相同，添加了行列索引
                  如果未找到数据，返回None
        """
        try:
            # 验证行列索引
            if not (0 <= row <= 2 and 0 <= col <= 2):
                print(f"错误: 行列索引超出范围 (row={row}, col={col})")
                return None

            # 确定要读取的文件
            if date is None:
                date = self.current_date

            file_path = os.path.join(self.data_dir, f"{date}.csv")
            if not os.path.exists(file_path):
                print(f"错误: 未找到日期为 {date} 的数据文件")
                return None

            # 读取CSV文件
            df = pd.read_csv(file_path)

            # 过滤指定行列的数据
            filtered_df = df[(df['row'] == row) & (df['col'] == col)]

            if filtered_df.empty:
                print(f"未找到光伏 [{row}][{col}] 的IV曲线数据")
                return None

            # 获取最新的记录
            latest_record = filtered_df.iloc[-1]

            # 解析JSON数据
            voltages = json.loads(latest_record['voltages'])
            currents = json.loads(latest_record['currents'])
            powers = json.loads(latest_record['powers'])

            # 构建结果字典
            result = {
                'row': int(latest_record['row']),
                'col': int(latest_record['col']),
                'classification': int(latest_record['classification']),
                'vol_max': float(latest_record['vol_max']),
                'cur_max': float(latest_record['cur_max']),
                'pow_max': float(latest_record['pow_max']),
                'voltages': voltages,
                'currents': currents,
                'powers': powers,
                'timestamp': latest_record['timestamp']
            }

            return result

        except Exception as e:
            print(f"获取IV曲线时出错: {e}")
            return None

    def get_all_iv_curves(self, date=None):
        """
        获取指定日期的所有IV曲线数据

        参数:
            date (str, optional): 指定日期，格式为"YYYYMMDD"，默认为当天

        返回:
            list: 包含所有IV曲线数据的列表，每个元素是一个包含行列索引和数据的字典
                  如果未找到数据，返回空列表
        """
        try:
            # 确定要读取的文件
            if date is None:
                date = self.current_date

            file_path = os.path.join(self.data_dir, f"{date}.csv")
            if not os.path.exists(file_path):
                print(f"错误: 未找到日期为 {date} 的数据文件")
                return []

            # 读取CSV文件
            df = pd.read_csv(file_path)

            if df.empty:
                return []

            # 构建结果列表
            results = []
            for _, row in df.iterrows():
                result = {
                    'row': int(row['row']),
                    'col': int(row['col']),
                    'classification': int(row['classification']),
                    'vol_max': float(row['vol_max']),
                    'cur_max': float(row['cur_max']),
                    'pow_max': float(row['pow_max']),
                    'voltages': json.loads(row['voltages']),
                    'currents': json.loads(row['currents']),
                    'powers': json.loads(row['powers']),
                    'timestamp': row['timestamp']
                }
                results.append(result)

            return results

        except Exception as e:
            print(f"获取所有IV曲线时出错: {e}")
            return []

    def get_iv_curve_matrix(self, date=None):
        """
        获取指定日期的3x3光伏阵列IV曲线数据矩阵

        参数:
            date (str, optional): 指定日期，格式为"YYYYMMDD"，默认为当天

        返回:
            list: 3x3的嵌套列表，每个元素是对应位置光伏的最新IV曲线数据
                  如果某位置没有数据，对应元素为None
        """
        try:
            # 初始化3x3矩阵
            matrix = [[None for _ in range(3)] for _ in range(3)]

            # 获取所有IV曲线数据
            all_curves = self.get_all_iv_curves(date)

            # 按行列索引整理数据
            for row in range(3):
                for col in range(3):
                    # 过滤出当前行列的数据
                    curves = [curve for curve in all_curves if curve['row'] == row and curve['col'] == col]

                    if curves:
                        # 找出最新的记录
                        latest_curve = max(curves, key=lambda x: x['timestamp'])
                        matrix[row][col] = latest_curve

            return matrix

        except Exception as e:
            print(f"获取IV曲线矩阵时出错: {e}")
            return [[None for _ in range(3)] for _ in range(3)]

'''# 使用示例
def demo_usage():
    """演示如何使用PVIVCurveManager类"""
    # 创建管理器实例
    manager = PVIVCurveManager()

    # 模拟process_data处理后的结果
    sample_result = {
        'classification': 0,
        'vol_max': 35.4,
        'cur_max': 8.2,
        'pow_max': 290.28,
        'voltages': [0, 5, 10, 15, 20, 25, 30, 35, 40],
        'currents': [8.5, 8.5, 8.4, 8.3, 8.2, 8.0, 7.5, 6.0, 0],
        'powers': [0, 42.5, 84.0, 124.5, 164.0, 200.0, 225.0, 210.0, 0]
    }

    # 存储IV曲线数据
    manager.store_iv_curve(1, 2, sample_result)

    # 获取IV曲线数据
    retrieved_result = manager.get_iv_curve(1, 2)
    print(f"检索到的IV曲线数据: {retrieved_result}")

    # 获取所有IV曲线数据
    all_curves = manager.get_all_iv_curves()
    print(f"获取到 {len(all_curves)} 条IV曲线数据")

    # 获取IV曲线矩阵
    matrix = manager.get_iv_curve_matrix()
    print("IV曲线矩阵:")
    for row in range(3):
        for col in range(3):
            if matrix[row][col]:
                print(f"[{row}][{col}]: {matrix[row][col]['classification']}")
            else:
                print(f"[{row}][{col}]: 无数据")


if __name__ == "__main__":
    demo_usage()




'''
