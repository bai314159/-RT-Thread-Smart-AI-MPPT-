import sys
import logging
import time
from threading import Thread
from time import sleep
from CON_NET.tcp_server import TcpServer,MqttClient
from CON_NET.mqtt_client import mqtt_client_instance
from DATA.data_storage import PVIVCurveManager
'''receiver-MqttReceiver
# 配置日志系统
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),  # 控制台输出
        logging.FileHandler("application.log", encoding='utf-8')  # 文件日志
    ]
)
'''


def start_tcp_server():
    """
    启动 TCP 服务器的函数
    """
    tcp_server = TcpServer(mqtt_client_instance)  # 先创建 TCP 服务器实例
   # tcp_server.start()
    mqtt_client = MqttClient(tcp_server)  # 替换为你的 MQTT 代理地址
    #tcp_server.mqtt_client = mqtt_client  # 将 MQTT 客户端赋值给 TCP 服务器
    Thread(target=tcp_server.start).start()  # 启动 TCP 服务器
    mqtt_client.start()  # 启动 MQTT 客户端


def start_mqtt_client():
    """
    启动 MQTT 客户端的函数
    """

    try:
        logging.info(get_time(),"启动 MQTT 客户端...")
        mqtt_client_instance.start()
        #server = TcpServer()
        receiver = MqttReceiver()
        receiver.start()
        print(get_time())
        logging.info("MQTT 客户端已启动。")
    except Exception as e:
        logging.error(f"启动 MQTT 客户端失败: {e}")


def start_local_storage():
    data_manager = PVIVCurveManager()
    




def get_time():
    return '[' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + ']'
def main():
    """
    主控制函数
    """
    TCP_server = True
    MQTT_client = True
    Local_storage = False

    tcp_thread = Thread(target=start_tcp_server, daemon=True)
    mqtt_thread = Thread(target=start_mqtt_client, daemon=True)
    storage_thread = Thread(target=start_mqtt_client, daemon=True)

    if TCP_server:
       tcp_thread.start()

    if MQTT_client:
       mqtt_thread.start()

    if Local_storage:
       storage_thread.start()


    try:
        while True:
            sleep(1)  # 主线程保持运行
    except KeyboardInterrupt:
        logging.info("程序终止。")
        # 此处可添加清理代码


if __name__ == "__main__":
    main()
